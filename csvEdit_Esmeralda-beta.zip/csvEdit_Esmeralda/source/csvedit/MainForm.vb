﻿'
' Created by SharpDevelop.
' User: bojan
' Date: sri 20.07.2022.
' Time: 09:12
' last edit 12:28 PM 12/24/2022
'
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Public Partial Class MainForm
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	
	Dim stProgramAndVersion As String ="csvEdit Esmeralda, v2022-12-24-1"
	Dim stWebSite As String = "dbojan.github.io"
	
	
	
	Sub fnCut
		
		fnCopy
		fnDelete
		
		laStatus.Text="Cut selected items"
	End Sub
	
	
	
	
	Sub fnCopy
		If dataGridView1.Rows.Count < 1 Then
			MsgBox("No rows?")
			Exit Sub
		End If
		'SendKeys.Send("^c")
		'copy
		'for pasting in say excel. unselected cells will be pasted as empty! deleting value in excel
		Me.dataGridView1.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText
		Clipboard.SetDataObject(Me.dataGridView1.GetClipboardContent)
		
		laStatus.Text="Copied selected items"
	End Sub
	
	
	Sub fnPaste
		
		'paste in selected cells
		
		'no selected
		If dataGridView1.GetCellCount(DataGridViewElementStates.Selected) <1 Then
			Exit Sub
		End If
		
		
		Dim liCopied As New List(Of String)
		'create list of items from clipboard
		For Each line As String In Clipboard.GetText.Split(vbNewLine)'go over each line
			If Not line.Trim.ToString = "" Then
				
				Dim items() As String = line.Trim.Split(vbTab)
				
				For Each item In items
					If item.Length > 0 Then 'no empty cells, or empty cells with newlines. newlines length is also seen as 0
						liCopied.Add(item)
						'MessageBox.Show("added " & item & " length " & item.Length)	
					End If
					
				Next
				
				
			End If
		Next
		
		
		Dim inCounterPaste As Integer = 0
		
		
		For Each dgvr As DataGridViewRow In DataGridView1.Rows
			For Each dgvc As DataGridViewCell In dgvr.Cells
				If dgvc.Selected = True Then
					'MessageBox.Show(liCopied(inCounterPaste) & inCounterPaste  )
					dgvc.Value=liCopied(inCounterPaste)
					inCounterPaste = inCounterPaste +1
				End If
				
			Next
		Next
		
		
	End Sub
	
	
	
	
	Sub fnDelete
		
		For Each cell As DataGridViewCell In dataGridView1.SelectedCells
			cell.Value=""
		Next
		
		laStatus.Text="Deleted selected items"
	End Sub
	
	
	
	
	Sub OpenToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		fnClosingDataGridView		
		Dim openFileDialog1 As New OpenFileDialog()
		If OpenFileDialog1.ShowDialog <> System.Windows.Forms.DialogResult.Cancel Then
			laFilename.Text = OpenFileDialog1.FileName
			fnOpencsv
		End If
		
		
		
	End Sub
	
	
	Sub fnOpencsv
		
		'coming from formload, or file-open
		'lafilename and ladelimiter must be set
		
		dataGridView1.EndEdit
		
		
		Dim lines() As String = IO.File.ReadAllLines(laFilename.Text)
		Dim stFirstline As String = lines(0)
		
		laDelimiter.Text=""
		
		If stFirstline.Contains(vbTab) Then
			laDelimiter.Text=vbTab
		ElseIf stFirstline.Contains("|")
			laDelimiter.Text="|"
		ElseIf stFirstline.Contains(";")
			laDelimiter.Text=";"
		Else
			laDelimiter.Text=","
		End if
		
		dataGridView1.Rows.Clear
		dataGridView1.Columns.Clear
		
		
		
		
		If laDelimiter.Text = vbTab Then 'textfield parser skips empty tab delimited lines, so we do not use it here .... 
			
			'dataGridView1.AllowUserToAddRows=false
			Dim streamReader1 As System.IO.StreamReader
			streamReader1 = My.Computer.FileSystem.OpenTextFileReader(laFilename.Text)
			Dim stFullLineRead As String
			
			Dim arLine() As String 
			Do
				stFullLineRead = streamReader1.ReadLine()
				
				arLine = Split(stFullLineRead, laDelimiter.Text)
				
				If dataGridView1.Columns.Count = 0 Then ' add columns if no columns
					For i = 0 To arLine.Length - 1
						DataGridView1.Columns.Add("Column" & i + 1, "Column" & i + 1)
					Next
				End If
				
				Me.DataGridView1.Rows.Add(arLine)
			Loop Until stFullLineRead Is Nothing
			
			
			dataGridView1.Rows.RemoveAt(dataGridView1.RowCount-2) 'remove empty line at the end
			'dataGridView1.AllowUserToAddRows=True
			streamReader1.Close() 'remove last crlf
			
			
		Else 
			
			Dim TextFieldParser1 As New Microsoft.VisualBasic.FileIO.TextFieldParser(laFilename.Text) 'but needed for , delimited, with , inside cells
			TextFieldParser1.Delimiters = New String() {laDelimiter.Text}
			While Not TextFieldParser1.EndOfData
				Dim Row1 As String() = TextFieldParser1.ReadFields()
				If DataGridView1.Columns.count = 0 Then 'no columns yet, add empty columns
					Dim i As Integer
					For i = 0 To Row1.Length - 1
						DataGridView1.Columns.Add("Column" & i + 1, "Column" & i + 1)
					Next
				End If
				DataGridView1.Rows.Add(Row1)
			End While
			
		End If
		
		
		
		laStatus.Text="File loaded"
		laChanged.Text=""
	End Sub
	
	
	
	
	
	Sub fnSavecsv
		'exit edit cell
		
		dataGridView1.EndEdit
		
		
		
		
		
		
		
		'coming from file-save
		'lafilename and ladelimiter must be set
		
		If dataGridView1.Rows.Count < 1 Then
			MsgBox("No rows? No save.")
			Exit Sub
		End If
		
		If laDelimiter.Text="" Then
			laDelimiter.Text = vbTab
		End If
		
		
		
		'empty string name
		If laFilename.Text="" Then
			
			Dim SaveFileDialog1 As New SaveFileDialog()
			saveFileDialog1.Filter = "csv separated values|*.csv|tab separated values|*.tsv|Microsoft Office Excel 2003 SpreadsheetML XML|*.xml|All files|*.*"
			
			If SaveFileDialog1.ShowDialog <> System.Windows.Forms.DialogResult.Cancel Then
				laFilename.Text = SaveFileDialog1.FileName
				
				'if tsv selected as type ' default value is 1, starting index is 1
				If saveFileDialog1.FilterIndex = 2 Then
					laDelimiter.Text=vbTab
				End If
			Else
				laStatus.Text="No file selected. File not saved"
				Exit Sub
			End If
			
		End If
		
		
		
		
		'save
		Dim stGridData As String = String.Empty
		
		'XML
		'if xml selected as type ' default value is 1, starting index is 1
		If System.IO.Path.GetExtension(laFilename.Text) = ".xml" Then
			
			stGridData = stGridData & "<?xml version=""1.0"" encoding=""utf-8""?> <?mso-application progid=""Excel.Sheet""?> <Workbook xmlns=""urn:schemas-microsoft-com:office:spreadsheet"" xmlns:x=""urn:schemas-microsoft-com:office:excel""  xmlns:ss=""urn:schemas-microsoft-com:office:spreadsheet"" >  <Worksheet ss:Name=""Sheet1"">"  
			stGridData = stGridData & "<Table>" 
			'<Column ss:Width=""67""/><Column ss:Width=""25""/><Column ss:Width=""19""/><Column ss:Width=""19""/><Column ss:Width=""25""/>  
			
			For Each row As DataGridViewRow In DataGridView1.Rows
				
				'MessageBox.Show(row.Index & "" & dataGridView1.RowCount-2)
				If row.Index = dataGridView1.RowCount-1 Then'dont go into datagrid view editing line, -1 for index starting with 0
					Exit For 
				End If
				
				stGridData = stGridData & "<Row>" 
				
				For Each cell As DataGridViewCell In row.Cells
					stGridData = stGridData & "<Cell><Data ss:Type=""String"">" & cell.Value & "</Data></Cell>"
				Next
				
				stGridData = stGridData & "</Row>"
			Next	
			
			
			stGridData = stGridData & "</Table> </Worksheet> </Workbook>" 
			
		End If
		
		'saved below
		
		
		'csv,tsv,txt, or NOTHING ""
		If System.IO.Path.GetExtension(laFilename.Text) = ".csv" Or System.IO.Path.GetExtension(laFilename.Text) = ".tsv" Or System.IO.Path.GetExtension(laFilename.Text) = ".txt" Or System.IO.Path.GetExtension(laFilename.Text) = "" Then
			
			
			For Each row As DataGridViewRow In DataGridView1.Rows
				
				'MessageBox.Show(row.Index & "" & dataGridView1.RowCount-2)
				If row.Index = dataGridView1.RowCount-1 Then'dont go into datagrid view editing line, -1 for index starting with 0
					Exit For 
				End If
				
				For Each cell As DataGridViewCell In row.Cells
					
					
					'MessageBox.Show(cell.Value)
					
					'do not evaluate furhter if string is empty. because comparing with empty string gives error!
					If Not String.IsNullOrEmpty(cell.Value) Andalso cell.Value.Contains(",") And laDelimiter.Text="," Then 'check if there is , inside cell
						stGridData = stGridData & Chr(34) & cell.Value & Chr(34)
					Else
						stGridData = stGridData & cell.Value 
					End If
					
					
					'MessageBox.Show(cell.Value & " " & cell.ColumnIndex & " " & dataGridView1.ColumnCount-1)
					
					If cell.ColumnIndex < dataGridView1.ColumnCount-1 Then 'if not last add cell delimeter
						stGridData = stGridData & laDelimiter.Text
					End If
					
				Next
				
				If row.Index < dataGridView1.RowCount-2 ' add newline, unless it is last line, -2 for staring index with 0, another one for satagrdiview editing line
					stGridData = stGridData & vbNewLine
				End If
				
			Next
			
			
			
		End If
		
		
		
		My.Computer.FileSystem.WriteAllText(laFilename.Text, stGridData, False)
		
		laStatus.Text="File saved"
		laChanged.Text=""
	End Sub
	
	
	Sub fnDataGridViewSetStatusChanged
		dataGridView1.EndEdit
		laChanged.Text="changed"
	End Sub
	
	Sub fnClosingDataGridView
		dataGridView1.EndEdit
		
		If laChanged.Text="changed" Then
			
			Dim result As DialogResult = MessageBox.Show("Table changed. Save?", stProgramAndVersion, MessageBoxButtons.YesNo)
			
			
			If result = DialogResult.No Then
				laStatus.Text="File not saved"
			ElseIf result = DialogResult.Yes Then
				fnSavecsv
				laStatus.Text="File saved"
			End If
			
			laChanged.Text=""
		End If
		
	End Sub
	
	
	Sub SaveToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		fnSavecsv
	End Sub
	
	
	Sub MainFormLoad(sender As Object, e As EventArgs)
		
		laStatus.Text=stProgramAndVersion
		
		Dim arguments As String() = Environment.GetCommandLineArgs
		If arguments.Length = 2 Then ' file was dropped on the app
			laFilename.Text=arguments(1)
			fnOpencsv	
		End If
		
	End Sub
	
	
	
	Sub MainFormDragDrop(sender As Object, e As DragEventArgs)
		dataGridView1.EndEdit
		fnClosingDataGridView
		Dim files() As String = e.Data.GetData(DataFormats.FileDrop)
		For Each file In files
			laFilename.Text=file
			fnOpencsv
		Next
		
	End Sub
	
	
	
	Sub ClearToolStripMenuItemClick(sender As Object, e As EventArgs)
		'close file
		dataGridView1.EndEdit
		fnClosingDataGridView	
		dataGridView1.Rows.Clear
		dataGridView1.Columns.Clear
		laFilename.Text=""
		laDelimiter.Text=""
		laStatus.Text="Workspace cleared"
		laSelectedCell.Text=""
		
		'because there were changes, we have to set status -not changed-, again
		laChanged.Text=""
		
	End Sub
	
	
	Sub NewToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		fnClosingDataGridView
		
		dataGridView1.Rows.Clear
		dataGridView1.Columns.Clear
		
		dataGridView1.Columns.Add("Column1","Column1") ' column name, header text
		dataGridView1.Rows.Add(1)
		
		laFilename.Text=""
		laDelimiter.Text=vbTab
		laStatus.Text="New File"
	End Sub
	
	
	
	
	Sub QuitToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		fnClosingDataGridView
		Me.Close
	End Sub
	
	
	
	Sub MainFormDragEnter(sender As Object, e As DragEventArgs)
		dataGridView1.EndEdit
		If (e.Data.GetDataPresent(DataFormats.FileDrop)) Then
			e.Effect = DragDropEffects.All
		Else
			e.Effect = DragDropEffects.None
		End If
		
	End Sub
	
	
	
	Sub AboutToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		MsgBox(stProgramAndVersion & ", " & stWebSite )		
	End Sub
	
	Sub SaveAsToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit		
		'pick a new name.
		'delimiter should already be set
		
		laFilename.Text = ""
		fnSavecsv		
	End Sub
	
	
	
	Sub ReloadToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		fnClosingDataGridView
		If laFilename.Text<> "" Then
			fnOpencsv
			laStatus.Text = "File reopened"
		Else
			laStatus.Text="No file opened, cannot reopen it"
		End If
	End Sub
	
	Sub OpenInNotepadToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit		
		fnClosingDataGridView
		
		If laFilename.Text <> "" Then
			Shell("notepad.exe " & laFilename.Text, AppWinStyle.NormalFocus )
			laStatus.Text = "Opened in Notepad"
		Else
			laStatus.Text="No file opened, cannot open it in notepad"
		End If
	End Sub
	
	Sub ColumnToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		'add column
		dataGridView1.Columns.Add(dataGridView1.Columns.Count,"Column") ' & dataGridView1.Columns.Count +1)
	End Sub
	
	
	Sub RowToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		'add row
		If dataGridView1.Columns.Count = 0  Then 'error when columns.count = 0, and user adds row 
			dataGridView1.Columns.Add(dataGridView1.Columns.Count,"Column") ' & dataGridView1.Columns.Count +1)
		Else
			
			dataGridView1.Rows.Add(1)
		End If
	End Sub
	
	Sub InsertRowToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		'insert row 
		
		If dataGridView1.Columns.Count = 0 Then 'error when no columns, when user tries to add row. add column instead
			dataGridView1.Columns.Add(dataGridView1.Columns.Count,"Column") ' & dataGridView1.Columns.Count +1)
			Exit Sub
		End If
		
		If DataGridView1.SelectedCells.Count > 0 Then 'if selected, insert row above
			dataGridView1.Rows.Insert(dataGridView1.SelectedCells.Item(0).RowIndex,"")
		Else 'else add at bottom
			dataGridView1.Rows.Add(1)
		End If
		
		
	End Sub
	
	Sub InsertColumnToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		'insert column 
		'dataGridView1.Columns.Insert(dataGridView1.CurrentCell.ColumnIndex,dataGridView1.Columns.Count)
		Dim col As New DataGridViewTextBoxColumn
		col.HeaderText = "Column" '& (dataGridView1.CurrentCell.ColumnIndex -1 ).ToString
		col.Name="name"
		
		If DataGridView1.SelectedCells.Count > 0 'if selected insert before
			dataGridView1.Columns.Insert(dataGridView1.SelectedCells.Item(0).ColumnIndex,col)
		Else 'if not selected, add at the bottom
			'dataGridView1.Columns.Insert(0,col)
			dataGridView1.Columns.Add(dataGridView1.Columns.Count,"Column")
		End If
		
		
	End Sub
	
	Sub RemoveRowToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		'remove row(s)	
		
		If  dataGridView1.SelectedRows.Count = 0 And DataGridView1.SelectedCells.Count > 0 Then 'no row/s selected, BUT cell/s selected
			
			Dim soRowIndex = New SortedSet(Of Integer)() 'create list of indices of selected rows, in which cells are selected
			
			For inNumberOfSelectedCells As Integer = 0 To dataGridView1.SelectedCells.Count -1 'number of selected items
				soRowIndex.Add( dataGridView1.SelectedCells( inNumberOfSelectedCells ).RowIndex )	'add index of rows, inNumberOfSelectedCells is ordinal number 1, then ordinal number 2 ...
				'ordinal numbers START with 0
			Next
			
			For Each item As String In soRowIndex.Reverse  'start with biggest index, so don't mess up order by deleting
				dataGridView1.Rows.RemoveAt(item)
			Next
			
			
		Else 'full rows selected
			
			For Each row As DataGridViewRow In dataGridView1.SelectedRows
				dataGridView1.Rows.Remove(row)
			Next
			
			
		End If
		
		
		
	End Sub
	
	
	Sub RemoveColumnToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		'remove column(s)
		
		
		If  dataGridView1.SelectedColumns.Count = 0 And DataGridView1.SelectedCells.Count > 0 Then 'no columns selected, BUT cell/s selected
			
			Dim soColumnIndex = New SortedSet(Of Integer)() 'create list of indices of selected columns, in which cells are selected
			
			For inNumberOfSelectedCells As Integer = 0 To dataGridView1.SelectedCells.Count -1 'number of selected items
				soColumnIndex.Add( dataGridView1.SelectedCells( inNumberOfSelectedCells ).ColumnIndex )	'add index of columns, inNumberOfSelectedCells is ordinal number 1, then ordinal number 2 ...
				'ordinal numbers START with 0
			Next
			
			For Each item As String In soColumnIndex.Reverse  'start with biggest index, so don't mess up order by deleting
				dataGridView1.Columns.RemoveAt(item)
			Next
			
			
		Else 'full column selected
			
			For Each row As DataGridViewRow In dataGridView1.SelectedRows
				dataGridView1.Rows.Remove(row)
			Next
			
			
		End If
		
		
		
	End Sub
	
	
	
	
	Sub DataGridView1Click(sender As Object, e As EventArgs)
		
		'display selected cell.text in status
		If  dataGridView1.SelectedCells.Count > 0
			laSelectedCell.Text=dataGridView1.CurrentCell.Value
			
		End If
		
		
		
	End Sub
	
	
	
	Sub ClearCellsToolStripMenuItemClick(sender As Object, e As EventArgs)
		
		dataGridView1.EndEdit
		
		For Each cell As datagridviewcell In dataGridView1.SelectedCells
			cell.Value= ""
		Next
		
		
	End Sub
	
	
	Sub MainFormFormClosing(sender As Object, e As FormClosingEventArgs)
		dataGridView1.EndEdit
		fnClosingDataGridView
	End Sub
	
	
	
	Sub DataGridView1CellValueChanged(sender As Object, e As DataGridViewCellEventArgs)
		fnDataGridViewSetStatusChanged
	End Sub
	
	
	Sub DataGridView1ColumnAdded(sender As Object, e As DataGridViewColumnEventArgs)
		fnDataGridViewSetStatusChanged
	End Sub
	
	Sub DataGridView1ColumnRemoved(sender As Object, e As DataGridViewColumnEventArgs)
		fnDataGridViewSetStatusChanged
	End Sub
	
	Sub DataGridView1RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs)
		fnDataGridViewSetStatusChanged
	End Sub
	
	Sub DataGridView1RowsRemoved(sender As Object, e As DataGridViewRowsRemovedEventArgs)
		fnDataGridViewSetStatusChanged
	End Sub
	
	Sub DataGridView1Sorted(sender As Object, e As EventArgs)
		fnDataGridViewSetStatusChanged
	End Sub
	
	Sub ChangeDelimiterToolStripMenuItemClick(sender As Object, e As EventArgs)
		
		'exit edit cell
		dataGridView1.EndEdit
		
		If dataGridView1.Rows.Count < 1 Then
			MsgBox("No rows? Exiting.")
			Exit Sub
		End If
		
		Dim message, title, defaultValue As String
		Dim myValue As Object
		' Set prompt.
		message = "Enter a new delimiter. Use tab for tab."
		' Set title.
		title = stProgramAndVersion
		defaultValue = laDelimiter.Text 'currently used
		If defaultValue = vbTab Then
			defaultValue = "tab"
			
		End If
		
		' Display message, title, and default value.
		myValue = InputBox(message, title,defaultValue)
		
		If myValue <> "" Then 'if equals "" then it is cancel. othervise ...
			
			If myValue = "tab" Then 'if user entered tab, convert it to vbtab
				myValue = vbTab
			End If
			
			If laDelimiter.Text <> myValue Then 'if there is a change
				laDelimiter.Text = myValue
				fnDataGridViewSetStatusChanged
			End If
			
		End If
		
		
	End Sub
	
	
	
	
	Sub CutToolStripMenuItem1Click(sender As Object, e As EventArgs)
		fnCut
	End Sub
	
	
	Sub CopyToolStripMenuItemClick(sender As Object, e As EventArgs)
		fnCopy
	End Sub
	
	
	Sub PasteToolStripMenuItem1Click(sender As Object, e As EventArgs)
		fnPaste
	End Sub
	
	
	Sub DeleteToolStripMenuItem1Click(sender As Object, e As EventArgs)
		fnDelete
	End Sub
	
	
	
	
	
	Sub CutToolStripMenuItemClick(sender As Object, e As EventArgs)
		fnCut
	End Sub
	
	Sub CopyToolStripMenuItem1Click(sender As Object, e As EventArgs)
		fnCopy
	End Sub
	
	
	Sub PasteToolStripMenuItemClick(sender As Object, e As EventArgs)
		fnPaste
	End Sub
	
	Sub DeleteToolStripMenuItemClick(sender As Object, e As EventArgs)
		fnDelete
	End Sub
	
	
	
End Class

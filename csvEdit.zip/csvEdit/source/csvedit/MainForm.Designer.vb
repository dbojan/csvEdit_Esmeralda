'
' Created by SharpDevelop.
' User: bojan
' Date: sri 20.07.2022.
' Time: 09:12
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class MainForm
	Inherits System.Windows.Forms.Form
	
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Me.dataGridView1 = New System.Windows.Forms.DataGridView()
		Me.contextMenuStripContext = New System.Windows.Forms.ContextMenuStrip(Me.components)
		Me.cutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.copyToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
		Me.pasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.deleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.menuStrip1 = New System.Windows.Forms.MenuStrip()
		Me.fileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.newToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.openToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.reloadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.saveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.saveAsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.clearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.openInNewWindowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.openInNotepadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.quitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.editToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.cutToolStripMenuItemFORMMENU = New System.Windows.Forms.ToolStripMenuItem()
		Me.copyToolStripMenuItemFROMMENU = New System.Windows.Forms.ToolStripMenuItem()
		Me.pasteToolStripMenuItemFORMMENU = New System.Windows.Forms.ToolStripMenuItem()
		Me.pasteSingleValueInMultipleCellsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.pasteNonEmptyValuesInMultipleCellsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.deleteToolStripMenuItemFORMMENU = New System.Windows.Forms.ToolStripMenuItem()
		Me.toolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
		Me.copyWithHeaderInformationM3UToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.pasteAddToTheBottomRowsWithHeaderInformationM3UToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.bottomPasteRowsWithHeaderInformationM3UToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.doubleClickCellToPlayURLInM3UListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.searchMovesMatchingRowsToTheTopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.setUserAgentWhenStreamingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.validateM3UCellValuesWhenSavingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.replaceSpecialCharactersWhenConvertingXMLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.insertToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.removeRowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.insertRowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.removeColumnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.insertColumnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.rowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.columnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.toolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
		Me.changeColumnTitleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.changeDelimiterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.toolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
		Me.moveColumnToTheRightToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.moveColumnToTheLeftToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.toolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
		Me.moveTopRowToHeadersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.moveHeadersToTopRowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.iPTVToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.playToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.checkSelectedLinksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.checkLinksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.markDuplicateURLsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.removeDuplicateURLsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.addChannelNumberToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.markSelectedTemporarilyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.removeTemporToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.copyNamesFromURLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.createM3uListFromAFolderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.createFolderFromM3UListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.helpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.aboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.tableInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.statusStrip1 = New System.Windows.Forms.StatusStrip()
		Me.laFilename = New System.Windows.Forms.ToolStripStatusLabel()
		Me.laDelimiter = New System.Windows.Forms.ToolStripStatusLabel()
		Me.laStatus = New System.Windows.Forms.ToolStripStatusLabel()
		Me.laSelectedCell = New System.Windows.Forms.ToolStripStatusLabel()
		Me.laChanged = New System.Windows.Forms.ToolStripStatusLabel()
		Me.cmColumnName = New System.Windows.Forms.ComboBox()
		Me.cmSearchFor = New System.Windows.Forms.ComboBox()
		Me.bnSearch = New System.Windows.Forms.Button()
		Me.toolTip1 = New System.Windows.Forms.ToolTip(Me.components)
		Me.doNotFilterDroppedMultipleFilesOnProgramToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		CType(Me.dataGridView1,System.ComponentModel.ISupportInitialize).BeginInit
		Me.contextMenuStripContext.SuspendLayout
		Me.menuStrip1.SuspendLayout
		Me.statusStrip1.SuspendLayout
		Me.SuspendLayout
		'
		'dataGridView1
		'
		Me.dataGridView1.AllowDrop = true
		Me.dataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom)  _
						Or System.Windows.Forms.AnchorStyles.Left)  _
						Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
		Me.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
		Me.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
		Me.dataGridView1.ContextMenuStrip = Me.contextMenuStripContext
		Me.dataGridView1.Location = New System.Drawing.Point(12, 52)
		Me.dataGridView1.Name = "dataGridView1"
		Me.dataGridView1.Size = New System.Drawing.Size(984, 364)
		Me.dataGridView1.TabIndex = 1
		AddHandler Me.dataGridView1.CellMouseDoubleClick, AddressOf Me.DataGridView1CellMouseDoubleClick
		AddHandler Me.dataGridView1.CellValueChanged, AddressOf Me.DataGridView1CellValueChanged
		AddHandler Me.dataGridView1.ColumnAdded, AddressOf Me.DataGridView1ColumnAdded
		AddHandler Me.dataGridView1.ColumnRemoved, AddressOf Me.DataGridView1ColumnRemoved
		AddHandler Me.dataGridView1.RowsAdded, AddressOf Me.DataGridView1RowsAdded
		AddHandler Me.dataGridView1.RowsRemoved, AddressOf Me.DataGridView1RowsRemoved
		AddHandler Me.dataGridView1.Sorted, AddressOf Me.DataGridView1Sorted
		AddHandler Me.dataGridView1.Click, AddressOf Me.DataGridView1Click
		AddHandler Me.dataGridView1.DragDrop, AddressOf Me.MainFormDragDrop
		AddHandler Me.dataGridView1.DragEnter, AddressOf Me.MainFormDragEnter
		'
		'contextMenuStripContext
		'
		Me.contextMenuStripContext.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cutToolStripMenuItem, Me.copyToolStripMenuItem1, Me.pasteToolStripMenuItem, Me.deleteToolStripMenuItem})
		Me.contextMenuStripContext.Name = "contextMenuStrip1"
		Me.contextMenuStripContext.Size = New System.Drawing.Size(108, 92)
		'
		'cutToolStripMenuItem
		'
		Me.cutToolStripMenuItem.Name = "cutToolStripMenuItem"
		Me.cutToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
		Me.cutToolStripMenuItem.Text = "Cut"
		AddHandler Me.cutToolStripMenuItem.Click, AddressOf Me.CutToolStripMenuItemClick
		'
		'copyToolStripMenuItem1
		'
		Me.copyToolStripMenuItem1.Name = "copyToolStripMenuItem1"
		Me.copyToolStripMenuItem1.Size = New System.Drawing.Size(107, 22)
		Me.copyToolStripMenuItem1.Text = "Copy"
		AddHandler Me.copyToolStripMenuItem1.Click, AddressOf Me.CopyToolStripMenuItem1Click
		'
		'pasteToolStripMenuItem
		'
		Me.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem"
		Me.pasteToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
		Me.pasteToolStripMenuItem.Text = "Paste"
		AddHandler Me.pasteToolStripMenuItem.Click, AddressOf Me.PasteToolStripMenuItemClick
		'
		'deleteToolStripMenuItem
		'
		Me.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem"
		Me.deleteToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
		Me.deleteToolStripMenuItem.Text = "Delete"
		AddHandler Me.deleteToolStripMenuItem.Click, AddressOf Me.DeleteToolStripMenuItemClick
		'
		'menuStrip1
		'
		Me.menuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.fileToolStripMenuItem, Me.editToolStripMenuItem, Me.insertToolStripMenuItem, Me.iPTVToolStripMenuItem, Me.helpToolStripMenuItem})
		Me.menuStrip1.Location = New System.Drawing.Point(0, 0)
		Me.menuStrip1.Name = "menuStrip1"
		Me.menuStrip1.Size = New System.Drawing.Size(1008, 24)
		Me.menuStrip1.TabIndex = 2
		Me.menuStrip1.Text = "menuStrip1"
		'
		'fileToolStripMenuItem
		'
		Me.fileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.newToolStripMenuItem, Me.openToolStripMenuItem, Me.reloadToolStripMenuItem, Me.saveToolStripMenuItem, Me.saveAsToolStripMenuItem, Me.clearToolStripMenuItem, Me.openInNewWindowToolStripMenuItem, Me.openInNotepadToolStripMenuItem, Me.quitToolStripMenuItem})
		Me.fileToolStripMenuItem.Name = "fileToolStripMenuItem"
		Me.fileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
		Me.fileToolStripMenuItem.Text = "&File"
		'
		'newToolStripMenuItem
		'
		Me.newToolStripMenuItem.Name = "newToolStripMenuItem"
		Me.newToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N),System.Windows.Forms.Keys)
		Me.newToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
		Me.newToolStripMenuItem.Text = "&New"
		AddHandler Me.newToolStripMenuItem.Click, AddressOf Me.NewToolStripMenuItemClick
		'
		'openToolStripMenuItem
		'
		Me.openToolStripMenuItem.Name = "openToolStripMenuItem"
		Me.openToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O),System.Windows.Forms.Keys)
		Me.openToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
		Me.openToolStripMenuItem.Text = "&Open ..."
		Me.openToolStripMenuItem.ToolTipText = "Hold SHIFT to open in New Window"
		AddHandler Me.openToolStripMenuItem.Click, AddressOf Me.OpenToolStripMenuItemClick
		'
		'reloadToolStripMenuItem
		'
		Me.reloadToolStripMenuItem.Name = "reloadToolStripMenuItem"
		Me.reloadToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
		Me.reloadToolStripMenuItem.Text = "Re-Open"
		AddHandler Me.reloadToolStripMenuItem.Click, AddressOf Me.ReloadToolStripMenuItemClick
		'
		'saveToolStripMenuItem
		'
		Me.saveToolStripMenuItem.Name = "saveToolStripMenuItem"
		Me.saveToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S),System.Windows.Forms.Keys)
		Me.saveToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
		Me.saveToolStripMenuItem.Text = "&Save"
		AddHandler Me.saveToolStripMenuItem.Click, AddressOf Me.SaveToolStripMenuItemClick
		'
		'saveAsToolStripMenuItem
		'
		Me.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem"
		Me.saveAsToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift)  _
						Or System.Windows.Forms.Keys.S),System.Windows.Forms.Keys)
		Me.saveAsToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
		Me.saveAsToolStripMenuItem.Text = "Save &As ..."
		AddHandler Me.saveAsToolStripMenuItem.Click, AddressOf Me.SaveAsToolStripMenuItemClick
		'
		'clearToolStripMenuItem
		'
		Me.clearToolStripMenuItem.Name = "clearToolStripMenuItem"
		Me.clearToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
		Me.clearToolStripMenuItem.Text = "Close"
		AddHandler Me.clearToolStripMenuItem.Click, AddressOf Me.ClearToolStripMenuItemClick
		'
		'openInNewWindowToolStripMenuItem
		'
		Me.openInNewWindowToolStripMenuItem.Name = "openInNewWindowToolStripMenuItem"
		Me.openInNewWindowToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
		Me.openInNewWindowToolStripMenuItem.Text = "Open in New Window"
		AddHandler Me.openInNewWindowToolStripMenuItem.Click, AddressOf Me.OpenInNewWindowToolStripMenuItemClick
		'
		'openInNotepadToolStripMenuItem
		'
		Me.openInNotepadToolStripMenuItem.Name = "openInNotepadToolStripMenuItem"
		Me.openInNotepadToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
		Me.openInNotepadToolStripMenuItem.Text = "Open in Notepad"
		AddHandler Me.openInNotepadToolStripMenuItem.Click, AddressOf Me.OpenInNotepadToolStripMenuItemClick
		'
		'quitToolStripMenuItem
		'
		Me.quitToolStripMenuItem.Name = "quitToolStripMenuItem"
		Me.quitToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
		Me.quitToolStripMenuItem.Text = "Quit"
		AddHandler Me.quitToolStripMenuItem.Click, AddressOf Me.QuitToolStripMenuItemClick
		'
		'editToolStripMenuItem
		'
		Me.editToolStripMenuItem.CheckOnClick = true
		Me.editToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cutToolStripMenuItemFORMMENU, Me.copyToolStripMenuItemFROMMENU, Me.pasteToolStripMenuItemFORMMENU, Me.pasteSingleValueInMultipleCellsToolStripMenuItem, Me.pasteNonEmptyValuesInMultipleCellsToolStripMenuItem, Me.deleteToolStripMenuItemFORMMENU, Me.toolStripMenuItem5, Me.copyWithHeaderInformationM3UToolStripMenuItem, Me.pasteAddToTheBottomRowsWithHeaderInformationM3UToolStripMenuItem, Me.bottomPasteRowsWithHeaderInformationM3UToolStripMenuItem, Me.doubleClickCellToPlayURLInM3UListToolStripMenuItem, Me.searchMovesMatchingRowsToTheTopToolStripMenuItem, Me.setUserAgentWhenStreamingToolStripMenuItem, Me.validateM3UCellValuesWhenSavingToolStripMenuItem, Me.replaceSpecialCharactersWhenConvertingXMLToolStripMenuItem, Me.doNotFilterDroppedMultipleFilesOnProgramToolStripMenuItem})
		Me.editToolStripMenuItem.Name = "editToolStripMenuItem"
		Me.editToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
		Me.editToolStripMenuItem.Text = "&Edit"
		'
		'cutToolStripMenuItemFORMMENU
		'
		Me.cutToolStripMenuItemFORMMENU.Name = "cutToolStripMenuItemFORMMENU"
		Me.cutToolStripMenuItemFORMMENU.Size = New System.Drawing.Size(459, 22)
		Me.cutToolStripMenuItemFORMMENU.Text = "Cu&t"
		AddHandler Me.cutToolStripMenuItemFORMMENU.Click, AddressOf Me.CutToolStripMenuItem1Click
		'
		'copyToolStripMenuItemFROMMENU
		'
		Me.copyToolStripMenuItemFROMMENU.Name = "copyToolStripMenuItemFROMMENU"
		Me.copyToolStripMenuItemFROMMENU.Size = New System.Drawing.Size(459, 22)
		Me.copyToolStripMenuItemFROMMENU.Text = "&Copy"
		AddHandler Me.copyToolStripMenuItemFROMMENU.Click, AddressOf Me.CopyToolStripMenuItemClick
		'
		'pasteToolStripMenuItemFORMMENU
		'
		Me.pasteToolStripMenuItemFORMMENU.Name = "pasteToolStripMenuItemFORMMENU"
		Me.pasteToolStripMenuItemFORMMENU.Size = New System.Drawing.Size(459, 22)
		Me.pasteToolStripMenuItemFORMMENU.Text = "Paste"
		AddHandler Me.pasteToolStripMenuItemFORMMENU.Click, AddressOf Me.PasteToolStripMenuItem1Click
		'
		'pasteSingleValueInMultipleCellsToolStripMenuItem
		'
		Me.pasteSingleValueInMultipleCellsToolStripMenuItem.Name = "pasteSingleValueInMultipleCellsToolStripMenuItem"
		Me.pasteSingleValueInMultipleCellsToolStripMenuItem.Size = New System.Drawing.Size(459, 22)
		Me.pasteSingleValueInMultipleCellsToolStripMenuItem.Text = "Paste Single Value In Selected Cells"
		Me.pasteSingleValueInMultipleCellsToolStripMenuItem.ToolTipText = "Paste first value from the clipboard to all selected cells"
		AddHandler Me.pasteSingleValueInMultipleCellsToolStripMenuItem.Click, AddressOf Me.PasteSingleValueInMultipleCellsToolStripMenuItemClick
		'
		'pasteNonEmptyValuesInMultipleCellsToolStripMenuItem
		'
		Me.pasteNonEmptyValuesInMultipleCellsToolStripMenuItem.Name = "pasteNonEmptyValuesInMultipleCellsToolStripMenuItem"
		Me.pasteNonEmptyValuesInMultipleCellsToolStripMenuItem.Size = New System.Drawing.Size(459, 22)
		Me.pasteNonEmptyValuesInMultipleCellsToolStripMenuItem.Text = "Paste Non-Empty Values in Selected Cells"
		AddHandler Me.pasteNonEmptyValuesInMultipleCellsToolStripMenuItem.Click, AddressOf Me.PasteNonEmptyValuesInMultipleCellsToolStripMenuItemClick
		'
		'deleteToolStripMenuItemFORMMENU
		'
		Me.deleteToolStripMenuItemFORMMENU.Name = "deleteToolStripMenuItemFORMMENU"
		Me.deleteToolStripMenuItemFORMMENU.ShortcutKeys = CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.Delete),System.Windows.Forms.Keys)
		Me.deleteToolStripMenuItemFORMMENU.Size = New System.Drawing.Size(459, 22)
		Me.deleteToolStripMenuItemFORMMENU.Text = "De&lete"
		AddHandler Me.deleteToolStripMenuItemFORMMENU.Click, AddressOf Me.DeleteToolStripMenuItem1Click
		'
		'toolStripMenuItem5
		'
		Me.toolStripMenuItem5.Name = "toolStripMenuItem5"
		Me.toolStripMenuItem5.Size = New System.Drawing.Size(459, 22)
		Me.toolStripMenuItem5.Text = "---"
		'
		'copyWithHeaderInformationM3UToolStripMenuItem
		'
		Me.copyWithHeaderInformationM3UToolStripMenuItem.Name = "copyWithHeaderInformationM3UToolStripMenuItem"
		Me.copyWithHeaderInformationM3UToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D1),System.Windows.Forms.Keys)
		Me.copyWithHeaderInformationM3UToolStripMenuItem.Size = New System.Drawing.Size(459, 22)
		Me.copyWithHeaderInformationM3UToolStripMenuItem.Text = "Copy Rows With Header Information (M3U)"
		AddHandler Me.copyWithHeaderInformationM3UToolStripMenuItem.Click, AddressOf Me.CopyWithHeaderInformationM3UToolStripMenuItemClick
		'
		'pasteAddToTheBottomRowsWithHeaderInformationM3UToolStripMenuItem
		'
		Me.pasteAddToTheBottomRowsWithHeaderInformationM3UToolStripMenuItem.Name = "pasteAddToTheBottomRowsWithHeaderInformationM3UToolStripMenuItem"
		Me.pasteAddToTheBottomRowsWithHeaderInformationM3UToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D2),System.Windows.Forms.Keys)
		Me.pasteAddToTheBottomRowsWithHeaderInformationM3UToolStripMenuItem.Size = New System.Drawing.Size(459, 22)
		Me.pasteAddToTheBottomRowsWithHeaderInformationM3UToolStripMenuItem.Text = "Paste-Insert At  the Current Rows With Header Information (M3U)"
		AddHandler Me.pasteAddToTheBottomRowsWithHeaderInformationM3UToolStripMenuItem.Click, AddressOf Me.PasteAddToTheBottomRowsWithHeaderInformationM3UToolStripMenuItemClick
		'
		'bottomPasteRowsWithHeaderInformationM3UToolStripMenuItem
		'
		Me.bottomPasteRowsWithHeaderInformationM3UToolStripMenuItem.Name = "bottomPasteRowsWithHeaderInformationM3UToolStripMenuItem"
		Me.bottomPasteRowsWithHeaderInformationM3UToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D3),System.Windows.Forms.Keys)
		Me.bottomPasteRowsWithHeaderInformationM3UToolStripMenuItem.Size = New System.Drawing.Size(459, 22)
		Me.bottomPasteRowsWithHeaderInformationM3UToolStripMenuItem.Text = "Paste-Add To The Bottom Rows With Header Information (M3U)"
		AddHandler Me.bottomPasteRowsWithHeaderInformationM3UToolStripMenuItem.Click, AddressOf Me.BottomPasteRowsWithHeaderInformationM3UToolStripMenuItemClick
		'
		'doubleClickCellToPlayURLInM3UListToolStripMenuItem
		'
		Me.doubleClickCellToPlayURLInM3UListToolStripMenuItem.Checked = true
		Me.doubleClickCellToPlayURLInM3UListToolStripMenuItem.CheckOnClick = true
		Me.doubleClickCellToPlayURLInM3UListToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
		Me.doubleClickCellToPlayURLInM3UListToolStripMenuItem.Name = "doubleClickCellToPlayURLInM3UListToolStripMenuItem"
		Me.doubleClickCellToPlayURLInM3UListToolStripMenuItem.Size = New System.Drawing.Size(459, 22)
		Me.doubleClickCellToPlayURLInM3UListToolStripMenuItem.Text = "Double Click Cell To Play URL In M3U List"
		AddHandler Me.doubleClickCellToPlayURLInM3UListToolStripMenuItem.Click, AddressOf Me.DoubleClickCellToPlayURLInM3UListToolStripMenuItemClick
		'
		'searchMovesMatchingRowsToTheTopToolStripMenuItem
		'
		Me.searchMovesMatchingRowsToTheTopToolStripMenuItem.Checked = true
		Me.searchMovesMatchingRowsToTheTopToolStripMenuItem.CheckOnClick = true
		Me.searchMovesMatchingRowsToTheTopToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
		Me.searchMovesMatchingRowsToTheTopToolStripMenuItem.Name = "searchMovesMatchingRowsToTheTopToolStripMenuItem"
		Me.searchMovesMatchingRowsToTheTopToolStripMenuItem.Size = New System.Drawing.Size(459, 22)
		Me.searchMovesMatchingRowsToTheTopToolStripMenuItem.Text = "Search Moves Matching Rows To The Top"
		AddHandler Me.searchMovesMatchingRowsToTheTopToolStripMenuItem.Click, AddressOf Me.SearchMovesMatchingRowsToTheTopToolStripMenuItemClick
		'
		'setUserAgentWhenStreamingToolStripMenuItem
		'
		Me.setUserAgentWhenStreamingToolStripMenuItem.Checked = true
		Me.setUserAgentWhenStreamingToolStripMenuItem.CheckOnClick = true
		Me.setUserAgentWhenStreamingToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
		Me.setUserAgentWhenStreamingToolStripMenuItem.Name = "setUserAgentWhenStreamingToolStripMenuItem"
		Me.setUserAgentWhenStreamingToolStripMenuItem.Size = New System.Drawing.Size(459, 22)
		Me.setUserAgentWhenStreamingToolStripMenuItem.Text = "Auto Set User Agent for Network URL"
		AddHandler Me.setUserAgentWhenStreamingToolStripMenuItem.Click, AddressOf Me.SetUserAgentWhenStreamingToolStripMenuItemClick
		'
		'validateM3UCellValuesWhenSavingToolStripMenuItem
		'
		Me.validateM3UCellValuesWhenSavingToolStripMenuItem.Checked = true
		Me.validateM3UCellValuesWhenSavingToolStripMenuItem.CheckOnClick = true
		Me.validateM3UCellValuesWhenSavingToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
		Me.validateM3UCellValuesWhenSavingToolStripMenuItem.Name = "validateM3UCellValuesWhenSavingToolStripMenuItem"
		Me.validateM3UCellValuesWhenSavingToolStripMenuItem.Size = New System.Drawing.Size(459, 22)
		Me.validateM3UCellValuesWhenSavingToolStripMenuItem.Text = "Validate M3U Cell Values When Saving"
		AddHandler Me.validateM3UCellValuesWhenSavingToolStripMenuItem.Click, AddressOf Me.ValidateM3UCellValuesWhenSavingToolStripMenuItemClick
		'
		'replaceSpecialCharactersWhenConvertingXMLToolStripMenuItem
		'
		Me.replaceSpecialCharactersWhenConvertingXMLToolStripMenuItem.Checked = true
		Me.replaceSpecialCharactersWhenConvertingXMLToolStripMenuItem.CheckOnClick = true
		Me.replaceSpecialCharactersWhenConvertingXMLToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
		Me.replaceSpecialCharactersWhenConvertingXMLToolStripMenuItem.Name = "replaceSpecialCharactersWhenConvertingXMLToolStripMenuItem"
		Me.replaceSpecialCharactersWhenConvertingXMLToolStripMenuItem.Size = New System.Drawing.Size(459, 22)
		Me.replaceSpecialCharactersWhenConvertingXMLToolStripMenuItem.Text = "Replace Special Characters When Converting To And From XML"
		AddHandler Me.replaceSpecialCharactersWhenConvertingXMLToolStripMenuItem.Click, AddressOf Me.ReplaceSpecialCharactersWhenConvertingXMLToolStripMenuItemClick
		'
		'insertToolStripMenuItem
		'
		Me.insertToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.removeRowToolStripMenuItem, Me.insertRowToolStripMenuItem, Me.removeColumnToolStripMenuItem, Me.insertColumnToolStripMenuItem, Me.rowToolStripMenuItem, Me.columnToolStripMenuItem, Me.toolStripMenuItem2, Me.changeColumnTitleToolStripMenuItem, Me.changeDelimiterToolStripMenuItem, Me.toolStripMenuItem3, Me.moveColumnToTheRightToolStripMenuItem, Me.moveColumnToTheLeftToolStripMenuItem, Me.toolStripMenuItem4, Me.moveTopRowToHeadersToolStripMenuItem, Me.moveHeadersToTopRowToolStripMenuItem})
		Me.insertToolStripMenuItem.Name = "insertToolStripMenuItem"
		Me.insertToolStripMenuItem.Size = New System.Drawing.Size(57, 20)
		Me.insertToolStripMenuItem.Text = "&Modify"
		'
		'removeRowToolStripMenuItem
		'
		Me.removeRowToolStripMenuItem.Name = "removeRowToolStripMenuItem"
		Me.removeRowToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5
		Me.removeRowToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
		Me.removeRowToolStripMenuItem.Text = "Row(s) Remove"
		AddHandler Me.removeRowToolStripMenuItem.Click, AddressOf Me.RemoveRowToolStripMenuItemClick
		'
		'insertRowToolStripMenuItem
		'
		Me.insertRowToolStripMenuItem.Name = "insertRowToolStripMenuItem"
		Me.insertRowToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F6
		Me.insertRowToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
		Me.insertRowToolStripMenuItem.Text = "Row Insert"
		AddHandler Me.insertRowToolStripMenuItem.Click, AddressOf Me.InsertRowToolStripMenuItemClick
		'
		'removeColumnToolStripMenuItem
		'
		Me.removeColumnToolStripMenuItem.Name = "removeColumnToolStripMenuItem"
		Me.removeColumnToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F7
		Me.removeColumnToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
		Me.removeColumnToolStripMenuItem.Text = "Column(s) Remove"
		AddHandler Me.removeColumnToolStripMenuItem.Click, AddressOf Me.RemoveColumnToolStripMenuItemClick
		'
		'insertColumnToolStripMenuItem
		'
		Me.insertColumnToolStripMenuItem.Name = "insertColumnToolStripMenuItem"
		Me.insertColumnToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F8
		Me.insertColumnToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
		Me.insertColumnToolStripMenuItem.Text = "Column Insert"
		AddHandler Me.insertColumnToolStripMenuItem.Click, AddressOf Me.InsertColumnToolStripMenuItemClick
		'
		'rowToolStripMenuItem
		'
		Me.rowToolStripMenuItem.Name = "rowToolStripMenuItem"
		Me.rowToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
		Me.rowToolStripMenuItem.Text = "Row Add"
		AddHandler Me.rowToolStripMenuItem.Click, AddressOf Me.RowToolStripMenuItemClick
		'
		'columnToolStripMenuItem
		'
		Me.columnToolStripMenuItem.Name = "columnToolStripMenuItem"
		Me.columnToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
		Me.columnToolStripMenuItem.Text = "Column Add"
		AddHandler Me.columnToolStripMenuItem.Click, AddressOf Me.ColumnToolStripMenuItemClick
		'
		'toolStripMenuItem2
		'
		Me.toolStripMenuItem2.Name = "toolStripMenuItem2"
		Me.toolStripMenuItem2.Size = New System.Drawing.Size(297, 22)
		Me.toolStripMenuItem2.Text = "---"
		'
		'changeColumnTitleToolStripMenuItem
		'
		Me.changeColumnTitleToolStripMenuItem.Name = "changeColumnTitleToolStripMenuItem"
		Me.changeColumnTitleToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
		Me.changeColumnTitleToolStripMenuItem.Text = "Change Column Title (For M3U)"
		AddHandler Me.changeColumnTitleToolStripMenuItem.Click, AddressOf Me.ChangeColumnTitleToolStripMenuItemClick
		'
		'changeDelimiterToolStripMenuItem
		'
		Me.changeDelimiterToolStripMenuItem.Name = "changeDelimiterToolStripMenuItem"
		Me.changeDelimiterToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
		Me.changeDelimiterToolStripMenuItem.Text = "Change Delimiter (For CSV)"
		AddHandler Me.changeDelimiterToolStripMenuItem.Click, AddressOf Me.ChangeDelimiterToolStripMenuItemClick
		'
		'toolStripMenuItem3
		'
		Me.toolStripMenuItem3.Name = "toolStripMenuItem3"
		Me.toolStripMenuItem3.Size = New System.Drawing.Size(297, 22)
		Me.toolStripMenuItem3.Text = "---"
		'
		'moveColumnToTheRightToolStripMenuItem
		'
		Me.moveColumnToTheRightToolStripMenuItem.Name = "moveColumnToTheRightToolStripMenuItem"
		Me.moveColumnToTheRightToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F12
		Me.moveColumnToTheRightToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
		Me.moveColumnToTheRightToolStripMenuItem.Text = "Move Column To The Right (For CSV)"
		AddHandler Me.moveColumnToTheRightToolStripMenuItem.Click, AddressOf Me.MoveColumnToTheRightToolStripMenuItemClick
		'
		'moveColumnToTheLeftToolStripMenuItem
		'
		Me.moveColumnToTheLeftToolStripMenuItem.Name = "moveColumnToTheLeftToolStripMenuItem"
		Me.moveColumnToTheLeftToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F11
		Me.moveColumnToTheLeftToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
		Me.moveColumnToTheLeftToolStripMenuItem.Text = "Move Column To the Left (For Csv)"
		AddHandler Me.moveColumnToTheLeftToolStripMenuItem.Click, AddressOf Me.MoveColumnToTheLeftToolStripMenuItemClick
		'
		'toolStripMenuItem4
		'
		Me.toolStripMenuItem4.Name = "toolStripMenuItem4"
		Me.toolStripMenuItem4.Size = New System.Drawing.Size(297, 22)
		Me.toolStripMenuItem4.Text = "---"
		'
		'moveTopRowToHeadersToolStripMenuItem
		'
		Me.moveTopRowToHeadersToolStripMenuItem.Name = "moveTopRowToHeadersToolStripMenuItem"
		Me.moveTopRowToHeadersToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
		Me.moveTopRowToHeadersToolStripMenuItem.Text = "Move Top Row To Headers"
		AddHandler Me.moveTopRowToHeadersToolStripMenuItem.Click, AddressOf Me.MoveTopRowToHeadersToolStripMenuItemClick
		'
		'moveHeadersToTopRowToolStripMenuItem
		'
		Me.moveHeadersToTopRowToolStripMenuItem.Name = "moveHeadersToTopRowToolStripMenuItem"
		Me.moveHeadersToTopRowToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
		Me.moveHeadersToTopRowToolStripMenuItem.Text = "Move Headers To Top Row"
		AddHandler Me.moveHeadersToTopRowToolStripMenuItem.Click, AddressOf Me.MoveHeadersToTopRowToolStripMenuItemClick
		'
		'iPTVToolStripMenuItem
		'
		Me.iPTVToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.playToolStripMenuItem, Me.checkSelectedLinksToolStripMenuItem, Me.checkLinksToolStripMenuItem, Me.markDuplicateURLsToolStripMenuItem, Me.removeDuplicateURLsToolStripMenuItem, Me.addChannelNumberToolStripMenuItem, Me.markSelectedTemporarilyToolStripMenuItem, Me.removeTemporToolStripMenuItem, Me.copyNamesFromURLToolStripMenuItem, Me.createM3uListFromAFolderToolStripMenuItem, Me.createFolderFromM3UListToolStripMenuItem})
		Me.iPTVToolStripMenuItem.Name = "iPTVToolStripMenuItem"
		Me.iPTVToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
		Me.iPTVToolStripMenuItem.Text = "M&3U"
		'
		'playToolStripMenuItem
		'
		Me.playToolStripMenuItem.Name = "playToolStripMenuItem"
		Me.playToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1
		Me.playToolStripMenuItem.Size = New System.Drawing.Size(349, 22)
		Me.playToolStripMenuItem.Text = "&Play"
		AddHandler Me.playToolStripMenuItem.Click, AddressOf Me.PlayToolStripMenuItemClick
		'
		'checkSelectedLinksToolStripMenuItem
		'
		Me.checkSelectedLinksToolStripMenuItem.Name = "checkSelectedLinksToolStripMenuItem"
		Me.checkSelectedLinksToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.L),System.Windows.Forms.Keys)
		Me.checkSelectedLinksToolStripMenuItem.Size = New System.Drawing.Size(349, 22)
		Me.checkSelectedLinksToolStripMenuItem.Text = "Check Selected Links For Validity"
		AddHandler Me.checkSelectedLinksToolStripMenuItem.Click, AddressOf Me.CheckSelectedLinksToolStripMenuItemClick
		'
		'checkLinksToolStripMenuItem
		'
		Me.checkLinksToolStripMenuItem.Name = "checkLinksToolStripMenuItem"
		Me.checkLinksToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift)  _
						Or System.Windows.Forms.Keys.L),System.Windows.Forms.Keys)
		Me.checkLinksToolStripMenuItem.Size = New System.Drawing.Size(349, 22)
		Me.checkLinksToolStripMenuItem.Text = "Check All Links For Validity"
		AddHandler Me.checkLinksToolStripMenuItem.Click, AddressOf Me.CheckLinksToolStripMenuItemClick
		'
		'markDuplicateURLsToolStripMenuItem
		'
		Me.markDuplicateURLsToolStripMenuItem.Name = "markDuplicateURLsToolStripMenuItem"
		Me.markDuplicateURLsToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D),System.Windows.Forms.Keys)
		Me.markDuplicateURLsToolStripMenuItem.Size = New System.Drawing.Size(349, 22)
		Me.markDuplicateURLsToolStripMenuItem.Text = "Mark Duplicate URLs"
		Me.markDuplicateURLsToolStripMenuItem.ToolTipText = "You should sort your list by URLs first"
		AddHandler Me.markDuplicateURLsToolStripMenuItem.Click, AddressOf Me.MarkDuplicateURLsToolStripMenuItemClick
		'
		'removeDuplicateURLsToolStripMenuItem
		'
		Me.removeDuplicateURLsToolStripMenuItem.Name = "removeDuplicateURLsToolStripMenuItem"
		Me.removeDuplicateURLsToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift)  _
						Or System.Windows.Forms.Keys.D),System.Windows.Forms.Keys)
		Me.removeDuplicateURLsToolStripMenuItem.Size = New System.Drawing.Size(349, 22)
		Me.removeDuplicateURLsToolStripMenuItem.Text = "Remove Duplicate URLs"
		AddHandler Me.removeDuplicateURLsToolStripMenuItem.Click, AddressOf Me.RemoveDuplicateURLsToolStripMenuItemClick
		'
		'addChannelNumberToolStripMenuItem
		'
		Me.addChannelNumberToolStripMenuItem.Name = "addChannelNumberToolStripMenuItem"
		Me.addChannelNumberToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.R),System.Windows.Forms.Keys)
		Me.addChannelNumberToolStripMenuItem.Size = New System.Drawing.Size(349, 22)
		Me.addChannelNumberToolStripMenuItem.Text = "Add Channel Numbers"
		AddHandler Me.addChannelNumberToolStripMenuItem.Click, AddressOf Me.AddChannelNumberToolStripMenuItemClick
		'
		'markSelectedTemporarilyToolStripMenuItem
		'
		Me.markSelectedTemporarilyToolStripMenuItem.Name = "markSelectedTemporarilyToolStripMenuItem"
		Me.markSelectedTemporarilyToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.M),System.Windows.Forms.Keys)
		Me.markSelectedTemporarilyToolStripMenuItem.Size = New System.Drawing.Size(349, 22)
		Me.markSelectedTemporarilyToolStripMenuItem.Text = "Mark Selected Rows Temporarily"
		AddHandler Me.markSelectedTemporarilyToolStripMenuItem.Click, AddressOf Me.MarkSelectedTemporarilyToolStripMenuItemClick
		'
		'removeTemporToolStripMenuItem
		'
		Me.removeTemporToolStripMenuItem.Name = "removeTemporToolStripMenuItem"
		Me.removeTemporToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift)  _
						Or System.Windows.Forms.Keys.M),System.Windows.Forms.Keys)
		Me.removeTemporToolStripMenuItem.Size = New System.Drawing.Size(349, 22)
		Me.removeTemporToolStripMenuItem.Text = "Remove All Temporary Row Markings"
		AddHandler Me.removeTemporToolStripMenuItem.Click, AddressOf Me.RemoveTemporToolStripMenuItemClick
		'
		'copyNamesFromURLToolStripMenuItem
		'
		Me.copyNamesFromURLToolStripMenuItem.Name = "copyNamesFromURLToolStripMenuItem"
		Me.copyNamesFromURLToolStripMenuItem.Size = New System.Drawing.Size(349, 22)
		Me.copyNamesFromURLToolStripMenuItem.Text = "Copy Names From URL to Name Column"
		AddHandler Me.copyNamesFromURLToolStripMenuItem.Click, AddressOf Me.CopyNamesFromURLToolStripMenuItemClick
		'
		'createM3uListFromAFolderToolStripMenuItem
		'
		Me.createM3uListFromAFolderToolStripMenuItem.Name = "createM3uListFromAFolderToolStripMenuItem"
		Me.createM3uListFromAFolderToolStripMenuItem.Size = New System.Drawing.Size(349, 22)
		Me.createM3uListFromAFolderToolStripMenuItem.Text = "Create M3U List From A Folder"
		AddHandler Me.createM3uListFromAFolderToolStripMenuItem.Click, AddressOf Me.CreateM3uListFromAFolderToolStripMenuItemClick
		'
		'createFolderFromM3UListToolStripMenuItem
		'
		Me.createFolderFromM3UListToolStripMenuItem.Name = "createFolderFromM3UListToolStripMenuItem"
		Me.createFolderFromM3UListToolStripMenuItem.Size = New System.Drawing.Size(349, 22)
		Me.createFolderFromM3UListToolStripMenuItem.Text = "Create Folder From M3U List"
		AddHandler Me.createFolderFromM3UListToolStripMenuItem.Click, AddressOf Me.CreateFolderFromM3UListToolStripMenuItemClick
		'
		'helpToolStripMenuItem
		'
		Me.helpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.aboutToolStripMenuItem, Me.tableInfoToolStripMenuItem})
		Me.helpToolStripMenuItem.Name = "helpToolStripMenuItem"
		Me.helpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
		Me.helpToolStripMenuItem.Text = "&Help"
		'
		'aboutToolStripMenuItem
		'
		Me.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem"
		Me.aboutToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
		Me.aboutToolStripMenuItem.Text = "About"
		AddHandler Me.aboutToolStripMenuItem.Click, AddressOf Me.AboutToolStripMenuItemClick
		'
		'tableInfoToolStripMenuItem
		'
		Me.tableInfoToolStripMenuItem.Name = "tableInfoToolStripMenuItem"
		Me.tableInfoToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
		Me.tableInfoToolStripMenuItem.Text = "Table Info"
		AddHandler Me.tableInfoToolStripMenuItem.Click, AddressOf Me.TableInfoToolStripMenuItemClick
		'
		'statusStrip1
		'
		Me.statusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.laFilename, Me.laDelimiter, Me.laStatus, Me.laSelectedCell, Me.laChanged})
		Me.statusStrip1.Location = New System.Drawing.Point(0, 419)
		Me.statusStrip1.Name = "statusStrip1"
		Me.statusStrip1.Size = New System.Drawing.Size(1008, 22)
		Me.statusStrip1.TabIndex = 3
		Me.statusStrip1.Text = "statusStrip1"
		'
		'laFilename
		'
		Me.laFilename.Name = "laFilename"
		Me.laFilename.Size = New System.Drawing.Size(0, 17)
		'
		'laDelimiter
		'
		Me.laDelimiter.Name = "laDelimiter"
		Me.laDelimiter.Size = New System.Drawing.Size(0, 17)
		'
		'laStatus
		'
		Me.laStatus.Name = "laStatus"
		Me.laStatus.Size = New System.Drawing.Size(0, 17)
		'
		'laSelectedCell
		'
		Me.laSelectedCell.Name = "laSelectedCell"
		Me.laSelectedCell.Size = New System.Drawing.Size(0, 17)
		'
		'laChanged
		'
		Me.laChanged.Name = "laChanged"
		Me.laChanged.Size = New System.Drawing.Size(0, 17)
		'
		'cmColumnName
		'
		Me.cmColumnName.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
		Me.cmColumnName.FormattingEnabled = true
		Me.cmColumnName.Location = New System.Drawing.Point(594, 25)
		Me.cmColumnName.Name = "cmColumnName"
		Me.cmColumnName.Size = New System.Drawing.Size(133, 21)
		Me.cmColumnName.TabIndex = 4
		'
		'cmSearchFor
		'
		Me.cmSearchFor.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
		Me.cmSearchFor.FormattingEnabled = true
		Me.cmSearchFor.Location = New System.Drawing.Point(733, 25)
		Me.cmSearchFor.Name = "cmSearchFor"
		Me.cmSearchFor.Size = New System.Drawing.Size(182, 21)
		Me.cmSearchFor.TabIndex = 5
		'
		'bnSearch
		'
		Me.bnSearch.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
		Me.bnSearch.Location = New System.Drawing.Point(921, 23)
		Me.bnSearch.Name = "bnSearch"
		Me.bnSearch.Size = New System.Drawing.Size(75, 23)
		Me.bnSearch.TabIndex = 6
		Me.bnSearch.Text = "Search"
		Me.toolTip1.SetToolTip(Me.bnSearch, "To clear search, press CTRL and click on search. Or search for empty line. You ca"& _ 
				"n disable sort from EDIT menu or by holding SHIFT.")
		Me.bnSearch.UseVisualStyleBackColor = true
		AddHandler Me.bnSearch.Click, AddressOf Me.BnSearchClick
		'
		'doNotFilterDroppedMultipleFilesOnProgramToolStripMenuItem
		'
		Me.doNotFilterDroppedMultipleFilesOnProgramToolStripMenuItem.Checked = true
		Me.doNotFilterDroppedMultipleFilesOnProgramToolStripMenuItem.CheckOnClick = true
		Me.doNotFilterDroppedMultipleFilesOnProgramToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
		Me.doNotFilterDroppedMultipleFilesOnProgramToolStripMenuItem.Name = "doNotFilterDroppedMultipleFilesOnProgramToolStripMenuItem"
		Me.doNotFilterDroppedMultipleFilesOnProgramToolStripMenuItem.Size = New System.Drawing.Size(459, 22)
		Me.doNotFilterDroppedMultipleFilesOnProgramToolStripMenuItem.Text = "Do not filter dropped multiple files on program"
		AddHandler Me.doNotFilterDroppedMultipleFilesOnProgramToolStripMenuItem.Click, AddressOf Me.DoNotFilterDroppedMultipleFilesOnProgramToolStripMenuItemClick
		'
		'MainForm
		'
		Me.AcceptButton = Me.bnSearch
		Me.AllowDrop = true
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(1008, 441)
		Me.Controls.Add(Me.bnSearch)
		Me.Controls.Add(Me.cmSearchFor)
		Me.Controls.Add(Me.cmColumnName)
		Me.Controls.Add(Me.statusStrip1)
		Me.Controls.Add(Me.dataGridView1)
		Me.Controls.Add(Me.menuStrip1)
		Me.MainMenuStrip = Me.menuStrip1
		Me.Name = "MainForm"
		Me.Text = "csvEdit"
		AddHandler FormClosing, AddressOf Me.MainFormFormClosing
		AddHandler Load, AddressOf Me.MainFormLoad
		AddHandler DragDrop, AddressOf Me.MainFormDragDrop
		AddHandler DragEnter, AddressOf Me.MainFormDragEnter
		CType(Me.dataGridView1,System.ComponentModel.ISupportInitialize).EndInit
		Me.contextMenuStripContext.ResumeLayout(false)
		Me.menuStrip1.ResumeLayout(false)
		Me.menuStrip1.PerformLayout
		Me.statusStrip1.ResumeLayout(false)
		Me.statusStrip1.PerformLayout
		Me.ResumeLayout(false)
		Me.PerformLayout
	End Sub
	Private doNotFilterDroppedMultipleFilesOnProgramToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private replaceSpecialCharactersWhenConvertingXMLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private doubleClickCellToPlayURLInM3UListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private validateM3UCellValuesWhenSavingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private setUserAgentWhenStreamingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private openInNewWindowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private toolTip1 As System.Windows.Forms.ToolTip
	Private searchMovesMatchingRowsToTheTopToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private bnSearch As System.Windows.Forms.Button
	Private cmSearchFor As System.Windows.Forms.ComboBox
	Private cmColumnName As System.Windows.Forms.ComboBox
	Private copyNamesFromURLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private createFolderFromM3UListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private createM3uListFromAFolderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private pasteAddToTheBottomRowsWithHeaderInformationM3UToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private bottomPasteRowsWithHeaderInformationM3UToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private copyWithHeaderInformationM3UToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private toolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
	Private tableInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private removeTemporToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private markSelectedTemporarilyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private addChannelNumberToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private markDuplicateURLsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private removeDuplicateURLsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private checkSelectedLinksToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private checkLinksToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private pasteNonEmptyValuesInMultipleCellsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private pasteSingleValueInMultipleCellsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private moveColumnToTheLeftToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private moveColumnToTheRightToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private toolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
	Private moveTopRowToHeadersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private moveHeadersToTopRowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private toolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
	Private changeColumnTitleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private playToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private iPTVToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private laChanged As System.Windows.Forms.ToolStripStatusLabel
	Private deleteToolStripMenuItemFORMMENU As System.Windows.Forms.ToolStripMenuItem
	Private pasteToolStripMenuItemFORMMENU As System.Windows.Forms.ToolStripMenuItem
	Private cutToolStripMenuItemFORMMENU As System.Windows.Forms.ToolStripMenuItem
	Private deleteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private pasteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private copyToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
	Private cutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private contextMenuStripContext As System.Windows.Forms.ContextMenuStrip
	Private toolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
	Private changeDelimiterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private laSelectedCell As System.Windows.Forms.ToolStripStatusLabel
	Private removeColumnToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private removeRowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private insertColumnToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private insertRowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private rowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private columnToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private insertToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private openInNotepadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private reloadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private newToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private saveAsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private aboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private helpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private laStatus As System.Windows.Forms.ToolStripStatusLabel
	Private copyToolStripMenuItemFROMMENU As System.Windows.Forms.ToolStripMenuItem
	Private editToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private quitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private clearToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private laDelimiter As System.Windows.Forms.ToolStripStatusLabel
	Private laFilename As System.Windows.Forms.ToolStripStatusLabel
	Private statusStrip1 As System.Windows.Forms.StatusStrip
	Private saveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private openToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private fileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private menuStrip1 As System.Windows.Forms.MenuStrip
	Private dataGridView1 As System.Windows.Forms.DataGridView
	

	

End Class

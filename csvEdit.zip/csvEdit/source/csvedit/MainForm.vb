'
' Created by SharpDevelop.
' User: bojan
'
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'

'part1 goes above class
Imports System.Linq
Imports System.Reflection
Imports System.Xml 'xml reader
Imports System.Text.RegularExpressions ' remove illegal chars


Public Partial Class MainForm
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	'part2 goes inside class
	Public Sub EnableDoubleBuffered(ByVal dgv As DataGridView)
		Dim dgvType As Type = dgv.[GetType]()
		Dim pi As PropertyInfo = dgvType.GetProperty("DoubleBuffered",BindingFlags.Instance Or BindingFlags.NonPublic)
		pi.SetValue(dgv, True, Nothing)
	End Sub
	
	' ************ version info ************
	
	Dim stProgramAndVersion As String ="csvEdit Esmeralda 2024-01-06-1"
	Dim stWebSite As String = "dbojan.github.io"
	
	
	Dim arArguments As String() = Environment.GetCommandLineArgs
	'rem in case there is no info from settings.txt
	
	Dim stFfprobeLocation As String = "ffprobe in d:/apps/ffmpeg/ffprobe.exe or in settings.txt"
	Dim stMpvLocation As String = "mpv in d:/apps/mpv/mpv.exe or in settings.txt"
	
	Dim stTestUsing As String = "ffprobe"
	Dim stUserAgent As String = ""
	
	
	Sub MainFormLoad(sender As Object, e As EventArgs)
		'part3 goes in main form load
		EnableDoubleBuffered(dataGridView1)
		
		
		
		
		If System.IO.File.Exists("d:/apps/ffmpeg/ffprobe.exe") Then
			stFfprobeLocation = "d:/apps/ffmpeg/ffprobe.exe"
		End If
		
		
		
		If System.IO.File.Exists("d:/apps/mpv/mpv.exe") Then
			stMpvLocation = "d:/apps/mpv/mpv.exe"
		End If
		
		
		
		Dim stSettingsFile As String = System.IO.Path.Combine(Application.StartupPath, "settings.txt")
		Dim arSettings() As String
		
		If System.IO.File.Exists(stSettingsFile) Then
			arSettings  = IO.File.ReadAllLines(stSettingsFile)
			
			If Array.IndexOf(arSettings,"ffprobe=") <> -1 Then
				stFfprobeLocation=arSettings(Array.IndexOf(arSettings,"ffprobe=")+1)
			End If
			
			If Array.IndexOf(arSettings,"mpv=") <> -1 Then
				stMpvLocation=arSettings(Array.IndexOf(arSettings,"mpv=")+1)
			End If
			
			
		Else
			laStatus.Text = "settings.txt is missing"
		End If
		
		laStatus.Text=stProgramAndVersion
		
		
		If System.IO.File.Exists(stSettingsFile) Then
			
			
			If Not System.IO.File.Exists(stFfprobeLocation) Then
				laStatus.Text  = stFfprobeLocation & " Warning: ffprobe program is missing, please edit settings.txt"
			End If
			
			If Not System.IO.File.Exists(stMpvLocation) Then
				laStatus.Text  = stMpvLocation & " Warning: mpv program is missing, please edit settings.txt"
			End If
			
			
		End If
		
		' exe, 				index = 0, total length 1, length is same as number of elements
		' first argument, 	index = 1, total length 2
		' second argument, 	index = 2, total length 3
		
		If arArguments.Length > 1 Then ' length 2 or more, at least first argument
			
			If System.IO.File.Exists( arArguments(1) ) 'one item, file. probably textual/m3u/csv...
				
				laFilename.Text=arArguments(1) 'open it
				fnOpencsv
				
			ElseIf System.IO.Directory.Exists(  arArguments(1) ) Then 'one item, but directory. create simple list of files from inside dir
				
				Dim liFiles As New List(Of String) 
				liFiles = System.IO.Directory.GetFiles( arArguments(1), "*", System.IO.SearchOption.AllDirectories).ToList
				fnCreateFilelist(liFiles) 'send simple list of files to fn, to create real list of files
				
			End If
			
		End If
		
		If arArguments.Length > 2  Then ' length 3 or more, save as filename present too
			laFilename.Text=arArguments(2) ' save as filename has index 2, not 3 :)
			If System.IO.Directory.Exists(laFilename.Text) Then
				fnCreateFolderFromM3U(laFilename.Text) 'save m3ulist as folder
			Else
				
				'should we sort?
				
				
				If laFilename.Text.Substring(0,4) = "sort" And laFilename.Text.IndexOf("_")  <> -1 Then
					
					'sort by column number
					Dim intConverted As Integer
					Dim stInterValue As String = laFilename.Text.Substring(   4, laFilename.Text.IndexOf("_")-4    )'get value between sort and _
					If Int32.TryParse(stInterValue, intConverted) Then 'is it integer32 ? result if yes in intConverted
						'sort by column number, starting from 1
						
						Dim inSearchColumnIndex As Integer = intConverted -1 'cause we start with 0
						
						dataGridView1.Sort(dataGridView1.Columns(inSearchColumnIndex),System.ComponentModel.ListSortDirection.Ascending)
						
					Else
						
						'sort by column name
						Dim inSearchColumnIndex As Integer
						For i = 0 To dataGridView1.Columns.Count - 1
							If dataGridView1.Columns(i).Name.ToLower = stInterValue Then
								inSearchColumnIndex = i
							End If
						Next
						
						
						dataGridView1.Sort(dataGridView1.Columns(inSearchColumnIndex),System.ComponentModel.ListSortDirection.Ascending)
						
						
					End If
					
					
					
					
					
					
				End If
				
				
				
				
				
				
				fnSavecsv 'regular save
			End If
			
			'System.Console.WriteLine("Converted.")
			Me.Close
		End If
		
		cmSearchFor.Items.Add("")
		laStatus.Text = "Drag and drop files on this window to open them. Hold SHIFT to open in a new window."
	End Sub
	
	
	
	Sub fnOpenInNewWindow(stFileNew As String )
		Dim prStart  As New System.Diagnostics.Process
		
		prStart.StartInfo.FileName = Application.ExecutablePath
		prStart.StartInfo.WorkingDirectory = Application.StartupPath 'System.IO.Path.GetDirectoryName(stFfprobeLocation)
		
		prStart.StartInfo.Arguments = chr(34) & stFileNew & Chr(34)
		prStart.Start
	End Sub
	
	
	Sub fnCut
		
		fnCopy
		fnDelete
		
		laStatus.Text="Cut selected items"
	End Sub
	
	
	
	
	Sub fnCopy
		If dataGridView1.Rows.Count < 1 Then
			MsgBox("No rows?")
			Exit Sub
		End If
		'SendKeys.Send("^c")
		'copy
		'for pasting in say excel. unselected cells will be pasted as empty! deleting value in excel
		Me.dataGridView1.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText
		Clipboard.SetDataObject(Me.dataGridView1.GetClipboardContent)
		
		laStatus.Text="Copied selected items"
	End Sub
	
	
	
	Sub PasteNonEmptyValuesInMultipleCellsToolStripMenuItemClick(sender As Object, e As EventArgs)
		
		Dim liCopied As New List(Of String)
		Dim stClipboard As String = Clipboard.GetText
		
		'no selected
		If dataGridView1.SelectedCells.Count = 0 Then
			Exit Sub
		End If
		
		If stClipboard.Length = 0 Then
			'Exit Sub 'empty? 
		End If
		
		
		Dim stCurrentColumnIndex, stCurrentRowIndex As Integer
		'stCurrentColumnIndex = DataGridView1.CurrentCell.ColumnIndex
		stCurrentRowIndex = 0
		
		For Each stRow In Strings.Split(stClipboard,Environment.NewLine)
			stCurrentColumnIndex = 0
			For Each stCell	In Strings.Split(stRow, vbTab)
				If Not String.IsNullOrEmpty(stCell) And Not String.IsNullOrWhiteSpace(stCell) Then
					liCopied.Add(stCell)
				End If
				
				stCurrentColumnIndex = stCurrentColumnIndex + 1
			Next
			stCurrentRowIndex = stCurrentRowIndex+1
		Next
		
		If liCopied.Count = 0 Then
			Exit Sub
		End If
		
		
		Dim inPasteCounter As Integer = 0
		'have to be in order
		For i As Integer = 0 To dataGridView1.Rows.Count-1
			For j As Integer = 0 To dataGridView1.Columns.Count-1
				If dataGridView1.Rows(i).Cells(j).Selected Then
					
					
					If inPasteCounter <= liCopied.Count-1 ' no overflow
						If Not dataGridView1.Rows(i).Index <=dataGridView1.Rows.Count-2 Then '2 because editing row
							dataGridView1.Rows.Add(1)
						End If
						
						dataGridView1.Rows(i).Cells(j).Value=liCopied(inPasteCounter)
						inPasteCounter = inPasteCounter + 1
					Else
						Exit Sub
					End If
					
				End If
			Next
		Next
		
	End Sub
	
	
	Sub PasteSingleValueInMultipleCellsToolStripMenuItemClick(sender As Object, e As EventArgs)
		
		
		'Paste first value from the clipboard to all selected cells
		Dim stClipboard As String 
		stClipboard = Clipboard.GetText
		stClipboard=  Strings.Split(stClipboard,Environment.NewLine)(0)
		stClipboard = Strings.Split(stClipboard,vbCr)(0)'maybe disable this?
		stClipboard = Strings.Split(stClipboard,vbLf)(0)'maybe disable this?
		stClipboard = Strings.Split(stClipboard,vbTab)(0)
		
		'no selected
		If dataGridView1.SelectedCells.Count = 0 Then
			Exit Sub
		End If
		
		If stClipboard.Length = 0 Then
			'Exit Sub 'empty? 
		End If
		
		
		'have to be in order
		For i As Integer = 0 To dataGridView1.Rows.Count-1
			For j As Integer = 0 To dataGridView1.Columns.Count-1
				If dataGridView1.Rows(i).Cells(j).Selected Then
					
					If Not dataGridView1.Rows(i).Index <=dataGridView1.Rows.Count-2 Then '2 because editing row
						dataGridView1.Rows.Add(1)
					End If
					
					dataGridView1.Rows(i).Cells(j).Value=stClipboard
				End If
			Next
		Next
		
		
		
	End Sub
	
	Sub fnPaste
		
		Dim stClipboard As String = Clipboard.GetText
		
		'no selected
		If dataGridView1.SelectedCells.Count = 0 Then
			Exit Sub
		End If
		
		If stClipboard.Length = 0 Then
			'Exit Sub 'empty? 
		End If
		
		
		Dim stCurrentColumnIndex, stCurrentRowIndex As Integer
		'stCurrentColumnIndex = DataGridView1.CurrentCell.ColumnIndex
		stCurrentRowIndex = DataGridView1.CurrentCell.RowIndex
		
		For Each stRow In Strings.Split(stClipboard,Environment.NewLine)
			stCurrentColumnIndex = DataGridView1.CurrentCell.ColumnIndex 're initialize after new row
			For Each stCell	In Strings.Split(stRow, vbTab)
				
				If Not stCurrentColumnIndex <= dataGridView1.Columns.Count-1 Then 'because editing row
					dataGridView1.Columns.Add("Column","Column")
				End If
				
				If Not stCurrentRowIndex <=dataGridView1.Rows.Count-2 Then '2 because editing row
					dataGridView1.Rows.Add(1)
				End If
				If stCurrentColumnIndex <= dataGridView1.Columns.Count-1 And stCurrentRowIndex <=dataGridView1.Rows.Count-1 Then
					dataGridView1.Rows(stCurrentRowIndex).Cells(stCurrentColumnIndex).Value = stCell
					stCurrentColumnIndex = stCurrentColumnIndex + 1
					
				End If	
			Next
			stCurrentRowIndex = stCurrentRowIndex+1
		Next
		
		
	End Sub
	
	
	Sub fnDelete
		
		For Each cell As DataGridViewCell In dataGridView1.SelectedCells
			cell.Value=""
		Next
		
		laStatus.Text="Deleted selected items"
	End Sub
	
	Sub OpenInNewWindowToolStripMenuItemClick(sender As Object, e As EventArgs)
		
		dataGridView1.EndEdit
		Dim openFileDialog1 As New OpenFileDialog()
		
		If OpenFileDialog1.ShowDialog <> System.Windows.Forms.DialogResult.Cancel Then
			fnOpenInNewWindow(OpenFileDialog1.FileName)
		End If
		
	End Sub
	
	
	Sub OpenToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		
		Dim openFileDialog1 As New OpenFileDialog()
		Dim boPressedShift As Boolean = False
		
		If My.Computer.Keyboard.ShiftKeyDown Then 'if shift pressed open in new window
			boPressedShift = True
		End If
		
		
		If boPressedShift = True Or My.Computer.Keyboard.ShiftKeyDown
		Else
			fnClosingDataGridView
		End If
		
		If OpenFileDialog1.ShowDialog <> System.Windows.Forms.DialogResult.Cancel Then
			If boPressedShift = True Or My.Computer.Keyboard.ShiftKeyDown Then
				fnOpenInNewWindow(OpenFileDialog1.FileName)
				boPressedShift = False
			Else
				laFilename.Text = OpenFileDialog1.FileName
				fnOpencsv
			End If
			
		End If
		
		
	End Sub
	
	
	
	Sub fnOpencsv
		
		'coming from formload, or file-open
		'lafilename and ladelimiter must be set
		laStatus.Text = "Please wait, loading file ... "
		laSelectedCell.Text = ""
		
		Update
		dataGridView1.EndEdit
		
		
		Dim lines() As String = IO.File.ReadAllLines(laFilename.Text)
		Dim stFirstline As String = lines(0)
		
		laDelimiter.Text=""
		
		If stFirstline.Contains(vbTab) Then
			laDelimiter.Text=vbTab
		ElseIf stFirstline.Contains("|")
			laDelimiter.Text="|"
		ElseIf stFirstline.Contains(";")
			laDelimiter.Text=";"
		Else
			laDelimiter.Text=","
		End if
		
		dataGridView1.Rows.Clear
		dataGridView1.Columns.Clear
		
		
		
		'open
		'm3u or m3u8
		If System.IO.Path.GetExtension(laFilename.Text).ToLower = ".m3u" Or System.IO.Path.GetExtension(laFilename.Text).ToLower = ".m3u8" Then
			laDelimiter.Text=vbTab'first line is often full of ,
			
			
			Dim streamReader1 As System.IO.StreamReader
			streamReader1 = My.Computer.FileSystem.OpenTextFileReader(laFilename.Text)
			Dim stFullLineRead As String
			
			Dim liHeaders As New List(Of String)
			Dim liLines As New List(Of String)
			Dim stSearch As String
			Dim arTemp() As String
			Dim boAddName As Boolean = False
			
			'add headers
			
			Do
				stFullLineRead = streamReader1.ReadLine()
				
				'parse line 
				Do
					
					If String.IsNullOrEmpty(stFullLineRead) Then
						Exit Do
					End If
					
					' check all tags
					
					stSearch = "#EXTM3U" ' single line for all list
					If stFullLineRead.Contains(stSearch) Then
						suCheckAddColumn(stSearch,stSearch) 
						Exit Do 'one line type, exit
					End If
					
					
					stSearch = "#EXTINF"
					If stFullLineRead.Contains(stSearch) Then
						stSearch = "#EXTINF"      
						suCheckAddColumn(stSearch,stSearch) 
						
						If stFullLineRead.Contains(",") Then ' remove name, must be last, could have " "
							
							'nameValue = stFullLineRead.Substring(stFullLineRead.LastIndexOf(",") + 1) ' last part, get the value
							stFullLineRead = stFullLineRead.Substring(0, stFullLineRead.LastIndexOf(","))' first part, remove all after ,
							
							boAddName = True ' add name column header later, after extinf tag, for cosmetic purposes
							
						End If
						
						If stFullLineRead.Contains(" ") ' else no tags like tag=value? removed name, tags usually dont have " ". this is to remove "#extinf:xx "
							arTemp = split(stFullLineRead," ", 2) 'get "#EXTINF:xx "
							stFullLineRead = arTemp(1)'all after ':xxx ' ....
							arTemp = Nothing
						End If
						
						'parse rest of the tags, other than the name after "," at the end of the line
						If stFullLineRead.Contains("=") Then 
							
							stFullLineRead = stFullLineRead.Replace(""" ","""__end__") ' replace '" ' with '"__end__'. Add tags to headers
							'last tag before , has no space ('",' not '" ')but that is ok. it is last tag so it does not need to have __end__ appended
							
							arTemp = split(stFullLineRead,"__end__")
							
							'arTemp = stFullLineRead.Split({"__end__","="}, StringSplitOptions.None) 'do both splits end and = . we are not doing this now
							
							For Each item In arTemp
								If item.Contains("=") Then
									arTemp = split(item,"=",2)'max 2 in case there are more = . there should not be, though
									arTemp(0)=arTemp(0).Trim
									
									'MessageBox.Show("--"& arTemp(0) & "--")
									stSearch = "#EXTINF" & arTemp(0)
									suCheckAddColumn(stSearch,stSearch) 
									
									arTemp = Nothing
								End If
								
							Next
						End If
						
						
						
						If boAddName = True Then ' make sure name column header is after extinf tags, cosmetic purposes only. displayindex only changes display, not for real
							stSearch = "Name"
							suCheckAddColumn(stSearch,stSearch) 
							boAddName = False
						End If
						
						
						
						Exit Do 'last thing in channel info
						
					End If 'end extinf
					
					
					
					
					stSearch = "#PLAYLIST"
					If stFullLineRead.Contains(stSearch) Then
						suCheckAddColumn(stSearch,stSearch) 
						Exit Do
					End If
					
					
					stSearch = "#EXT" ' unknow ext tag
					If stFullLineRead.Contains(stSearch) Then
						
						If stFullLineRead.Contains(":") Then
							arTemp = split(stFullLineRead,":")
							suCheckAddColumn(arTemp(0),arTemp(0)) 
							arTemp = Nothing
						ElseIf stFullLineRead.Contains(" ") Then' no :, maybe " " ?
							arTemp = split(stFullLineRead," ")
							suCheckAddColumn(arTemp(0),arTemp(0)) 
							arTemp = Nothing
						Else
							suCheckAddColumn(stFullLineRead.Trim,stFullLineRead.Trim) ' no :, no " "
						End If
						
						Exit Do
					End If	
					
					
					stSearch = "#"
					If stFullLineRead.Contains(stSearch) Then
						If stFullLineRead.Substring(0,1) = "#" Then 'has to be at the start, some urls have # in them
							suCheckAddColumn("Comment","Comment") 
							Exit Do
						End If
					End If
					
					'stSearch = "://"
					'If stFullLineRead.Contains(stSearch) Or stFullLineRead.Contains(".") Then 'url or filename?
					suCheckAddColumn("URL","URL") ' none of the above? add url. unless it's empty which is checked at the top with the String.IsNullOrEmpty(stFullLineRead) 
					Exit Do
					'End If
					'Exit Do
				Loop 
				
				
			Loop Until stFullLineRead Is Nothing
			
			
			'add content
			streamReader1.Close() 'remove last crlf
			
			
			
			streamReader1 = My.Computer.FileSystem.OpenTextFileReader(laFilename.Text)
			
			Dim inLineCounter As Integer = 0
			Do
				stFullLineRead = streamReader1.ReadLine()
				
				'parse line 
				
				Do
					
					If String.IsNullOrEmpty(stFullLineRead) Then
						Exit Do
					End If
					
					
					stSearch = "#EXTM3U" ' single line for all list
					If stFullLineRead.Contains(stSearch) Then
						
						'suCheckAddColumn(stSearch,stSearch)
						'dataGridView1.Rows(inLineCounter).Cells(dataGridView1.Columns.item(stSearch).Index).Value = stFullLineRead ' also works, but is longer
						'MessageBox.Show("add inside m3u")				
						dataGridView1.Rows.Add()'single in a row
						dataGridView1.Rows(inLineCounter).Cells(dataGridView1.Columns(stSearch).Index).Value = stFullLineRead
						
						
						inLineCounter = inLineCounter + 1
						
						Exit Do 'one line in whole file, exit do
					End If
					
					
					stSearch = "#EXTINF"
					If stFullLineRead.Contains(stSearch) Then
						'MessageBox.Show("add inside extinf")		
						dataGridView1.Rows.Add()'need new row for extinf
						
						'suCheckAddColumn(stSearch,stSearch) 'check "#EXTINF"
						
						
						If stFullLineRead.Contains(",") Then ' remove name, must be last. name can also have spaces so has to be processed adding column headers first
							
							stSearch = "Name"
							'suCheckAddColumn(stSearch,stSearch) 
							
							'nameValue = stFullLineRead.Substring(stFullLineRead.LastIndexOf(",") + 1) ' last part, get the value
							
							dataGridView1.Rows(inLineCounter).Cells(dataGridView1.Columns(stSearch).Index).Value = stFullLineRead.Substring(stFullLineRead.LastIndexOf(",") + 1).Trim
							
							'used in previous version get last item in array: arTemp(arTemp.Length-1).Trim
							
							stFullLineRead = stFullLineRead.Substring(0, stFullLineRead.LastIndexOf(","))' first part, remove all after ,
							
							'MessageBox.Show("2-" & stFullLineRead)
						End If
						
						
						If stFullLineRead.Contains(" ")
							arTemp = split(stFullLineRead," ", 2) 'get "#EXTINF:xx "
							
							stSearch = "#EXTINF"      
							'suCheckAddColumn(stSearch,stSearch) 
							dataGridView1.Rows(inLineCounter).Cells(dataGridView1.Columns(stSearch).Index).Value = arTemp(0)
							stFullLineRead = arTemp(1)'all after "#EXTINF:xx "
							arTemp = Nothing
						Else ' no space, no tags? add all
							stSearch = "#EXTINF"      
							'suCheckAddColumn(stSearch,stSearch) 
							dataGridView1.Rows(inLineCounter).Cells(dataGridView1.Columns(stSearch).Index).Value = stFullLineRead
							Exit Do 'exit, no tags
						End If
						
						
						
						
						'parse rest of the tags
						
						'MessageBox.Show(stFullLineRead)
						
						If stFullLineRead.Contains("=") Then
							stFullLineRead = stFullLineRead.Replace(""" ","""__end__") ' replace '" ' with '"__end__'. Add tags to headers
							'MessageBox.Show("3-" & stFullLineRead)
							arTemp = split(stFullLineRead,"__end__")
							
							'arTemp = stFullLineRead.Split({"__end__","="}, StringSplitOptions.None) 'do both splits end and = . we are not doing this now
							
							
							For Each item In arTemp
								If item.Contains("=") Then
									arTemp = split(item,"=",2)'max 2 in case there are more = . there should not be, though
									arTemp(0)=arTemp(0).Trim
									
									'MessageBox.Show("--"& arTemp(0) & "--")
									
									stSearch = "#EXTINF" & arTemp(0)
									'suCheckAddColumn(stSearch,stSearch) 
									
									dataGridView1.Rows(inLineCounter).Cells(dataGridView1.Columns(stSearch).Index).Value = arTemp(1).Trim
									
									arTemp = Nothing
								End If
								
							Next
						End If
						
						
						
						
						Exit Do
					End If
					
					
					stSearch = "#PLAYLIST"
					If stFullLineRead.Contains(stSearch) Then
						'suCheckAddColumn(stSearch,stSearch) 
						dataGridView1.Rows(inLineCounter).Cells(dataGridView1.Columns(stSearch).Index).Value = stFullLineRead
						Exit Do
					End If
					
					
					stSearch = "#EXT" ' none of the known ones, but it is #ext
					If stFullLineRead.Contains(stSearch) Then
						
						If stFullLineRead.Contains(":") Then
							arTemp = split(stFullLineRead,":")
							'suCheckAddColumn(arTemp(0),arTemp(0)) 
							dataGridView1.Rows(inLineCounter).Cells(dataGridView1.Columns(arTemp(0)).Index).Value = stFullLineRead
							arTemp = Nothing
						ElseIf stFullLineRead.Contains(" ") Then' no :, maybe " " ?
							arTemp = split(stFullLineRead," ")
							'suCheckAddColumn(arTemp(0),arTemp(0)) 
							dataGridView1.Rows(inLineCounter).Cells(dataGridView1.Columns(arTemp(0)).Index).Value = stFullLineRead
							arTemp = Nothing
						Else
							'suCheckAddColumn(stFullLineRead,stFullLineRead) ' no :, no " "
							dataGridView1.Rows(inLineCounter).Cells(dataGridView1.Columns(arTemp(0)).Index).Value = stFullLineRead
						End If
						
						
						Exit Do
					End If
					
					
					
					
					stSearch = "#"
					If stFullLineRead.Contains(stSearch) Then
						If stFullLineRead.Substring(0,1) = "#" Then 'has to be at the start, some urls have # in them
							'suCheckAddColumn("Comment","Comment")
							dataGridView1.Rows(inLineCounter).Cells(dataGridView1.Columns("Comment").Index).Value = stFullLineRead
							Exit Do
						End If
					End If
					
					'	stSearch = "://"
					'	If stFullLineRead.Contains(stSearch) Then
					'suCheckAddColumn("URL","URL") 
					'		dataGridView1.Rows(inLineCounter).Cells(dataGridView1.Columns("URL").Index).Value = stFullLineRead
					'		inLineCounter = inLineCounter + 1 ' last data in m3u for the single channel. or should be, moving on to the next channel
					
					'		Exit Do
					
					'	End If
					
					'filename?
					'no match? add url?
					
					If inLineCounter = dataGridView1.Rows.Count -1 Then 'empty row, only data for this channel/mp3 file is filename
						dataGridView1.Rows.Add()
					End If
					dataGridView1.Rows(inLineCounter).Cells(dataGridView1.Columns("URL").Index).Value = stFullLineRead.Trim
					inLineCounter = inLineCounter + 1 ' last data in m3u for the single channel. or should be, moving on to the next channel
					
					Exit Do
				Loop
				
				
				
			Loop Until stFullLineRead Is Nothing
			
			'dataGridView1.Rows.RemoveAt(dataGridView1.RowCount-2) 'remove empty line at the end
			'dataGridView1.AllowUserToAddRows=True
			streamReader1.Close() 'remove last crlf
			
			
			'end open m3u*
			
			
			'open xml
		ElseIf System.IO.Path.GetExtension(laFilename.Text).ToLower = ".xml"  Then
			
			Dim inRowCount As Integer = 0
			Dim inColumCount As Integer = 0
			
			' Create an XML reader.
			Using reader As XmlReader = XmlReader.Create(laFilename.Text)
				While reader.Read()
					' Check for start elements.
					If reader.IsStartElement() Then
						
						' element or article element.
						If reader.Name = "Row" Then
							inRowCount = inRowCount +1
							inColumCount = 0
							If dataGridView1.Columns.Count = 0 Then
								DataGridView1.Columns.Add("Column" & inColumCount + 1, "Column" & inColumCount + 1)			
							End If
							dataGridView1.Rows.Add(1)
							
							'   MessageBox.Show("Start  element.")
							
						ElseIf reader.Name = "Cell" Then
							'	MessageBox.Show("Start <article> element.")
							
						ElseIf reader.Name = "Data" Then
							'  MessageBox.Show("Start <article> element.")
							
							' Text data.
							If reader.Read() Then
								
								inColumCount = inColumCount +1
								'MessageBox.Show(inRowCount & " " & inColumCount & " " & reader.Value )
								
								'MessageBox.Show(dataGridView1.Columns.Count)
								If  inRowCount = 1 And inColumCount <>1 Then
									DataGridView1.Columns.Add("Column" & inColumCount + 1, "Column" & inColumCount + 1)			
								End If
								
								'check if string is empty or it will show error, replace special chars when opening xml, if option is enabled in menu
								If Not String.IsNullOrEmpty(reader.Value) Andalso replaceSpecialCharactersWhenConvertingXMLToolStripMenuItem.Checked = True And reader.Value.ToString.Length>0
									dataGridView1.Rows(inRowCount-1).Cells(inColumCount-1).Value = reader.Value.Replace("&lt;" , "<").Replace("&gt;" , ">").Replace("&quot;" , Chr(34) ).Replace("&apos;" , "'").Replace("&amp;" , "&")
								Else
									dataGridView1.Rows(inRowCount-1).Cells(inColumCount-1).Value = reader.Value
									
								End If
								
								
							End If
							
						End If
						
						
					End If
				End While
			End Using
			
			
			
			
			
			
			
			
			
			
			
			
			
		Else
			
			
			'open else (csv, tsv, txt ...)
			
			'if tab
			If laDelimiter.Text = vbTab Then 'textfield parser skips empty tab delimited lines, so we do not use it here .... 
				
				'dataGridView1.AllowUserToAddRows=false
				Dim streamReader1 As System.IO.StreamReader
				streamReader1 = My.Computer.FileSystem.OpenTextFileReader(laFilename.Text)
				Dim stFullLineRead As String
				
				Dim arLine() As String 
				Do
					stFullLineRead = streamReader1.ReadLine()
					
					
					If stFullLineRead Is Nothing Then 
						Exit Do
					End If
					
					
					
					arLine = Split(stFullLineRead, laDelimiter.Text)
					
					If dataGridView1.Columns.Count = 0 Then ' add columns if no columns
						For i = 0 To arLine.Length - 1
							DataGridView1.Columns.Add("Column" & i + 1, "Column" & i + 1)
						Next
					End If
					
					Me.DataGridView1.Rows.Add(arLine)
				Loop Until stFullLineRead Is Nothing
				
				
				'dataGridView1.Rows.RemoveAt(dataGridView1.RowCount-2) 'remove empty line at the end ?
				'dataGridView1.AllowUserToAddRows=True
				streamReader1.Close() 'remove last crlf
				
				
			Else 'not tab
				
				Dim TextFieldParser1 As New Microsoft.VisualBasic.FileIO.TextFieldParser(laFilename.Text) 'but needed for , delimited, with , inside cells
				TextFieldParser1.Delimiters = New String() {laDelimiter.Text}
				While Not TextFieldParser1.EndOfData
					Dim Row1 As String() = TextFieldParser1.ReadFields()
					If DataGridView1.Columns.count = 0 Then 'no columns yet, add empty columns
						Dim i As Integer
						For i = 0 To Row1.Length - 1
							DataGridView1.Columns.Add("Column" & i + 1, "Column" & i + 1)
						Next
					End If
					DataGridView1.Rows.Add(Row1)
				End While
				
			End If
			'end vbtab delimiter
			
			
		End If
		'end open
		
		
		'add column names and order numbers(starting from 1), to search combobox
		If  dataGridView1.Columns.Count  > 0 Then 
			cmColumnName.Items.Clear
			For x = 0 To  dataGridView1.Columns.Count-1 
				If cmColumnName.FindString( dataGridView1.Columns(x).Name ) = -1 Then 'if column name not in seach box, add it
					cmColumnName.Items.Add( dataGridView1.Columns(x).Name )
				End If
			Next
			
			
			For x = 0 To  dataGridView1.Columns.Count-1 
				If cmColumnName.FindString( x+1 ) = -1 Then 'if column number not in seach box, add it ' use numbers instead column name, starting with 1
					cmColumnName.Items.Add( x+1 )
				End If
			Next
			
			
			If cmColumnName.FindString("name") <> -1 Then 'set default if exist 'name'
				cmColumnName.SelectedIndex = cmColumnName.FindString("name")
			Else
				cmColumnName.SelectedIndex = 0 'else set it to first column
			End If
			
		End If
		
		
		
		
		
		
		
		laStatus.Text="File loaded."
		laSelectedCell.Text = dataGridView1.Rows.Count-1 & " rows, " & dataGridView1.Columns.Count & " columns."
		laChanged.Text=""
		
	End Sub
	
	Function fnCheckQuotes(stItem As String) As String
		If Not stItem.StartsWith(Chr(34)) Then
			stItem = Chr(34) & stItem
		End If
		
		If Not stItem.EndsWith(Chr(34)) Then
			stItem = stItem & Chr(34)
		End If
		
		Return stItem
	End Function
	
	Sub fnSavecsv
		
		laStatus.Text = "Please wait, saving ... "
		laSelectedCell.Text = ""
		Update
		Dim intIndexOfExtension As Integer = 0
		
		'exit edit cell
		dataGridView1.EndEdit
		
		'if coming from file-save as lafilenmae is set to ''
		
		'if coming from file-save
		'lafilename and ladelimiter must be set
		
		If dataGridView1.Rows.Count < 1 Then
			laStatus.Text = "No rows? No save."
			Exit Sub
		End If
		
		
		If laDelimiter.Text="" Then
			laDelimiter.Text = vbTab
		End If
		
		'empty string name, always when coming from file-save as
		If laFilename.Text="" Then
			
			Dim SaveFileDialog1 As New SaveFileDialog()
			saveFileDialog1.Filter = "tab separated values|*.tsv|csv separated values|*.csv|Microsoft Office Excel 2003 SpreadsheetML XML|*.xml|m3u playlist|*.m3u|All files|*.*"
			
			
			'set extension
			If dataGridView1.Columns.Count>0 Then 
				If dataGridView1.Columns(0).Name.Length >=6 AndAlso dataGridView1.Columns(0).Name.Substring(0,6).ToLower = "column" Then 
					'not m3u
				Else
					'm3u, set extension
					
					intIndexOfExtension =   Array.IndexOf(saveFileDialog1.Filter.Split("|"), "*.m3u" )'find which one is *.m3u, starts from 0. later selected result starsts from 1, number 3 is 3
					If intIndexOfExtension > 0 Then
						intIndexOfExtension = (intIndexOfExtension \ 2) +1 'intger divide without remaining value
					End If
					
					SaveFileDialog1.FilterIndex = intIndexOfExtension  'if used with save as, filename is deleted first unfortunatelly. function untested. supposed to select same extension ...
					'SaveFileDialog1.FilterIndex = 3
				End If
			End If
			
			
			
			
			
			If SaveFileDialog1.ShowDialog <> System.Windows.Forms.DialogResult.Cancel Then
				laFilename.Text = SaveFileDialog1.FileName
			Else
				laStatus.Text="No file selected. File not saved"
				Exit Sub
			End If
			
		End If
		
		
		'if tsv selected as type
		If System.IO.Path.GetExtension(laFilename.Text).ToLower = ".tsv" Then
			laDelimiter.Text=vbTab
		End If
		
		
		'save
		'Dim stGridData As String = String.Empty
		Dim sbGridData As New System.Text.StringBuilder
		
		
		
		
		'm3u or m3u8
		If System.IO.Path.GetExtension(laFilename.Text).ToLower = ".m3u" Or System.IO.Path.GetExtension(laFilename.Text).ToLower = ".m3u8" Then
			
			Dim sbExtInfTags, sbOthers,sbRow As New System.Text.StringBuilder
			Dim stExtM3u, stExtInf, stName, stUrl, stComment As String
			
			
			'saving something as m3u. header names can be URL, #EXTINF = m3u, or columnxxx=csv
			If dataGridView1.Columns.Count>0 Then 
				'coming from csv, where header name is columnxxx
				If dataGridView1.Columns(0).Name.Length >=6 AndAlso  dataGridView1.Columns(0).Name.Substring(0,6).ToLower = "column" Then 
					'csv
					suMoveTopRowToHeaders
				End If
			End If
			
			
			For Each row As DataGridViewRow In DataGridView1.Rows
				
				stExtM3u = Nothing
				stExtInf = Nothing
				stName = Nothing
				sbExtInfTags.Clear
				stUrl = Nothing
				stComment = Nothing
				sbOthers.Clear
				sbRow.Clear
				
				
				If row.Index = dataGridView1.RowCount-1 Then'dont go into datagrid view editing line, -1 for index starting with 0
					Exit For 
				End If
				
				
				For Each cell As DataGridViewCell In row.Cells
					
					'If Not String.IsNullOrEmpty(cell.Value) Then
					
					'MessageBox.Show("cell value: " & "--" & cell.Value & "--" & "sbgrid: " & "--" & sbGridData.ToString & "--" & " " & sbGridData.Length)
					'MessageBox.Show(cell.Value)
					
					
					'#extm3u, quotes in cell value ok, in extm3u not. add space before cellvalue, end can be trimmed for spaces
					If dataGridView1.Columns(cell.ColumnIndex).Name = "#EXTM3U" And Not String.IsNullOrEmpty(cell.Value) Then
						
						'no validating
						If validateM3UCellValuesWhenSavingToolStripMenuItem.Checked = False Then
							stExtM3u = cell.Value
							Exit For
						End If
						
						
						If cell.Value.Length < "#EXTM3U".Length Then
							stExtM3u = "#EXTM3U"
						Else
							If Not cell.Value.ToString.StartsWith("#EXTM3U") Then
								stExtM3u = "#EXTM3U " & cell.Value.ToString.Trim
							Else 'it starts with "#EXTM3U" ...
								stExtM3u = cell.Value.ToString.Trim
							End If
							
						End If
						Exit For'we already know it is not empty, so we use the value and move to the next row ...
						
						'#extinf, remove extra spaces, quotes. name is in the name column
					ElseIf dataGridView1.Columns(cell.ColumnIndex).Name = "#EXTINF" Then
						
						If validateM3UCellValuesWhenSavingToolStripMenuItem.Checked = False Then
							stExtInf = cell.Value
							GoTo L1
						End If
						
						
						If String.IsNullOrEmpty(cell.Value) Then
							stExtInf = "#EXTINF:-1"
						Else
							If Not cell.Value.ToString.StartsWith("#EXTINF:") Then
								stExtInf = "#EXTINF:-1"
							Else
								Dim arSplitExtinf() As String = Split(cell.Value.ToString,":",2)'max 2 substrings
								'Dim arSplitExtinf() As String = cell.Value.ToString.Split(":",2)'max 2 substrings not working
								Dim inSeconds As Integer
								If Integer.TryParse(arSplitExtinf(1), inSeconds) Then
									stExtInf = "#EXTINF:" & inSeconds 'is integer
								Else
									stExtInf = "#EXTINF:-1" 'is not integer
								End If
								
								stExtInf = stExtInf.Replace(Chr(34) ,"").Trim
							End If
						End If
						
						L1:
						'#extinf tags
					ElseIf dataGridView1.Columns(cell.ColumnIndex).Name.Contains("#EXTINF") AndAlso dataGridView1.Columns(cell.ColumnIndex).Name.Length > "#EXTINF".Length Then
						
						If validateM3UCellValuesWhenSavingToolStripMenuItem.Checked = False Then
							sbExtInfTags.Append( " " & dataGridView1.Columns(cell.ColumnIndex).Name.Substring(7) & "=" & cell.Value & " ")'no check quotes for cell.value
							GoTo L2
						End If
						
						If String.IsNullOrEmpty(cell.Value) Then
							sbExtInfTags.Append( " " & dataGridView1.Columns(cell.ColumnIndex).Name.Substring(7) & "=" & Chr(34)&Chr(34) & " ")  ' " " tag=something 
						Else
							sbExtInfTags.Append( " " & dataGridView1.Columns(cell.ColumnIndex).Name.Substring(7) & "=" & fnCheckQuotes(cell.Value) & " ")  ' " " tag=something, add double quotes around cell.value if they don't exist
						End If				
						
						
						L2:
						',name
					ElseIf dataGridView1.Columns(cell.ColumnIndex).Name = "Name" Then
						
						If validateM3UCellValuesWhenSavingToolStripMenuItem.Checked = False Then
							stName = cell.Value
							GoTo L3
						End If
						
						
						If String.IsNullOrEmpty(cell.Value) Then
							stName = Chr(34)&Chr(34) 
						Else
							stName = cell.Value.ToString.Replace("," , " ").Trim ',name ' no "," in name because parsing
						End If	
						
						L3:
						'url. we don't touch url, except to trim spaces from the end. can it hold " inside?
					ElseIf dataGridView1.Columns(cell.ColumnIndex).Name = "URL" Then
						
						If validateM3UCellValuesWhenSavingToolStripMenuItem.Checked = False Then
							stUrl = cell.Value
							GoTo L4
						End If
						
						If String.IsNullOrEmpty(cell.Value) Then
							stUrl = Chr(34)&Chr(34) 
						Else
							stUrl = cell.Value.ToString.Trim 'trim white spaces from url, because quotes later
						End If	
						
						L4:
						'comment, dont touch it, just add # at the start, so it is ignored (used as comment by readers). no double quotes needed, has its own row
					ElseIf dataGridView1.Columns(cell.ColumnIndex).Name = "Comment" Then
						
						If validateM3UCellValuesWhenSavingToolStripMenuItem.Checked = False Then
							stComment = cell.Value
							GoTo L5
						End If
						
						If String.IsNullOrEmpty(cell.Value) Then
							stComment = "#"
						Else
							stComment = cell.Value
							If Not stComment.StartsWith("#") Then
								stComment = "#" & stComment
							End If
						End If	
						
						
						
						L5:
					Else 'none of the above, add to others (#ext... #playlist... etc)
						
						If sbOthers.Length = 0 Then 'if empty
							sbOthers.Append(cell.Value) 'add value only
						Else
							sbOthers.Append(Environment.NewLine & cell.Value) 'else add separator (if not first)
						End If
						
					End If
					
					
					'End If
					'end not empty
					
				Next
				'end each cell
				
				
				If Not String.IsNullOrEmpty(stExtM3u) Then
					sbRow.Append(stExtM3u)
				End If
				
				If Not String.IsNullOrEmpty(stExtInf) Then
					
					If sbRow.Length > 0 Then ' if not first, add newline before it
						sbRow.Append(Environment.NewLine)
					End If
					sbRow.Append(stExtInf & " ")
				End If
				
				
				If sbExtInfTags.Length > 0 Then ' if not empty, if exists
					sbRow.Append(" " & sbExtInfTags.ToString & " ")
				End If
				
				If Not String.IsNullOrEmpty(stName) Then
					sbRow.Append(" ," & stName)
				End If
				
				If Not String.IsNullOrEmpty(stComment) Then
					If sbRow.Length > 0 Then ' if not first, add newline before it
						sbRow.Append(Environment.NewLine)
					End If
					sbRow.Append(stComment )
				End If
				
				If sbOthers.Length > 0 Then 'if exists sbothers
					If sbRow.Length > 0 Then ' if not first, add newline before it
						sbRow.Append(Environment.NewLine)
					End If
					sbRow.Append(sbOthers)
				End If
				
				
				If Not String.IsNullOrEmpty(stUrl) Then
					If sbRow.Length > 0 Then ' if not first, add newline before it
						sbRow.Append(Environment.NewLine)
					End If
					sbRow.Append(stUrl ) 'stUrl is last
				End If
				
				If sbGridData.Length>0 Then
					sbGridData.Append(Environment.NewLine) 'add new line to the existing body, BEFORE adding current row. will NOT add newline to the last line
				End If
				
				sbRow.Replace("  "," ")' remove double spaces
				sbGridData.Append(sbRow.Replace("  "," "))
				sbRow.Clear
				
				'MessageBox.Show(sbGridData.ToString)
				
			Next	
			'end row
			
			'after all lines are done, add newline
			sbGridData.Append(Environment.NewLine) 'add so you can merge using copy *.* file.m3u . file last line crlf will be ignored when loading m3u
			
			'XML
			'if xml selected as type
			'todo if column names susbstr is not column, save columns name
		ElseIf System.IO.Path.GetExtension(laFilename.Text).ToLower = ".xml" Then
			
			suCloneColumnNamesInFirstRow(1)
			
			
			sbGridData.Append("<?xml version=""1.0"" encoding=""utf-8""?> <?mso-application progid=""Excel.Sheet""?> <Workbook xmlns=""urn:schemas-microsoft-com:office:spreadsheet"" xmlns:x=""urn:schemas-microsoft-com:office:excel""  xmlns:ss=""urn:schemas-microsoft-com:office:spreadsheet"" >  <Worksheet ss:Name=""Sheet1"">" & Environment.NewLine)  
			sbGridData.Append("<Table>" & Environment.NewLine) 
			'<Column ss:Width=""67""/><Column ss:Width=""25""/><Column ss:Width=""19""/><Column ss:Width=""19""/><Column ss:Width=""25""/>  
			
			For Each row As DataGridViewRow In DataGridView1.Rows
				
				'MessageBox.Show(row.Index & "" & dataGridView1.RowCount-2)
				If row.Index = dataGridView1.RowCount-1 Then'dont go into datagrid view editing line, -1 for index starting with 0
					Exit For 
				End If
				
				sbGridData.Append("<Row>")
				
				For Each cell As DataGridViewCell In row.Cells
					
					'replace special characters when saving, if option is enabled in menu. first check if string is not empty, or you will get error
					If Not String.IsNullOrEmpty(cell.Value) Andalso replaceSpecialCharactersWhenConvertingXMLToolStripMenuItem.Checked = True Then
						
						sbGridData.Append("<Cell><Data ss:Type=""String"">" & cell.Value.Replace("&" , "&amp;").Replace("<" , "&lt;").Replace(">" , "&gt;").Replace( Chr(34) , "&quot;").Replace("'" , "&apos;") & "</Data></Cell>")
						
					Else
						sbGridData.Append("<Cell><Data ss:Type=""String"">" & cell.Value & "</Data></Cell>")
					End If
					
					
					
				Next
				
				sbGridData.Append("</Row>" & Environment.NewLine)
			Next	
			
			sbGridData.Append("</Table> </Worksheet> </Workbook>" & Environment.NewLine) 
			'suCloneColumnNamesInFirstRow(0)
			
		Else
			
			'csv,tsv,txt, or NOTHING ""
			'If System.IO.Path.GetExtension(laFilename.Text) = ".csv" Or System.IO.Path.GetExtension(laFilename.Text) = ".tsv" Or System.IO.Path.GetExtension(laFilename.Text) = ".txt" Or System.IO.Path.GetExtension(laFilename.Text) = "" Then
			
			'anything else
			
			suCloneColumnNamesInFirstRow(1)
			
			For Each row As DataGridViewRow In DataGridView1.Rows
				
				'MessageBox.Show(row.Index & "" & dataGridView1.RowCount-2)
				If row.Index = dataGridView1.RowCount-1 Then'dont go into datagrid view editing line, -1 for index starting with 0
					Exit For 
				End If
				
				For Each cell As DataGridViewCell In row.Cells
					
					
					'MessageBox.Show(cell.Value)
					
					'do not evaluate further if string is empty. because comparing with empty string gives error!
					If Not String.IsNullOrEmpty(cell.Value) Andalso cell.Value.Contains(",") And laDelimiter.Text="," Then 'check if there is , inside cell
						sbGridData.Append(Chr(34) & cell.Value & Chr(34))
					Else
						sbGridData.Append(cell.Value)
					End If
					
					
					'MessageBox.Show(cell.Value & " " & cell.ColumnIndex & " " & dataGridView1.ColumnCount-1)
					
					If cell.ColumnIndex < dataGridView1.ColumnCount-1 Then 'if not last cell, add cell delimeter
						sbGridData.Append(laDelimiter.Text)
					End If
					
				Next
				
				If row.Index < dataGridView1.RowCount-1 ' add newline, unless it is edit line
					sbGridData.Append(Environment.NewLine)
				End If
			Next
			
			'suCloneColumnNamesInFirstRow(0)
			
		End If
		'end save
		
		'My.Computer.FileSystem.WriteAllText(laFilename.Text, sbGridData.ToString, False)'writes utf8-BOM. last argument is append=false. one could add ,system.text.encoding.utf8 and still gets utf8-bom :(
		System.IO.File.WriteAllText(laFilename.Text, sbGridData.ToString)
		
		laStatus.Text="File saved"
		laChanged.Text=""
		
		
	End Sub
	
	
	Sub fnDataGridViewSetStatusChanged
		dataGridView1.EndEdit
		laChanged.Text="Content changed"
	End Sub
	
	Sub fnClosingDataGridView
		dataGridView1.EndEdit
		
		If laChanged.Text="Content changed" Then
			
			Dim result As DialogResult = MessageBox.Show("Table changed. Save?", stProgramAndVersion, MessageBoxButtons.YesNo)
			
			
			If result = DialogResult.No Then
				laStatus.Text="File not saved"
			ElseIf result = DialogResult.Yes Then
				fnSavecsv
				laStatus.Text="File saved"
			End If
			
			laChanged.Text=""
		End If
		
	End Sub
	
	
	
	
	
	Sub SaveToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		fnSavecsv
	End Sub
	
	
	
	
	Sub ClearToolStripMenuItemClick(sender As Object, e As EventArgs)
		'close file
		dataGridView1.EndEdit
		fnClosingDataGridView	
		dataGridView1.Rows.Clear
		dataGridView1.Columns.Clear
		laFilename.Text=""
		laDelimiter.Text=""
		laStatus.Text="Workspace cleared"
		laSelectedCell.Text=""
		
		'because there were changes, we have to set status -not changed-, again
		laChanged.Text=""
		
	End Sub
	
	
	
	Sub fnNew
		dataGridView1.EndEdit
		fnClosingDataGridView
		
		dataGridView1.Rows.Clear
		dataGridView1.Columns.Clear
		
		dataGridView1.Columns.Add("Column1","Column1") ' column name, header text
		dataGridView1.Rows.Add(1)
		
		laFilename.Text=""
		laDelimiter.Text=vbTab
		laStatus.Text="New File"
	End Sub
	
	Sub NewToolStripMenuItemClick(sender As Object, e As EventArgs)
		fnNew
	End Sub
	
	
	
	
	Sub QuitToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		fnClosingDataGridView
		Me.Close
	End Sub
	
	
	
	Sub MainFormDragEnter(sender As Object, e As DragEventArgs)
		'activated when dragged files enter csvedit window
		dataGridView1.EndEdit
		If (e.Data.GetDataPresent(DataFormats.FileDrop)) Then
			e.Effect = DragDropEffects.All
		Else
			e.Effect = DragDropEffects.None
		End If
		
	End Sub
	
	
	
	
	Sub SaveAsToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit		
		'pick a new name.
		'delimiter should already be set
		
		laFilename.Text = ""
		fnSavecsv		
	End Sub
	
	
	
	Sub ReloadToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		fnClosingDataGridView
		If laFilename.Text<> "" Then
			fnOpencsv
			laStatus.Text = "File reopened"
		Else
			laStatus.Text="No file opened, cannot reopen it"
		End If
	End Sub
	
	Sub OpenInNotepadToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit		
		fnClosingDataGridView
		
		If laFilename.Text <> "" Then
			Shell("notepad.exe " & laFilename.Text, AppWinStyle.NormalFocus )
			laStatus.Text = "Opened in Notepad"
		Else
			laStatus.Text="No file opened, cannot open it in notepad"
		End If
	End Sub
	
	Sub ColumnToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		'add column
		dataGridView1.Columns.Add("Column","Column") ' & dataGridView1.Columns.Count +1)
	End Sub
	
	
	Sub RowToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		'add row
		If dataGridView1.Columns.Count = 0  Then 'error when columns.count = 0, and user adds row 
			dataGridView1.Columns.Add("Column","Column") ' & dataGridView1.Columns.Count +1)
		Else
			
			dataGridView1.Rows.Add(1)
		End If
	End Sub
	
	Sub InsertRowToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		'insert row 
		
		If dataGridView1.Columns.Count = 0 Then 'error when no columns, when user tries to add row. add column instead
			dataGridView1.Columns.Add("Column","Column") ' & dataGridView1.Columns.Count +1)
			Exit Sub
		End If
		
		If DataGridView1.SelectedCells.Count > 0 Then 'if selected, insert row above
			dataGridView1.Rows.Insert(dataGridView1.SelectedCells.Item(0).RowIndex,"")
		Else 'else add at bottom
			dataGridView1.Rows.Add(1)
		End If
		
		
	End Sub
	
	Sub InsertColumnToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		'insert column 
		'dataGridView1.Columns.Insert(dataGridView1.CurrentCell.ColumnIndex,dataGridView1.Columns.Count)
		Dim col As New DataGridViewTextBoxColumn
		col.HeaderText = "Column" '& (dataGridView1.CurrentCell.ColumnIndex -1 ).ToString
		col.Name = "Column"
		
		If DataGridView1.SelectedCells.Count > 0 'if selected insert before
			dataGridView1.Columns.Insert(dataGridView1.SelectedCells.Item(0).ColumnIndex,col)
		Else 'if not selected, add at the bottom
			'dataGridView1.Columns.Insert(0,col)
			dataGridView1.Columns.Add("Column","Column")
		End If
		
		
	End Sub
	
	Sub RemoveRowToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		'remove row(s)	
		
		laStatus.Text = "Please wait, removing selected row(s) ... "
		Update
		
		
		If  dataGridView1.SelectedRows.Count = 0 And DataGridView1.SelectedCells.Count > 0 Then 'no row/s selected, BUT cell/s selected
			
			Dim soRowIndex = New SortedSet(Of Integer)() 'create list of indices of selected rows, in which cells are selected
			'duplicates are not allowed in sorted set
			
			For inNumberOfSelectedCells As Integer = 0 To dataGridView1.SelectedCells.Count -1 'number of selected items
				soRowIndex.Add( dataGridView1.SelectedCells( inNumberOfSelectedCells ).RowIndex )	'add index of rows, inNumberOfSelectedCells is ordinal number 1, then ordinal number 2 ...
				'ordinal numbers START with 0
			Next
			
			For Each item As Integer In soRowIndex.Reverse  'start with biggest index, so don't mess up order by deleting
				If  item <  dataGridView1.Rows.Count -1 Then 'not last editable row
					dataGridView1.Rows.RemoveAt(item)
				End If
				
			Next
			
			
		Else 'full rows selected
			
			For Each row As DataGridViewRow In dataGridView1.SelectedRows
				If row.Index <  dataGridView1.Rows.Count -1
					dataGridView1.Rows.Remove(row)
				End If
				
			Next
			
			
		End If
		
		laStatus.Text = "Done."
		
	End Sub
	
	
	Sub RemoveColumnToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		'remove column(s)
		laStatus.Text = "Please wait, removing selected column(s) ... "
		Update
		
		If  dataGridView1.SelectedColumns.Count = 0 And DataGridView1.SelectedCells.Count > 0 Then 'no columns selected, BUT cell/s selected
			
			Dim soColumnIndex = New SortedSet(Of Integer)() 'create list of indices of selected columns, in which cells are selected
			
			For inNumberOfSelectedCells As Integer = 0 To dataGridView1.SelectedCells.Count -1 'number of selected items
				soColumnIndex.Add( dataGridView1.SelectedCells( inNumberOfSelectedCells ).ColumnIndex )	'add index of columns, inNumberOfSelectedCells is ordinal number 1, then ordinal number 2 ...
				'ordinal numbers START with 0
			Next
			
			For Each item As String In soColumnIndex.Reverse  'start with biggest index, so don't mess up order by deleting
				dataGridView1.Columns.RemoveAt(item)
			Next
			
			
		Else 'full column selected
			
			For Each row As DataGridViewRow In dataGridView1.SelectedRows
				dataGridView1.Rows.Remove(row)
			Next
			
			
		End If
		
		laStatus.Text = "Done."
		
	End Sub
	
	
	
	
	Sub DataGridView1Click(sender As Object, e As EventArgs)
		Dim stCellSelected As String = "" 
		
		If dataGridView1.SelectedCells.Count > 1 Then
			stCellSelected = dataGridView1.SelectedCells.Count & " cells selected. "
		End If
		
		
		
		'display selected cell.text in status
		If  dataGridView1.SelectedCells.Count > 0
			laSelectedCell.Text= stCellSelected & "current row: " & dataGridView1.CurrentCell.RowIndex +1 & ", current column: " &  dataGridView1.CurrentCell.ColumnIndex+1 &  ". " & dataGridView1.CurrentCell.Value 
			
		End If
		
		
		
	End Sub
	
	
	
	Sub ClearCellsToolStripMenuItemClick(sender As Object, e As EventArgs)
		
		dataGridView1.EndEdit
		
		For Each cell As datagridviewcell In dataGridView1.SelectedCells
			cell.Value= ""
		Next
		
		
	End Sub
	
	
	Sub MainFormFormClosing(sender As Object, e As FormClosingEventArgs)
		dataGridView1.EndEdit
		fnClosingDataGridView
	End Sub
	
	
	
	Sub DataGridView1CellValueChanged(sender As Object, e As DataGridViewCellEventArgs)
		fnDataGridViewSetStatusChanged
	End Sub
	
	
	Sub DataGridView1ColumnAdded(sender As Object, e As DataGridViewColumnEventArgs)
		fnDataGridViewSetStatusChanged
	End Sub
	
	Sub DataGridView1ColumnRemoved(sender As Object, e As DataGridViewColumnEventArgs)
		fnDataGridViewSetStatusChanged
	End Sub
	
	Sub DataGridView1RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs)
		fnDataGridViewSetStatusChanged
	End Sub
	
	Sub DataGridView1RowsRemoved(sender As Object, e As DataGridViewRowsRemovedEventArgs)
		fnDataGridViewSetStatusChanged
	End Sub
	
	Sub DataGridView1Sorted(sender As Object, e As EventArgs)
		fnDataGridViewSetStatusChanged
	End Sub
	
	Sub ChangeDelimiterToolStripMenuItemClick(sender As Object, e As EventArgs)
		
		'exit edit cell
		dataGridView1.EndEdit
		
		If dataGridView1.Rows.Count < 1 Then
			MsgBox("No rows? Exiting.")
			Exit Sub
		End If
		
		Dim message, title, defaultValue As String
		Dim myValue As Object
		' Set prompt.
		message = "Enter a new delimiter. Use tab for tab."
		' Set title.
		title = stProgramAndVersion
		defaultValue = laDelimiter.Text 'currently used
		If defaultValue = vbTab Then
			defaultValue = "tab"
			
		End If
		
		' Display message, title, and default value.
		myValue = InputBox(message, title,defaultValue)
		
		If myValue <> "" Then 'if equals "" then it is cancel. othervise ...
			
			If myValue = "tab" Then 'if user entered tab, convert it to vbtab
				myValue = vbTab
			End If
			
			If laDelimiter.Text <> myValue Then 'if there is a change
				laDelimiter.Text = myValue
				fnDataGridViewSetStatusChanged
			End If
			
		End If
		
		
	End Sub
	
	
	
	
	Sub CutToolStripMenuItem1Click(sender As Object, e As EventArgs)
		fnCut
	End Sub
	
	
	Sub CopyToolStripMenuItemClick(sender As Object, e As EventArgs)
		fnCopy
	End Sub
	
	
	Sub PasteToolStripMenuItem1Click(sender As Object, e As EventArgs)
		fnPaste
	End Sub
	
	
	Sub DeleteToolStripMenuItem1Click(sender As Object, e As EventArgs)
		fnDelete
	End Sub
	
	
	
	
	
	Sub CutToolStripMenuItemClick(sender As Object, e As EventArgs)
		fnCut
	End Sub
	
	Sub CopyToolStripMenuItem1Click(sender As Object, e As EventArgs)
		fnCopy
	End Sub
	
	
	Sub PasteToolStripMenuItemClick(sender As Object, e As EventArgs)
		fnPaste
	End Sub
	
	Sub DeleteToolStripMenuItemClick(sender As Object, e As EventArgs)
		fnDelete
	End Sub
	
	
	Sub fnPlay
		
		
		
		Dim prStart = New ProcessStartInfo()
		
		Dim stName,stUrl As String
		
		'prStart.WorkingDirectory = "d:\apps\mpv"
		'prStart.FileName = "d:\apps\mpv\mpv.exe"
		
		'MessageBox.Show(stMpvLocation)
		If Not System.IO.File.Exists(stMpvLocation) Then
			MessageBox.Show( "Settings.txt, File missing: " & stMpvLocation )
			Exit Sub
		End If
		
		Dim stPlayFile As String = System.IO.Path.Combine(Application.StartupPath, "play.bat")
		
		If  System.IO.File.Exists(stPlayFile) Then
			System.IO.File.Delete( stPlayFile )
		End If
		
		If setUserAgentWhenStreamingToolStripMenuItem.Checked = True Then
			stUserAgent = "--user-agent=mpv" ' because this also sets user agent: "--user-agent="
		Else
			stUserAgent = ""
		End If
		
		
		Dim stTextToWrite As String
		
		stTextToWrite =  Environment.NewLine & "@echo off" &Environment.NewLine & "chcp 65001>Nul"  &Environment.NewLine _
			& "echo %1" & Environment.NewLine & "echo %2" & Environment.NewLine  _
			& "cd /d " & Chr(34) & System.IO.Path.GetDirectoryName(stMpvLocation) & Chr(34) & Environment.NewLine _
			& Chr(34) & stMpvLocation &Chr(34) & " --no-config " & stUserAgent & " --title=%2 %1" 'old version: " abc ... --user-agent=""" & stUserAgent & """  ..." quotes only at start and end
		
		
		
		System.IO.File.WriteAllText(stPlayFile, stTextToWrite)
		
		If  Not System.IO.File.Exists(stPlayFile) Then
			MessageBox.Show( "File missing: " & stPlayFile )
			Exit Sub
		End If
		
		prStart.FileName = stPlayFile
		'prStart.FileName = "I:\Desktop\programming\csveditvers\csvEdit\play.bat"
		prStart.WorkingDirectory = System.IO.Path.GetDirectoryName(stPlayFile)
		
		
		
		
		For i = 0 To dataGridView1.Columns.Count - 1
			If dataGridView1.Columns(i).Name.ToLower = "name" Then
				stName = dataGridView1.Rows(dataGridView1.CurrentCell.RowIndex).Cells(i).Value
			End If
			If dataGridView1.Columns(i).Name.ToLower = "url" Then
				stUrl = dataGridView1.Rows(dataGridView1.CurrentCell.RowIndex).Cells(i).Value
			End If
		Next
		
		prStart.WindowStyle = prStart.WindowStyle.Normal
		'ignore beginning and end quotes...  --geometry=800x600+0+0
		'prStart.Arguments = " --no-config  --user-agent=android   --title=""" & stName & """   """ & stUrl & """ "
		
		prStart.Arguments = "    """ & stUrl & """   """ & stName & """   "
		
		'MessageBox.Show(stUrl)
		'MessageBox.Show(System.IO.Path.Combine(prStart.WorkingDirectory,prStart.FileName))
		'MessageBox.Show(prStart.Arguments)
		
		If	My.Computer.FileSystem.FileExists(System.IO.Path.Combine(prStart.WorkingDirectory,prStart.FileName)) Then
			'Process.Start(System.IO.Path.Combine(prStart.WorkingDirectory,prStart.FileName))
			Process.Start(prStart)
		Else
			MessageBox.Show( "Settings.txt, File missing: " & System.IO.Path.Combine(prStart.WorkingDirectory,prStart.FileName) )
		End if
	End Sub
	
	
	Sub PlayToolStripMenuItemClick(sender As Object, e As EventArgs)
		fnPlay
		
	End Sub
	
	Sub ChangeColumnTitleToolStripMenuItemClick(sender As Object, e As EventArgs)
		If dataGridView1.Columns.Count = 0 Then
			laStatus.Text = "No columns ..."
			Exit Sub
		End If
		
		Dim stInput As String
		stInput = InputBox("Enter new value, use -empty- to remove title:", "Enter new value:", dataGridView1.Columns(dataGridView1.SelectedCells.Item(0).ColumnIndex).Name )
		
		
		'because vb.net inputbox returns empty for both "no string" and "Cancel" ...		
		If stInput = "" Then
			Exit Sub
			
		'use something else for empty string, instead of "" 
		ElseIf stInput = "-empty-" Then
			stInput = ""		
		End if
		
		
		If dataGridView1.SelectedCells.Count > 0 Then
			dataGridView1.Columns(dataGridView1.SelectedCells.Item(0).ColumnIndex).HeaderText = stInput
			dataGridView1.Columns(dataGridView1.SelectedCells.Item(0).ColumnIndex).Name = stInput 'have to set BOTH headertext and Name!
		End If
		
		
	End Sub
	
	Sub MoveHeadersToTopRowToolStripMenuItemClick(sender As Object, e As EventArgs)
		suMoveHeadersToTopRow
	End Sub
	
	Sub suMoveHeadersToTopRow
		If dataGridView1.Columns.Count>0 Then
			dataGridView1.Rows.Insert(0)	
			For i As Integer = 0 To dataGridView1.Columns.Count -1
				dataGridView1.Rows(0).Cells(i).Value = dataGridView1.Columns(i).Name
				dataGridView1.Columns(i).HeaderText = "Column" & i+1
				dataGridView1.Columns(i).Name = "Column" & i+1 'have to set BOTH headertext and Name!
			Next
		end if
	End Sub
	
	
	Sub suMoveTopRowToHeaders
		For i As Integer = 0 To dataGridView1.Columns.Count -1
			dataGridView1.Columns(i).HeaderText = dataGridView1.Rows(0).Cells(i).Value
			dataGridView1.Columns(i).Name = dataGridView1.Rows(0).Cells(i).Value 'have to set BOTH headertext and Name!
		Next
		dataGridView1.Rows.RemoveAt(0)
	End Sub
	
	'someething is saved as csv, this is the check (possibly coming from other format), column names can be:  URL, or #EXTINF = not csv, or columnxxxx= csv 
	Sub suCloneColumnNamesInFirstRow (inCommand As Integer) ' if column name not column, save column name (when saving from m3u to some other format)
		
		If dataGridView1.Columns.Count>0 Then
			If dataGridView1.Columns(0).Name.Length >=6 AndAlso  dataGridView1.Columns(0).Name.Substring(0,6).ToLower = "column" Then 
				'coming from csv, don't do anything
			Else 
				'not coming from csv
				If inCommand = 1 Then
					suMoveHeadersToTopRow
				Else
					dataGridView1.Rows.RemoveAt(0)
				End If
				
			End If
		End If
		
	End Sub
	
	sub suCheckAddColumn(stCheck As String, stAdd As String)
		
		If Not dataGridView1.Columns.Contains(stCheck) Then ' add column  and its title
			DataGridView1.Columns.Add(stAdd, stAdd)
		End If	
		
	End Sub
	
	
	
	Sub MoveTopRowToHeadersToolStripMenuItemClick(sender As Object, e As EventArgs)
		
		suMoveTopRowToHeaders
	End Sub
	
	
	
	Sub AboutToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		MsgBox(stProgramAndVersion & ", " & stWebSite )
		
	End Sub
	
	
	
	
	
	Sub MoveColumnToTheRightToolStripMenuItemClick(sender As Object, e As EventArgs)
		
		If DataGridView1.SelectedCells.Count > 0 Then 'if selected 
			'Dim arCurrentCell() As Integer = {dataGridView1.SelectedCells.Item(0).RowIndex, dataGridView1.SelectedCells.Item(0).ColumnIndex}
			
			
			Dim inMoveTo As Integer = 2
			If dataGridView1.SelectedCells.Item(0).ColumnIndex+inMoveTo <= dataGridView1.Columns.Count Then
				
				
				
				Dim col As New DataGridViewTextBoxColumn
				col.HeaderText = dataGridView1.Columns(dataGridView1.CurrentCell.ColumnIndex).HeaderText
				col.Name = dataGridView1.Columns(dataGridView1.CurrentCell.ColumnIndex).Name
				
				dataGridView1.Columns.Insert(dataGridView1.SelectedCells.Item(0).ColumnIndex+inMoveTo,col)'insert at + 2
				For i As Integer = 0 To dataGridView1.Rows.Count - 2 ' dount count edit line, either
					dataGridView1.Rows(i).Cells(dataGridView1.CurrentCell.ColumnIndex+inMoveTo).Value = dataGridView1.Rows(i).Cells(dataGridView1.CurrentCell.ColumnIndex).Value
				Next
				
				Dim arCurrentCell() As Integer = {dataGridView1.CurrentCell.ColumnIndex,dataGridView1.CurrentCell.RowIndex}
				dataGridView1.Columns.RemoveAt(dataGridView1.CurrentCell.ColumnIndex)
				
				dataGridView1.CurrentCell = dataGridView1(arCurrentCell(0)+1,arCurrentCell(1)) 'column index, row index
			End If
			
		End If
		
	End Sub
	
	
	
	
	Sub MoveColumnToTheLeftToolStripMenuItemClick(sender As Object, e As EventArgs)
		
		If DataGridView1.SelectedCells.Count > 0 Then 'if selected 
			
			Dim inMoveTo As Integer = -1
			
			If dataGridView1.SelectedCells.Item(0).ColumnIndex+inMoveTo >= 0 Then 'index cannot go lower than 0
				
				
				Dim col As New DataGridViewTextBoxColumn
				col.HeaderText = dataGridView1.Columns(dataGridView1.CurrentCell.ColumnIndex).HeaderText
				col.Name = dataGridView1.Columns(dataGridView1.CurrentCell.ColumnIndex).Name
				
				dataGridView1.Columns.Insert(dataGridView1.SelectedCells.Item(0).ColumnIndex+inMoveTo,col)'insert at + 2
				For i As Integer = 0 To dataGridView1.Rows.Count - 2 ' dount count edit line, either
					dataGridView1.Rows(i).Cells(dataGridView1.CurrentCell.ColumnIndex+inMoveTo-1).Value = dataGridView1.Rows(i).Cells(dataGridView1.CurrentCell.ColumnIndex).Value '-1 to destination row index, cause we added another column
				Next
				
				Dim arCurrentCell() As Integer = {dataGridView1.CurrentCell.ColumnIndex,dataGridView1.CurrentCell.RowIndex}
				
				dataGridView1.Columns.RemoveAt(dataGridView1.CurrentCell.ColumnIndex)
				
				dataGridView1.CurrentCell = dataGridView1(arCurrentCell(0)-2,arCurrentCell(1)) 'column index, row index
			End If
			
		End If
		
	End Sub
	
	
	
	
	
	Sub DataGridView1CellMouseDoubleClick(sender As Object, e As DataGridViewCellMouseEventArgs)
		If DoubleClickCellToPlayURLInM3UListToolStripMenuItem.Checked = True Then
			fnPlay	
		End If
		
	End Sub
	
	
	Sub fnCheckLinks(liIndicesOfRows As List(Of Integer) )
		
		
		
		
		If dataGridView1.Columns.Count=0 Or dataGridView1.Rows.Count = 0 Then
			Exit sub
		End If
		
		If liIndicesOfRows.Count = 0 Then
			Exit Sub  'empty list
		End If
		
		
		
		Dim stStatusColumn As String = "#EXTINFstatus"
		Dim stEXTINFColumn = "#EXTINF"
		Dim stUrlColumn = "URL"
		Dim stNameColumn = "Name"
		
		Dim stYes As String = "ok"
		Dim stNo As String = "no"
		
		Dim dtStartTime As DateTime
		Dim dtStopTime As DateTime
		Dim tsElapsedTime As TimeSpan
		Dim tsRemaining As TimeSpan
		Dim deCompleted As Decimal
		
		
		
		
		
		If Not dataGridView1.Columns.Contains(stUrlColumn) Then
			laStatus.Text = "No URL column. Aborted"
			Exit Sub
		End If
		
		
		If Not dataGridView1.Columns.Contains(stEXTINFColumn) Then
			dataGridView1.Columns.Add(stEXTINFColumn,stEXTINFColumn)
		End If
		
		If Not dataGridView1.Columns.Contains(stStatusColumn) Then
			dataGridView1.Columns.Add(stStatusColumn,stStatusColumn)
		End If
		
		Dim inStatusColumnIndex As Integer
		Dim inUrlColumnIndex As Integer
		Dim inNameColumnIndex As Integer
		Dim inEXTINFColumnIndex As Integer
		
		For i = 0 To dataGridView1.Columns.Count - 1
			If dataGridView1.Columns(i).Name.ToLower = stStatusColumn.ToLower Then
				inStatusColumnIndex = i
			ElseIf dataGridView1.Columns(i).Name.ToLower = stUrlColumn.ToLower Then
				inUrlColumnIndex = i
			ElseIf dataGridView1.Columns(i).Name.ToLower = stNameColumn.ToLower Then
				inNameColumnIndex = i
			ElseIf dataGridView1.Columns(i).Name.ToLower = stEXTINFColumn.ToLower Then
				inEXTINFColumnIndex = i
			End If
			
		Next
		
		
		
		Dim prStart  As New System.Diagnostics.Process
		
		If stTestUsing = "ffprobe" Then
			prStart.StartInfo.FileName = stFfprobeLocation
			prStart.StartInfo.WorkingDirectory = System.IO.Path.GetDirectoryName(stFfprobeLocation)
			'jr ok, says its not
			
			If setUserAgentWhenStreamingToolStripMenuItem.Checked = True Then
				stUserAgent = "-user_agent ffprobe"
			Else
				stUserAgent = ""
			End If
			
		End If
		
		
		'If stTestUsing = "mpv" Then
		'	prStart.StartInfo.FileName = "d:\apps\mpv\mpv.exe"
		'	prStart.StartInfo.WorkingDirectory = "d:\apps\mpv"
		'	'katamai error when length 1
		'End If
		
		
		'If stTestUsing = "vlc" Then
		'	prStart.StartInfo.FileName = "d:\apps\vlc\vlc.exe"
		'	prStart.StartInfo.WorkingDirectory = "d:\apps\vlc"
		'	'always yes?
		'End If
		
		
		
		'If stTestUsing = "wget" Then
		'	prStart.StartInfo.FileName = "d:\apps\wget\wget.exe"
		'	prStart.StartInfo.WorkingDirectory = "d:\apps\wget"
		'End If
		
		
		'If stTestUsing = "ffmpeg" Then
		'	prStart.StartInfo.FileName = "d:\apps\ffmpeg\ffmpeg.exe"
		'	prStart.StartInfo.WorkingDirectory = "d:\apps\ffmpeg"
		'End If
		
		
		
		
		
		
		prStart.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
		
		
		
		
		If	Not My.Computer.FileSystem.FileExists(prStart.StartInfo.FileName) Then
			MessageBox.Show(prStart.StartInfo.FileName & " is missing!")
			laStatus.Text = ""
			Exit Sub
		End If
		
		
		Dim stName,stUrl As String
		
		laSelectedCell.Text = ""
		
		
		dtStartTime = Now
		Dim inListCurrentIndex As Integer = 0
		
		
		
		For x = 0 To liIndicesOfRows.Count-1 'index of items in list, NOT datagridview row index
			
			
			If  liIndicesOfRows(x) =  dataGridView1.Rows.Count -1 ' last editable row, not used
				Exit For
			End If
			
			
			
			stUrl = Nothing
			stName = ""
			
			
			If Not String.IsNullOrEmpty(dataGridView1.Rows(liIndicesOfRows(x)).Cells(inUrlColumnIndex).Value)
				stUrl = dataGridView1.Rows(liIndicesOfRows(x)).Cells(inUrlColumnIndex).Value
			End If 
			
			If Not String.IsNullOrEmpty(dataGridView1.Rows(liIndicesOfRows(x)).Cells(inNameColumnIndex).Value)
				stName = dataGridView1.Rows(liIndicesOfRows(x)).Cells(inNameColumnIndex).Value
			End If 
			
			
			
			'If stTestUsing = "mpv" Then
			'	If setUserAgentWhenStreamingToolStripMenuItem.Checked = True Then
			'		stUserAgent = "--user-agent=mpv"
			'	Else
			'		stUserAgent = ""
			'	End If
			'	prStart.StartInfo.Arguments = "  --no-config  --length=1 " & stUserAgent & "  --mute --geometry=800x600+0+0     """ & stUrl & """ "
			'	'kto says notok, sometimes does not work correctly if length cannot be measured
			'End If
			
			'If stTestUsing = "vlc" Then
			'	prStart.StartInfo.Arguments = " --http-user-agent=vlc --intf=dummy --no-repeat --stop-time=1 --play-and-exit  """ & stUrl & """ "
			'	'too many yes
			'End If
			
			
			If stTestUsing = "ffprobe" Then
				'rw = set network timeout to 15 sec. mostly ok, sometimes says notok, when program is working.
				'using stUserAgent set prior, above
				prStart.StartInfo.Arguments = " -rw_timeout 15000000 " & stUserAgent & " -i  """ & stUrl & """  "
			End If
			
			'If stTestUsing = "wget" Then
			'	'use newer version of wget on windows
			'	prStart.StartInfo.Arguments = " --timeout=5 --tries=1 --no-check-certificate -O test.html --user-agent=android   """ & stUrl & """ " 'wget
			'End If
			
			
			'If stTestUsing = "ffmpeg" Then
			'	prStart.StartInfo.Arguments = " -rw_timeout 15000000 -user_agent ffmpeg -i  """ & stUrl & """    -t 1  -f null  NUL " 'time =1, format null=no output created, output NUL so ffmpeg does not complain about missing option ' before used:  -c copy -t 1 -y test.ts "
			'	'user agent must be in front
			'End If
			
			
			
			
			If Not String.IsNullOrEmpty(stUrl) Then
				
				dtStopTime = Now
				tsElapsedTime = dtStopTime.Subtract(dtStartTime)
				deCompleted = Math.Round(   (inListCurrentIndex+1)/(liIndicesOfRows.Count) *100  ,2 ) 'not using liIndicesOfRows(x)
				
				tsRemaining = tsElapsedTime
				'160*(100-80)/80
				If deCompleted <> 0 Then
					tsRemaining = TimeSpan.FromTicks(tsElapsedTime.Ticks * ( ( 100 - deCompleted) /deCompleted) )
				End If
				
				
				
				laStatus.Text = "Testing row " & inListCurrentIndex +1  & " of " & liIndicesOfRows.Count & " rows: " & stName & ", " &  deCompleted   & "% complete ... " & "time elapsed in minutes: " & tsElapsedTime.TotalMinutes.ToString("0.00") & ", time remaining: " & tsRemaining.TotalMinutes.ToString("0.00")
				Update
				
				'Clipboard.SetText(prStart.StartInfo.Arguments.ToString)
				'MessageBox.Show(prStart.StartInfo.Arguments.ToString)
				
				prStart.Start
				prStart.WaitForExit(19000)'wait 19 sec max
				
				
				'Threading.Thread.Sleep(1500)
				
				
				
				For Each p As Process In System.Diagnostics.Process.GetProcessesByName(stTestUsing)' "ffprobe"
					
					Try
						p.Kill()
						p.WaitForExit()
					Catch winException As System.ComponentModel.Win32Exception
					Catch invalidException As InvalidOperationException
						'Threading.Thread.Sleep(1500)
					End Try
				Next
				
				If String.IsNullOrEmpty(dataGridView1.Rows(liIndicesOfRows(x)).Cells(inEXTINFColumnIndex).Value) 'fill extinf cell
					dataGridView1.Rows(liIndicesOfRows(x)).Cells(inEXTINFColumnIndex).Value = "#EXTINF:0"
				End If
				
				
				If prStart.ExitCode = 0  Then 'ok
					dataGridView1.Rows(liIndicesOfRows(x)).Cells(inStatusColumnIndex).Value = Chr(34) &stYes & ":" & prStart.ExitCode & " " & System.DateTime.Now.ToString("yyyy-MM-dd_HH:mm:ss") & Chr(34)
					'MessageBox.Show("ok")
				Else
					dataGridView1.Rows(liIndicesOfRows(x)).Cells(inStatusColumnIndex).Value = Chr(34) & stNo & ":" & prStart.ExitCode & " " & System.DateTime.Now.ToString("yyyy-MM-dd_HH:mm:ss") & Chr(34)
				End If
			End If
			
			
			
			inListCurrentIndex = inListCurrentIndex + 1
		Next
		'end rows
		laStatus.Text = "Finished testing at " & DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss") & ", after " & tsElapsedTime.TotalMinutes.ToString("0.00") & " minutes."
		'Update
		
		
		'ignore beginning and end quotes...
		
		
		'System.IO.Path.Combine(prStart.WorkingDirectory,prStart.FileName)
	End Sub
	
	
	
	
	
	
	Sub fnRemoveDuplicates(inDelete As Integer)
		
		Dim soIntegerDuplicateUrls = New SortedSet(Of Integer)() 
		Dim liUrls As New List(Of String)
		
		Dim inUrlColumnIndex As Integer
		
		For i = 0 To dataGridView1.Columns.Count - 1
			If dataGridView1.Columns(i).Name.ToLower = "url" Then
				inUrlColumnIndex = i
			End If
		Next
		
		
		Dim stUrl As String
		
		laSelectedCell.Text = ""
		
		For x = 0 To dataGridView1.Rows.Count -2
			stUrl = Nothing
			
			
			If Not String.IsNullOrEmpty(dataGridView1.Rows(x).Cells(inUrlColumnIndex).Value)
				stUrl = dataGridView1.Rows(x).Cells(inUrlColumnIndex).Value
				
				
				If Not liUrls.Contains(stUrl) Then ' add if not exist
					liUrls.Add(stUrl)
				Else
					soIntegerDuplicateUrls.Add(x)'else add to list of rows to delete
				End If
				
				
				laStatus.Text = "Checking row " & x+1 & " of " & dataGridView1.Rows.Count -1 & " rows, " & Math.Round(   (x+1)/(dataGridView1.Rows.Count-1) *100  ,2 ) & "% complete ..." 
				Update
				
			End If 
			
		Next
		'end rows
		
		laStatus.Text = soIntegerDuplicateUrls.Count & "duplicate rows removing ... " 
		Update
		
		For Each item As Integer In soIntegerDuplicateUrls.Reverse
			If inDelete = 1 Then
				dataGridView1.Rows.RemoveAt(item)
			Else
				dataGridView1.Rows(item).DefaultCellStyle.BackColor = Color.Red
			End If
			
		Next
		
		laStatus.Text = "Finished, " & soIntegerDuplicateUrls.Count & " removed, remaining rows: " & dataGridView1.Rows.Count -1  
		
		
	End Sub
	
	
	
	
	
	
	
	Sub CheckLinksToolStripMenuItemClick(sender As Object, e As EventArgs)
		
		If dataGridView1.Rows.Count = 0 Or dataGridView1.Columns.Count = 0 Then
			Exit Sub
		End If
		
		Dim liIndicesOfRows As New List(Of Integer)
		
		laStatus.Text = "Adding links to the list to be checked ..." 'should be very fast, but just in case set message
		Update
		
		liIndicesOfRows.AddRange(System.Linq.Enumerable.Range(0, dataGridView1.Rows.Count-1)) 'populate list with integers
		fnCheckLinks(liIndicesOfRows)
		
	End Sub
	
	Sub RemoveDuplicateURLsToolStripMenuItemClick(sender As Object, e As EventArgs)
		fnRemoveDuplicates(1)
	End Sub
	
	Sub MarkDuplicateURLsToolStripMenuItemClick(sender As Object, e As EventArgs)
		fnRemoveDuplicates(0)
	End Sub
	
	Sub AddChannelNumberToolStripMenuItemClick(sender As Object, e As EventArgs)
		
		Dim stEXTINFColumn  As String = "#EXTINF"
		Dim stChannelNumberColumn As String = "#EXTINFtvg-chno"
		Dim stEXTM3UColumn  As String = "#EXTM3U"
		
		If Not dataGridView1.Columns.Contains(stEXTINFColumn) Then
			dataGridView1.Columns.Add(stEXTINFColumn,stEXTINFColumn)
		End If
		
		If Not dataGridView1.Columns.Contains(stChannelNumberColumn) Then
			dataGridView1.Columns.Add(stChannelNumberColumn,stChannelNumberColumn)
		End If
		
		Dim inChannelNumberColumnIndex As Integer
		Dim inEXTINFColumnIndex As Integer
		Dim inEXTM3UColumnIndex As Integer
		
		For i = 0 To dataGridView1.Columns.Count - 1
			If dataGridView1.Columns(i).Name.ToLower = stChannelNumberColumn.ToLower Then
				inChannelNumberColumnIndex = i
			ElseIf dataGridView1.Columns(i).Name.ToLower = stEXTINFColumn.ToLower Then
				inEXTINFColumnIndex = i
			ElseIf dataGridView1.Columns(i).Name.ToLower = stEXTM3UColumn.ToLower Then
				inEXTM3UColumnIndex = i
			End If
			
		Next
		
		
		For i = 0 To dataGridView1.Rows.Count -2
			If dataGridView1.Columns.Contains(stEXTM3UColumn) And Not String.IsNullOrEmpty(dataGridView1.Rows(i).Cells(inEXTM3UColumnIndex).Value) Then ' if exist extm3u, and is not empty, do nothing
			Else
				If String.IsNullOrEmpty(dataGridView1.Rows(i).Cells(inEXTINFColumnIndex).Value) 'fill extinf cell
					dataGridView1.Rows(i).Cells(inEXTINFColumnIndex).Value = "#EXTINF:0"
				End If
				
				dataGridView1.Rows(i).Cells(inChannelNumberColumnIndex).Value =  Chr(34) & (i+1).ToString().PadLeft(6, "0") & Chr(34)
			End If
			
			
		Next
		
		
		
	End Sub
	
	Sub MarkSelectedTemporarilyToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		'remove row(s)	
		
		If  dataGridView1.SelectedRows.Count = 0 And DataGridView1.SelectedCells.Count > 0 Then 'no row/s selected, BUT cell/s selected
			
			Dim soRowIndex = New SortedSet(Of Integer)() 'create list of indices of selected rows, in which cells are selected
			
			For inNumberOfSelectedCells As Integer = 0 To dataGridView1.SelectedCells.Count -1 'number of selected items, duplicates not allowed in sorted set in case two cells selected in one row
				soRowIndex.Add( dataGridView1.SelectedCells( inNumberOfSelectedCells ).RowIndex )	'add index of rows, inNumberOfSelectedCells is ordinal number 1, then ordinal number 2 ...
				'ordinal numbers START with 0
			Next
			
			For Each item As Integer In soRowIndex.Reverse  'start with biggest index, so don't mess up order by deleting
				If  item <  dataGridView1.Rows.Count -1 'not last editable row
					dataGridView1.Rows(item).DefaultCellStyle.BackColor = Color.Green
				End If
				
			Next
			
			
		Else 'full rows selected
			
			For Each row As DataGridViewRow In dataGridView1.SelectedRows
				If row.Index <  dataGridView1.Rows.Count -1
					row.DefaultCellStyle.BackColor = Color.Green
				End If
				
			Next
			
			
		End If
		
	End Sub
	
	Sub RemoveTemporToolStripMenuItemClick(sender As Object, e As EventArgs)
		For i = 0 To dataGridView1.Rows.Count -2
			dataGridView1.Rows(i).DefaultCellStyle.BackColor = Color.White
		Next
	End Sub
	
	Sub TableInfoToolStripMenuItemClick(sender As Object, e As EventArgs) ' rows - 1 (editrow)
		laSelectedCell.Text = dataGridView1.Rows.Count-1 & " rows, " & dataGridView1.Columns.Count & " columns."
	End Sub
	
	Sub CheckSelectedLinksToolStripMenuItemClick(sender As Object, e As EventArgs)
		dataGridView1.EndEdit
		
		If dataGridView1.Rows.Count = 0 Or dataGridView1.Columns.Count=0 Then
			Exit Sub
		End If
		
		laStatus.Text = "Adding links to the list to be checked ..."
		Update
		
		Dim soRowIndex = New SortedSet(Of Integer)() 'create list of indices of selected rows, in which cells are selected
		'duplicates are not allowed in sorted set
		
		If  dataGridView1.SelectedRows.Count = 0 And DataGridView1.SelectedCells.Count > 0 Then 'no row/s selected, BUT cell/s selected
			For inNumberOfSelectedCells As Integer = 0 To dataGridView1.SelectedCells.Count -1 'number of selected items
				soRowIndex.Add( dataGridView1.SelectedCells( inNumberOfSelectedCells ).RowIndex )	'add index of rows, inNumberOfSelectedCells is ordinal number 1, then ordinal number 2 ...
				'ordinal numbers START with 0
			Next
		Else 'full rows selected
			
			For Each row As DataGridViewRow In dataGridView1.SelectedRows
				soRowIndex.Add(row.Index)
			Next
			
		End If
		'last row/editable row will be excluded later in fn()  (datagridview.rows.count -1)
		
		
		Dim liIndicesOfRows As List(Of Integer) 
		'liIndicesOfRows = soRowIndex.ToList 'if using imports System.Linq
		liIndicesOfRows = System.Linq.Enumerable.ToList(soRowIndex) 'same thing, convert to list
		
		
		fnCheckLinks(liIndicesOfRows)
	End Sub
	
	Sub CopyWithHeaderInformationM3UToolStripMenuItemClick(sender As Object, e As EventArgs)
		If dataGridView1.Rows.Count < 1 Then
			MsgBox("No rows?")
			Exit Sub
		End If
		'SendKeys.Send("^c")
		'copy
		'for pasting in say excel. unselected cells will be pasted as empty! deleting value in excel
		Me.dataGridView1.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
		
		
		
		
		
		dataGridView1.EndEdit
		
		If dataGridView1.Rows.Count = 0 Or dataGridView1.Columns.Count=0 Then
			Exit Sub
		End If
		
		
		Dim soRowIndex = New SortedSet(Of Integer)() 'create list of indices of selected rows, in which cells are selected
		'duplicates are not allowed in sorted set
		
		If  dataGridView1.SelectedRows.Count = 0 And DataGridView1.SelectedCells.Count > 0 Then 'no row/s selected, BUT cell/s selected
			For inNumberOfSelectedCells As Integer = 0 To dataGridView1.SelectedCells.Count -1 'number of selected items
				soRowIndex.Add( dataGridView1.SelectedCells( inNumberOfSelectedCells ).RowIndex )	'add index of rows, inNumberOfSelectedCells is ordinal number 1, then ordinal number 2 ...
				'ordinal numbers START with 0
			Next
		Else 'full rows selected
			
			For Each row As DataGridViewRow In dataGridView1.SelectedRows
				soRowIndex.Add(row.Index)
			Next
			
		End If
		'last row/editable row will be excluded later in fn()  (datagridview.rows.count -1)
		
		
		For Each x In soRowIndex
			dataGridView1.Rows( x  ).Selected  = True	
		Next
		
		
		Clipboard.SetDataObject(Me.dataGridView1.GetClipboardContent)
		laStatus.Text="Copied selected rows with header information"
	End Sub
	
	
	
	Sub fnPasteRowsWithHeaderInformation (inStartAtBottom As Integer)
		
		Dim stClipboard As String = Clipboard.GetText
		Dim inCopiedRowCounter As Integer = 0
		Dim inCopiedCellCounter As Integer = 0
		Dim arHeaders() As String
		Dim inCurrentRowIndex As Integer
		
		
		'no selected
		If dataGridView1.SelectedCells.Count = 0 Then
			Exit Sub
		End If
		
		If stClipboard.Length = 0 Then
			'Exit Sub 'empty? 
		End If
		
		If dataGridView1.Rows.Count = 0 Then
			dataGridView1.Rows.Add(1)
		End If
		
		If inStartAtBottom = 1
			inCurrentRowIndex = dataGridView1.Rows.Count-1 ' start at the bottom
		Else
			inCurrentRowIndex = DataGridView1.CurrentCell.RowIndex
		End If
		
		
		For Each stRow In Strings.Split(stClipboard,Environment.NewLine)
			If inCopiedRowCounter = 0 Then ' first row, which is headers
				arHeaders = Strings.Split(stRow, vbTab)
				inCopiedRowCounter = inCopiedRowCounter +1
				Continue For ' go to processing next row
			End If
			
			If inStartAtBottom = 1 Then
				dataGridView1.Rows.Add(1)
			Else
				dataGridView1.Rows.Insert(inCurrentRowIndex,1)
			End If
			
			
			inCopiedCellCounter = 0
			
			For Each stCell	In Strings.Split(stRow, vbTab)
				
				If inCopiedCellCounter = 0 Then ' skip first empty? column
					inCopiedCellCounter = inCopiedCellCounter +1
					Continue for
				End If
				
				If dataGridView1.Columns.Contains(arHeaders(inCopiedCellCounter)) Then 
				Else
					dataGridView1.Columns.Add(arHeaders(inCopiedCellCounter),arHeaders(inCopiedCellCounter)) 'add column if missing
				End If
				
				
				'cell value of dgv, which is the same as copied cell header. to get copied cell header we use copiedArray and its index
				dataGridView1.Rows(inCurrentRowIndex).Cells( dataGridView1.Columns(arHeaders(inCopiedCellCounter)).index  ).Value = stCell
				
				
				inCopiedCellCounter = inCopiedCellCounter +1
				
				
			Next
			inCurrentRowIndex = inCurrentRowIndex+1
			inCopiedRowCounter = inCopiedRowCounter +1 
		Next		
		
		
		
		
		'remove first columnx if empty
		
		Dim boColumn1HasData As Boolean = 0
		
		If dataGridView1.Columns(0).Name.Length >=6 AndAlso dataGridView1.Columns(0).Name.Substring(0,6).ToLower = "column" Then
			
			For i As Integer = 0 To dataGridView1.Rows.Count -1
				If Not String.IsNullOrWhiteSpace(dataGridView1.Rows(i).Cells(0).Value) Then 'if any column1(first cell) in each row has data
					
					boColumn1HasData = 1
					Exit For
				End If
			Next
			
			If boColumn1HasData = 0 Then
				dataGridView1.Columns.RemoveAt(0)
			End If
			
		End If
		
	End Sub
	
	Sub BottomPasteRowsWithHeaderInformationM3UToolStripMenuItemClick(sender As Object, e As EventArgs)
		fnPasteRowsWithHeaderInformation(1)
	End Sub
	
	Sub PasteAddToTheBottomRowsWithHeaderInformationM3UToolStripMenuItemClick(sender As Object, e As EventArgs)
		fnPasteRowsWithHeaderInformation(0)
	End Sub
	
	Sub fnCreateFilelist(liFileList As List(Of String) )
		
		fnNew 'clear
		dataGridView1.Rows.RemoveAt(0) 'remove list which is auto added
		
		Dim i As Integer = 0
		
		If My.Computer.Keyboard.ScrollLock Then 'create regular list
			For each item In liFileList
				If DoNotFilterDroppedMultipleFilesOnProgramToolStripMenuItem.Checked = False AndAlso ( System.IO.Path.GetExtension(item).ToLower = ".srt" Or System.IO.Path.GetExtension(item).ToLower = ".sub" Or System.IO.Path.GetExtension(item).ToLower = ".html" Or System.IO.Path.GetExtension(item).ToLower = ".png" Or System.IO.Path.GetExtension(item).ToLower = ".nfo" Or System.IO.Path.GetExtension(item).ToLower = ".txt" Or System.IO.Path.GetExtension(item).ToLower = ".jpg" ) Then
					Continue For ' do not add subtitles to list
				End If
				
				dataGridView1.Rows.Add
				dataGridView1.Rows(i).Cells(0).Value = item
				i = i +1
			Next
			
			
			'For x = 0 To liFileList.Count-1
			'	dataGridView1.Rows.Add
			'	dataGridView1.Rows(x).Cells(0).Value = liFileList(x)
			'Next
			
			
		Else 
			
			
			
			Dim stCategoryName As String = "VOD-LOCAL" 'ask for group title
			If My.Computer.Keyboard.CapsLock
				Dim stReturnValue As String = InputBox("Caps Lock key is pressed, enter new value for group title:",,stCategoryName)
				
				If stReturnValue <> "" Then
					stCategoryName = stReturnValue
				End If
				
			End If
			
			
			dataGridView1.Columns(0).Name = "#EXTM3U"
			dataGridView1.Columns(0).HeaderText = "#EXTM3U"
			
			'row for extm3u
			dataGridView1.Rows.Add
			dataGridView1.Rows(0).Cells(0).Value = "#EXTM3U"
			
			
			dataGridView1.Columns.Add("#EXTINF","#EXTINF")
			dataGridView1.Columns.Add("#EXTINFgroup-title","#EXTINFgroup-title")
			dataGridView1.Columns.Add("Name","Name")
			dataGridView1.Columns.Add("URL","URL")
			
			
			
			'+1 for extm3u which is first
			
			For each item In liFileList
				'. included in ext!
				If DoNotFilterDroppedMultipleFilesOnProgramToolStripMenuItem.Checked = False AndAlso ( System.IO.Path.GetExtension(item).ToLower = ".srt" Or System.IO.Path.GetExtension(item).ToLower = ".sub" Or System.IO.Path.GetExtension(item).ToLower = ".html" Or System.IO.Path.GetExtension(item).ToLower = ".png" Or System.IO.Path.GetExtension(item).ToLower = ".nfo" Or System.IO.Path.GetExtension(item).ToLower = ".txt" Or System.IO.Path.GetExtension(item).ToLower = ".jpg" ) Then
					Continue For ' do not add subtitles to list
				End If
				dataGridView1.Rows.Add
				dataGridView1.Rows(i+1).Cells(1).Value = "#EXTINF:0"
				dataGridView1.Rows(i+1).Cells(2).Value = Chr(34) & stCategoryName &  Chr(34)
				dataGridView1.Rows(i+1).Cells(3).Value = System.IO.Path.GetFileNameWithoutExtension(item).Replace("," , " ").Trim 'no "," in name, because parsing
				dataGridView1.Rows(i+1).Cells(4).Value = item
				i = i +1
			Next
			dataGridView1.Sort( dataGridView1.Columns("Name"),System.ComponentModel.ListSortDirection.Ascending)
		End If 
		
		
	End Sub
	
	
	Sub MainFormDragDrop(sender As Object, e As DragEventArgs)
		
		'activated when mouse button released (files dropped) after dragging files to csvedit window
		dataGridView1.EndEdit
		
		Dim liListOfDroppedFiles As New List(Of String)		
		If My.Computer.Keyboard.ShiftKeyDown Then 'if shift pressed open in new window
			
			liListOfDroppedFiles =  System.Linq.Enumerable.ToList(e.Data.GetData(DataFormats.FileDrop) ) 'convert to list
			
			If System.IO.File.Exists(liListOfDroppedFiles(0)) Then 'first file
				
				fnOpenInNewWindow(liListOfDroppedFiles(0))
				
				Exit Sub ' exit after calling fn
				
			End if
		End If
		
		
		fnClosingDataGridView
		
		
		'Dim liListOfDroppedFiles As New List(Of String)
		liListOfDroppedFiles =  System.Linq.Enumerable.ToList(e.Data.GetData(DataFormats.FileDrop) ) 'convert to list
		
		If liListOfDroppedFiles.Count = 1 Then 'one item
			
			If System.IO.Directory.Exists(liListOfDroppedFiles(0)) Then 'one item, but directory. create simple list of files from inside dir
				'Return FileSystemObject.Directory
				Dim liFiles As New List(Of String) 
				liFiles = System.IO.Directory.GetFiles(liListOfDroppedFiles(0), "*", System.IO.SearchOption.AllDirectories).ToList
				fnCreateFilelist(liFiles) 'send simple list of files to fn, to create real list of files
				
			ElseIf System.IO.File.Exists(liListOfDroppedFiles(0)) 'one item, file. probably textual/m3u/csv...
				'Return FileSystemObject.File
				laFilename.Text=liListOfDroppedFiles(0) 'first item
				fnOpencsv 'open as text
			End If
		Else '> 1
			fnCreateFilelist(liListOfDroppedFiles) 'create real list of files
			
			
		End If 'end >1
		
		
	End Sub
	
	
	Sub CreateM3uListFromAFolderToolStripMenuItemClick(sender As Object, e As EventArgs)
		
		Dim folderBrowserDialog1 As New FolderBrowserDialog
		
		Dim i As Integer = 0
		
		If folderBrowserDialog1.ShowDialog() = DialogResult.OK Then
			'Dim arFiles() As String = System.IO.Directory.GetFiles(folderBrowserDialog1.SelectedPath, "*", System.IO.SearchOption.AllDirectories)
			
			Dim liFiles As New List(Of String) 
			liFiles = System.IO.Directory.GetFiles(folderBrowserDialog1.SelectedPath, "*", System.IO.SearchOption.AllDirectories).ToList
			fnCreateFilelist(liFiles)
		End If
		
		
	End Sub
	
	
	
	Sub fnCreateFolderFromM3U(stFolder As String)
		
		laStatus.Text = "Creating folder (with m3u files) from m3u list ..."
		Update
		
		If dataGridView1.Columns.Count = 0 Or dataGridView1.Rows.Count = 0 Then
			laStatus.Text = "No columns or rows."
			Exit Sub
		End If
		
		
		If Not dataGridView1.Columns.Contains("URL") Then
			If dataGridView1.Columns.Count = 1 Then
				dataGridView1.Columns(0).Name = "URL"
				dataGridView1.Columns(0).HeaderText = "URL"
			Else
				laStatus.Text = "No URL column."
				Exit Sub
			End If
			
		End If
		
		
		Dim fiSaveFile As System.IO.StreamWriter
		Dim stFileName As String
		'Dim stFolder As String 'already defined
		
		
		Dim stSubFolder As String
		Dim stSubfolderTag As String
		
		Dim stName,stDelimiter,stUrl As String
		
		If Not System.IO.Directory.Exists(stFolder) Then
			System.IO.Directory.CreateDirectory(stFolder)
		End If
		stFolder = stFolder & System.IO.Path.DirectorySeparatorChar
		
		'group title as sub folder
		
		Dim inFileNameCounter As Integer = 0
		
		'if stLastFolderName.Name=single, use folder letters
		Dim stLastFolderName As New System.IO.DirectoryInfo(stFolder)
		
		For i = 0 To dataGridView1.Rows.Count -2
			'dataGridView1.Columns("URL").Index
			stSubFolder = ""
			
			
			If Not String.IsNullOrEmpty( dataGridView1.Rows(i).Cells("URL").value ) Then 'if url not empty
				
				stUrl = dataGridView1.Rows(i).Cells("URL").value
				
				
				stFileName = ""
				
				' if has name column and not empty
				If dataGridView1.Columns.Contains("Name") AndAlso Not String.IsNullOrEmpty( dataGridView1.Rows(i).Cells("Name").value ) Then
					stFileName = dataGridView1.Rows(i).Cells("Name").value.ToString.Trim
				Else
					
					stDelimiter = ""
					If stUrl.Contains("\") Then
						stDelimiter = "\"
					ElseIf stUrl.Contains("/") Then
						stDelimiter = "/"
					End If
					
					If stUrl.Contains("\") Or stUrl.Contains("/") Then
						stFilename = stUrl.Substring(stUrl.LastIndexOf(stDelimiter)+1)
					Else
						stFilename = stUrl
					End If
					
					
				End If
				stFileName = stFileName.Trim
				
				'no name column, or it does not contain path
				If String.IsNullOrEmpty(stFileName) Then
					stFileName = "Unknown"
				End If
				
				stFileName = stFileName.Replace("%20"," ")
				
				stFileName = fnRemoveSpecialCharacters(stFileName)
				
				
				stSubfolderTag = ""
				
				
				If dataGridView1.Columns.Contains("#EXTINFgroup-title") Then
					If Not String.IsNullOrEmpty( dataGridView1.Rows(i).Cells("#EXTINFgroup-title").value ) Then 'if has group title
						
						'stSubFolder = dataGridView1.Rows(i).Cells("#EXTINFgroup-title").value
						stSubFolder = dataGridView1.Rows(i).Cells("#EXTINFgroup-title").value.ToString.Replace("""","").Trim 'from sides on group title
						
						stSubFolder = fnRemoveSpecialCharacters(stSubFolder) & System.IO.Path.DirectorySeparatorChar
						stSubfolderTag = " group-title=" & dataGridView1.Rows(i).Cells("#EXTINFgroup-title").value
					End If
					
				End If
				
				'separate files by first letter. in subfolders. if destination folder is named single, or Single.
				'stFilename might be changed later, but only the last part (adding +1 to name), so the first name stays the same.
				If stLastFolderName.Name.ToLower="singles" Or stLastFolderName.Name.ToLower="singles+series" Or stLastFolderName.Name.ToLower="series+singles" Then
					stSubFolder = stSubFolder & stFileName.Substring(0,1).ToUpper & System.IO.Path.DirectorySeparatorChar
				End If
				
				'separate to series
				If stLastFolderName.Name.ToLower="series" Or stLastFolderName.Name.ToLower="singles+series" Or stLastFolderName.Name.ToLower="series+singles" Then
					
					
					If stFileName.ToLower.Contains("_s0") Then
						stSubFolder = stSubFolder & stFileName.Substring(0,stFileName.ToLower.IndexOf("_s0") ) & System.IO.Path.DirectorySeparatorChar
						
					Else if stFileName.ToLower.Contains("_s1") Then
						stSubFolder = stSubFolder & stFileName.Substring(0,stFileName.ToLower.IndexOf("_s1") ) & System.IO.Path.DirectorySeparatorChar
						
					Else if stFileName.ToLower.Contains("_s2") Then
						stSubFolder = stSubFolder & stFileName.Substring(0,stFileName.ToLower.IndexOf("_s2") ) & System.IO.Path.DirectorySeparatorChar
						
					Else if stFileName.ToLower.Contains("_s3") Then
						stSubFolder = stSubFolder & stFileName.Substring(0,stFileName.ToLower.IndexOf("_s3") ) & System.IO.Path.DirectorySeparatorChar
						
					Else if stFileName.ToLower.Contains("_s4") Then
						stSubFolder = stSubFolder & stFileName.Substring(0,stFileName.ToLower.IndexOf("_s4") ) & System.IO.Path.DirectorySeparatorChar
						
					Else if stFileName.ToLower.Contains("_s5") Then
						stSubFolder = stSubFolder & stFileName.Substring(0,stFileName.ToLower.IndexOf("_s5") ) & System.IO.Path.DirectorySeparatorChar
						
					Else if stFileName.ToLower.Contains("_s6") Then
						stSubFolder = stSubFolder & stFileName.Substring(0,stFileName.ToLower.IndexOf("_s6") ) & System.IO.Path.DirectorySeparatorChar
						
					Else if stFileName.ToLower.Contains("_s7") Then
						stSubFolder = stSubFolder & stFileName.Substring(0,stFileName.ToLower.IndexOf("_s7") ) & System.IO.Path.DirectorySeparatorChar
						
					Else if stFileName.ToLower.Contains("_s8") Then
						stSubFolder = stSubFolder & stFileName.Substring(0,stFileName.ToLower.IndexOf("_s8") ) & System.IO.Path.DirectorySeparatorChar
						
					Else if stFileName.ToLower.Contains("_s9") Then
						stSubFolder = stSubFolder & stFileName.Substring(0,stFileName.ToLower.IndexOf("_s9") ) & System.IO.Path.DirectorySeparatorChar
						
						'for unknown season, to be used as separator	
					Else if stFileName.ToLower.Contains("_sx") Then
						stSubFolder = stSubFolder & stFileName.Substring(0,stFileName.ToLower.IndexOf("_sx") ) & System.IO.Path.DirectorySeparatorChar
						
					End If
					
					
					'last char is \ (System.IO.Path.DirectorySeparatorChar)
					'if char before that is _ or - or " " or "." , remove it , and add \  
					'-1 cause index starts with 0, -2 cause we need the one before last. 1 is length of substring
					'If stSubFolder.Substring(stSubFolder.Length-2,1) = "_" Or stSubFolder.Substring(stSubFolder.Length-2,1) = "-" Or stSubFolder.Substring(stSubFolder.Length-2,1) = "." Or stSubFolder.Substring(stSubFolder.Length-2,1) = " " Then
					'		stSubFolder = stSubFolder.Substring(0,stSubFolder.Length-2) & System.IO.Path.DirectorySeparatorChar
					'	End If
					
				End If
				
				
				If Not System.IO.Directory.Exists(stFolder &  stSubFolder ) Then
					System.IO.Directory.CreateDirectory(stFolder &  stSubFolder )
				End If
				
				If System.IO.File.Exists(stFolder & stSubFolder & stFileName & ".m3u") Then 'if exist file already
					
					inFileNameCounter = 0
					Do
						inFileNameCounter = inFileNameCounter + 1
						
					Loop Until  Not System.IO.File.Exists(stFolder & stSubFolder & stFileName & "-" & inFileNameCounter &".m3u") 'add number
					stFileName = stFileName & "-" & inFileNameCounter
				End If
				
				
				fiSaveFile = My.Computer.FileSystem.OpenTextFileWriter(  stFolder &  stSubFolder &  stFileName & ".m3u" , True) 'set save file name
				fiSaveFile.WriteLine("#EXTM3U ")
				fiSaveFile.WriteLine("#EXTINF:0 " & stSubfolderTag & " ," & stFileName) 'will get changed from "" to filename, maybe change back?
				'fiSaveFile.WriteLine("#EXTVLCOPT:http-user-agent=Android")
				fiSaveFile.WriteLine(stUrl)
				fiSaveFile.Close()	
			End If
			
			
			'fiSaveFile = My.Computer.FileSystem.OpenTextFileWriter("c:\test.txt", True)
			'fiSaveFile.WriteLine("Here is the first string.")
			'fiSaveFile.Close()	
			
			
		Next
		laStatus.Text = "Finished." & dataGridView1.Rows.Count-1 & " files should be in " & stFolder '-1 editing row?
	End Sub
	
	
	Sub CreateFolderFromM3UListToolStripMenuItemClick(sender As Object, e As EventArgs)
		
		Dim stFolder As String
		
		Dim folderBrowserDialog1 As New FolderBrowserDialog
		
		If folderBrowserDialog1.ShowDialog() = DialogResult.OK Then
			stFolder = folderBrowserDialog1.SelectedPath
		Else
			Exit Sub
		End If
		
		
		fnCreateFolderFromM3U(stFolder)
	End Sub
	
	
	Public Function fnRemoveSpecialCharacters(ByVal str As String) As String
		Return Regex.Replace(str, "[^a-zA-Z0-9_]+", "_", RegexOptions.Compiled)
	End Function
	
	
	
	
	Sub CopyNamesFromURLToolStripMenuItemClick(sender As Object, e As EventArgs)
		Dim stUrl,stFilename,stDelimiter As String
		
		
		For i As Integer = 0 To dataGridView1.Rows.Count -2
			If dataGridView1.Columns.Contains("Name") And dataGridView1.Columns.Contains("URL") Then
				If Not String.IsNullOrEmpty( dataGridView1.Rows(i).Cells("URL").value )  AndAlso String.IsNullOrEmpty( dataGridView1.Rows(i).Cells("Name").value )  Then
					
					
					stUrl = dataGridView1.Rows(i).Cells("URL").Value.Trim 
					
					stDelimiter = ""
					If stUrl.Contains("\") Then
						stDelimiter = "\"
					ElseIf stUrl.Contains("/") Then
						stDelimiter = "/"
					End If
					
					
					If stUrl.Contains("\") Or stUrl.Contains("/") Then
						
						'if ends on / or \ remove it by shortening url for 1 char
						If stUrl.Substring(stUrl.Length-1) = "\" Or stUrl.Substring(stUrl.Length-1) = "/" Then
							stUrl = stUrl.Substring(0,stUrl.Length-1)
						End If
						
						stFilename = stUrl.Substring(stUrl.LastIndexOf(stDelimiter)+1)
					Else
						stFilename = stUrl
					End If
					
					
					stFileName = stFileName.Replace("%20"," ")
					stFileName = fnRemoveSpecialCharacters(stFileName)
					
					dataGridView1.Rows(i).Cells("Name").Value = stFileName
				End If
			End If
			
		Next
	End Sub
	
	
	
	
	Sub BnSearchClick(sender As Object, e As EventArgs)
		
		
		If My.Computer.Keyboard.CtrlKeyDown Then 'clear if ctrl pressed and clicked on button
			For x = 0 To dataGridView1.Rows.Count -2
				dataGridView1.Rows(x).DefaultCellStyle.BackColor = Color.White
				'dataGridView1.Rows.Item(x).Visible = True
			Next 
			Exit Sub
		End If
		
		
		
		If cmSearchFor.Text = "" Then
			For x = 0 To dataGridView1.Rows.Count -2
				dataGridView1.Rows(x).DefaultCellStyle.BackColor = Color.White
				'dataGridView1.Rows.Item(x).Visible = True
			Next 
			Exit Sub
		End If
		
		
		If  dataGridView1.Rows.Count = 0 Or cmColumnName.Text = "" Then
			Exit Sub
		End If
		
		'before new search
		For x = 0 To dataGridView1.Rows.Count -2
			dataGridView1.Rows(x).DefaultCellStyle.BackColor = Color.White
			'dataGridView1.Rows.Item(x).Visible = True
		Next 
		
		
		Dim inSearchColumnIndex As Integer
		
		If cmSearchFor.FindString(cmSearchFor.Text) = -1 Then 'search term not exist in search combo box, add it
			cmSearchFor.Items.Add(cmSearchFor.Text)
		End If
		
		
		If Int32.TryParse(cmColumnName.Text, inSearchColumnIndex) Then ' select column to search by column index, starting from 1
			If inSearchColumnIndex>0 Then
				inSearchColumnIndex = inSearchColumnIndex -1
			End If
		Else
			
			For i = 0 To dataGridView1.Columns.Count - 1
				If dataGridView1.Columns(i).Name.ToLower = cmColumnName.Text.ToLower Then 'set columindex name to search in index
					inSearchColumnIndex = i
				End If
			next
			
		End If
		
		
		
		Dim stCellText As String
		
		laSelectedCell.Text = ""
		laStatus.Text = "Please wait, searching table ..."
		Update
		Dim inResultColumnIndex As Integer 'hmm
		
		'add column if not exist, but only if enabled in menu, or not shift pressed
		If searchMovesMatchingRowsToTheTopToolStripMenuItem.Checked = True And My.Computer.Keyboard.ShiftKeyDown = False
			If Not dataGridView1.Columns.Contains("__searchresultForCSVEdit__") Then
				dataGridView1.Columns.Add("__searchresultForCSVEdit__","__searchresultForCSVEdit__")
				dataGridView1.Columns("__searchresultForCSVEdit__").Visible = False
			End If
			inResultColumnIndex = dataGridView1.Columns("__searchresultForCSVEdit__").Index
		End If
		
		
		For x = 0 To dataGridView1.Rows.Count -2
			stCellText = Nothing
			
			
			If Not String.IsNullOrEmpty(dataGridView1.Rows(x).Cells(inSearchColumnIndex).Value) Then
				stCellText = dataGridView1.Rows(x).Cells(inSearchColumnIndex).Value
				If stCellText.ToLower.Contains(cmSearchFor.Text.ToLower) Then
					'dataGridView1.Rows.Item(x).Visible = False
					'MessageBox.Show( inResultColumnIndex )
					If searchMovesMatchingRowsToTheTopToolStripMenuItem.Checked = True And My.Computer.Keyboard.ShiftKeyDown = False
						dataGridView1.Rows(x).Cells( inResultColumnIndex ).Value = dataGridView1.Rows.Count - x 'it will be sorted in reverse, all with value in extra column. make it so first one is 9 instead of 1, then 8 instead of 2 ...
					End If
					dataGridView1.Rows(x).DefaultCellStyle.BackColor = Color.Beige
				End If
			End If
			
			
		Next
		
		If searchMovesMatchingRowsToTheTopToolStripMenuItem.Checked = True And My.Computer.Keyboard.ShiftKeyDown = False
			dataGridView1.Sort(dataGridView1.Columns(inResultColumnIndex),System.ComponentModel.ListSortDirection.Descending)
			dataGridView1.Columns.RemoveAt( inResultColumnIndex )
		End If
		
		laStatus.Text = "Done"
		
		Update
		
	End Sub
	
	
	Sub DoubleClickCellToPlayURLInM3UListToolStripMenuItemClick(sender As Object, e As EventArgs)
		laStatus.Text = "Status of '" & sender.ToString & "' changed to: "& DoubleClickCellToPlayURLInM3UListToolStripMenuItem.CheckState
	End Sub
	
	Sub SearchMovesMatchingRowsToTheTopToolStripMenuItemClick(sender As Object, e As EventArgs)
		laStatus.Text = "Status of '" & sender.ToString & "' changed to: "& SearchMovesMatchingRowsToTheTopToolStripMenuItem.CheckState
	End Sub
	
	Sub SetUserAgentWhenStreamingToolStripMenuItemClick(sender As Object, e As EventArgs)
		laStatus.Text = "Status of '" & sender.ToString & "' changed to: "& SetUserAgentWhenStreamingToolStripMenuItem.CheckState
	End Sub
	
	Sub ValidateM3UCellValuesWhenSavingToolStripMenuItemClick(sender As Object, e As EventArgs)
		laStatus.Text = "Status of '" & sender.ToString & "' changed to: "& ValidateM3UCellValuesWhenSavingToolStripMenuItem.CheckState
	End Sub
	
	Sub ReplaceSpecialCharactersWhenConvertingXMLToolStripMenuItemClick(sender As Object, e As EventArgs)
		laStatus.Text = "Status of '" & sender.ToString & "' changed to: "& ReplaceSpecialCharactersWhenConvertingXMLToolStripMenuItem.CheckState
	End Sub
	
	Sub DoNotFilterDroppedMultipleFilesOnProgramToolStripMenuItemClick(sender As Object, e As EventArgs)
		laStatus.Text = "Status of '" & sender.ToString & "' changed to: "& DoNotFilterDroppedMultipleFilesOnProgramToolStripMenuItem.CheckState
	End Sub
	
	Sub PasteSingleValueInSelectedCellsAppendToolStripMenuItemClick(sender As Object, e As EventArgs)
		
		
		'Paste first value from the clipboard to all selected cells
		Dim stClipboard As String 
		stClipboard = Clipboard.GetText
		stClipboard=  Strings.Split(stClipboard,Environment.NewLine)(0)
		stClipboard = Strings.Split(stClipboard,vbCr)(0)'maybe disable this?
		stClipboard = Strings.Split(stClipboard,vbLf)(0)'maybe disable this?
		stClipboard = Strings.Split(stClipboard,vbTab)(0)
		
		'no selected
		If dataGridView1.SelectedCells.Count = 0 Then
			Exit Sub
		End If
		
		If stClipboard.Length = 0 Then
			'Exit Sub 'empty? 
		End If
		
		
		'have to be in order
		For i As Integer = 0 To dataGridView1.Rows.Count-1
			For j As Integer = 0 To dataGridView1.Columns.Count-1
				If dataGridView1.Rows(i).Cells(j).Selected Then
					
					If Not dataGridView1.Rows(i).Index <=dataGridView1.Rows.Count-2 Then '2 because editing row
						dataGridView1.Rows.Add(1)
					End If
					
					dataGridView1.Rows(i).Cells(j).Value=dataGridView1.Rows(i).Cells(j).Value & stClipboard
				End If
			Next
		Next
		
		
	End Sub
	
	Sub PasteSingleValueInSelectedCellsAsPrefixToolStripMenuItemClick(sender As Object, e As EventArgs)
		'Paste first value from the clipboard to all selected cells
		Dim stClipboard As String 
		stClipboard = Clipboard.GetText
		stClipboard=  Strings.Split(stClipboard,Environment.NewLine)(0)
		stClipboard = Strings.Split(stClipboard,vbCr)(0)'maybe disable this?
		stClipboard = Strings.Split(stClipboard,vbLf)(0)'maybe disable this?
		stClipboard = Strings.Split(stClipboard,vbTab)(0)
		
		'no selected
		If dataGridView1.SelectedCells.Count = 0 Then
			Exit Sub
		End If
		
		If stClipboard.Length = 0 Then
			'Exit Sub 'empty? 
		End If
		
		
		'have to be in order
		For i As Integer = 0 To dataGridView1.Rows.Count-1
			For j As Integer = 0 To dataGridView1.Columns.Count-1
				If dataGridView1.Rows(i).Cells(j).Selected Then
					
					If Not dataGridView1.Rows(i).Index <=dataGridView1.Rows.Count-2 Then '2 because editing row
						dataGridView1.Rows.Add(1)
					End If
					
					dataGridView1.Rows(i).Cells(j).Value=stClipboard & dataGridView1.Rows(i).Cells(j).Value
				End If
			Next
		Next
		
	End Sub
End Class

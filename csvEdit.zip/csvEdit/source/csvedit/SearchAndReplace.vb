﻿'
' Created by SharpDevelop.
' User: bojan
' Date: 9/8/2024
' Time: 10:58 AM
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Public Partial Class SearchAndReplaceForm
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	
	Sub BtReplaceClick(sender As Object, e As EventArgs)
		Close
	End Sub
	
	Sub SearchAndReplaceFormLoad(sender As Object, e As EventArgs)
		cbCase.SelectedIndex = 0
		tbSearch.Focus
		
	End Sub
End Class

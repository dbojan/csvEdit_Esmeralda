﻿'
' Created by SharpDevelop.
' User: bojan
' Date: 9/8/2024
' Time: 10:58 AM
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class SearchAndReplaceForm
	Inherits System.Windows.Forms.Form
	
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
		Me.btReplace = New System.Windows.Forms.Button()
		Me.tbSearch = New System.Windows.Forms.TextBox()
		Me.lbSearch = New System.Windows.Forms.Label()
		Me.lbReplace = New System.Windows.Forms.Label()
		Me.tbReplace = New System.Windows.Forms.TextBox()
		Me.lbCase = New System.Windows.Forms.Label()
		Me.cbCase = New System.Windows.Forms.ComboBox()
		Me.SuspendLayout
		'
		'btReplace
		'
		Me.btReplace.Location = New System.Drawing.Point(300, 81)
		Me.btReplace.Name = "btReplace"
		Me.btReplace.Size = New System.Drawing.Size(75, 23)
		Me.btReplace.TabIndex = 3
		Me.btReplace.Text = "Replace"
		Me.btReplace.UseVisualStyleBackColor = true
		AddHandler Me.btReplace.Click, AddressOf Me.BtReplaceClick
		'
		'tbSearch
		'
		Me.tbSearch.Location = New System.Drawing.Point(92, 34)
		Me.tbSearch.Name = "tbSearch"
		Me.tbSearch.Size = New System.Drawing.Size(186, 20)
		Me.tbSearch.TabIndex = 1
		'
		'lbSearch
		'
		Me.lbSearch.Location = New System.Drawing.Point(35, 37)
		Me.lbSearch.Name = "lbSearch"
		Me.lbSearch.Size = New System.Drawing.Size(51, 23)
		Me.lbSearch.TabIndex = 2
		Me.lbSearch.Text = "Search"
		'
		'lbReplace
		'
		Me.lbReplace.Location = New System.Drawing.Point(35, 84)
		Me.lbReplace.Name = "lbReplace"
		Me.lbReplace.Size = New System.Drawing.Size(51, 23)
		Me.lbReplace.TabIndex = 4
		Me.lbReplace.Text = "Replace"
		'
		'tbReplace
		'
		Me.tbReplace.Location = New System.Drawing.Point(92, 81)
		Me.tbReplace.Name = "tbReplace"
		Me.tbReplace.Size = New System.Drawing.Size(186, 20)
		Me.tbReplace.TabIndex = 2
		'
		'lbCase
		'
		Me.lbCase.Location = New System.Drawing.Point(35, 129)
		Me.lbCase.Name = "lbCase"
		Me.lbCase.Size = New System.Drawing.Size(51, 23)
		Me.lbCase.TabIndex = 6
		Me.lbCase.Text = "Case"
		'
		'cbCase
		'
		Me.cbCase.FormattingEnabled = true
		Me.cbCase.Items.AddRange(New Object() {"insensitive", "Sensitive"})
		Me.cbCase.Location = New System.Drawing.Point(92, 126)
		Me.cbCase.Name = "cbCase"
		Me.cbCase.Size = New System.Drawing.Size(186, 21)
		Me.cbCase.TabIndex = 4
		'
		'SearchAndReplaceForm
		'
		Me.AcceptButton = Me.btReplace
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(419, 179)
		Me.Controls.Add(Me.cbCase)
		Me.Controls.Add(Me.lbCase)
		Me.Controls.Add(Me.lbReplace)
		Me.Controls.Add(Me.tbReplace)
		Me.Controls.Add(Me.lbSearch)
		Me.Controls.Add(Me.tbSearch)
		Me.Controls.Add(Me.btReplace)
		Me.Name = "SearchAndReplaceForm"
		Me.Text = "SearchAndReplace"
		AddHandler Load, AddressOf Me.SearchAndReplaceFormLoad
		Me.ResumeLayout(false)
		Me.PerformLayout
	End Sub
	Public cbCase As System.Windows.Forms.ComboBox
	Private lbCase As System.Windows.Forms.Label
	Public tbReplace As System.Windows.Forms.TextBox
	Private lbReplace As System.Windows.Forms.Label
	Private lbSearch As System.Windows.Forms.Label
	Public tbSearch As System.Windows.Forms.TextBox
	Private btReplace As System.Windows.Forms.Button
End Class

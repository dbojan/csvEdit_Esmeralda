﻿'
' Created by SharpDevelop.
' User: bojan
' Date: sri 20.07.2022.
' Time: 09:12
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class MainForm
	Inherits System.Windows.Forms.Form
	
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Me.dataGridView1 = New System.Windows.Forms.DataGridView()
		Me.contextMenuStripContext = New System.Windows.Forms.ContextMenuStrip(Me.components)
		Me.cutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.copyToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
		Me.pasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.deleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.menuStrip1 = New System.Windows.Forms.MenuStrip()
		Me.fileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.newToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.openToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.reloadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.saveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.saveAsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.clearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.openInNotepadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.quitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.editToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.cutToolStripMenuItemFORMMENU = New System.Windows.Forms.ToolStripMenuItem()
		Me.copyToolStripMenuItemFROMMENU = New System.Windows.Forms.ToolStripMenuItem()
		Me.pasteToolStripMenuItemFORMMENU = New System.Windows.Forms.ToolStripMenuItem()
		Me.deleteToolStripMenuItemFORMMENU = New System.Windows.Forms.ToolStripMenuItem()
		Me.insertToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.columnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.insertColumnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.removeColumnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.rowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.insertRowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.removeRowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.toolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
		Me.changeDelimiterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.helpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.aboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.statusStrip1 = New System.Windows.Forms.StatusStrip()
		Me.laFilename = New System.Windows.Forms.ToolStripStatusLabel()
		Me.laDelimiter = New System.Windows.Forms.ToolStripStatusLabel()
		Me.laStatus = New System.Windows.Forms.ToolStripStatusLabel()
		Me.laSelectedCell = New System.Windows.Forms.ToolStripStatusLabel()
		Me.laChanged = New System.Windows.Forms.ToolStripStatusLabel()
		CType(Me.dataGridView1,System.ComponentModel.ISupportInitialize).BeginInit
		Me.contextMenuStripContext.SuspendLayout
		Me.menuStrip1.SuspendLayout
		Me.statusStrip1.SuspendLayout
		Me.SuspendLayout
		'
		'dataGridView1
		'
		Me.dataGridView1.AllowDrop = true
		Me.dataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom)  _
						Or System.Windows.Forms.AnchorStyles.Left)  _
						Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
		Me.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
		Me.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
		Me.dataGridView1.ContextMenuStrip = Me.contextMenuStripContext
		Me.dataGridView1.Location = New System.Drawing.Point(12, 27)
		Me.dataGridView1.Name = "dataGridView1"
		Me.dataGridView1.Size = New System.Drawing.Size(980, 390)
		Me.dataGridView1.TabIndex = 1
		AddHandler Me.dataGridView1.CellValueChanged, AddressOf Me.DataGridView1CellValueChanged
		AddHandler Me.dataGridView1.ColumnAdded, AddressOf Me.DataGridView1ColumnAdded
		AddHandler Me.dataGridView1.ColumnRemoved, AddressOf Me.DataGridView1ColumnRemoved
		AddHandler Me.dataGridView1.RowsAdded, AddressOf Me.DataGridView1RowsAdded
		AddHandler Me.dataGridView1.RowsRemoved, AddressOf Me.DataGridView1RowsRemoved
		AddHandler Me.dataGridView1.Sorted, AddressOf Me.DataGridView1Sorted
		AddHandler Me.dataGridView1.Click, AddressOf Me.DataGridView1Click
		AddHandler Me.dataGridView1.DragDrop, AddressOf Me.MainFormDragDrop
		AddHandler Me.dataGridView1.DragEnter, AddressOf Me.MainFormDragEnter
		'
		'contextMenuStripContext
		'
		Me.contextMenuStripContext.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cutToolStripMenuItem, Me.copyToolStripMenuItem1, Me.pasteToolStripMenuItem, Me.deleteToolStripMenuItem})
		Me.contextMenuStripContext.Name = "contextMenuStrip1"
		Me.contextMenuStripContext.Size = New System.Drawing.Size(191, 92)
		'
		'cutToolStripMenuItem
		'
		Me.cutToolStripMenuItem.Name = "cutToolStripMenuItem"
		Me.cutToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
		Me.cutToolStripMenuItem.Text = "Cut"
		AddHandler Me.cutToolStripMenuItem.Click, AddressOf Me.CutToolStripMenuItemClick
		'
		'copyToolStripMenuItem1
		'
		Me.copyToolStripMenuItem1.Name = "copyToolStripMenuItem1"
		Me.copyToolStripMenuItem1.Size = New System.Drawing.Size(190, 22)
		Me.copyToolStripMenuItem1.Text = "Copy"
		AddHandler Me.copyToolStripMenuItem1.Click, AddressOf Me.CopyToolStripMenuItem1Click
		'
		'pasteToolStripMenuItem
		'
		Me.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem"
		Me.pasteToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
		Me.pasteToolStripMenuItem.Text = "Paste In Selected Cells"
		AddHandler Me.pasteToolStripMenuItem.Click, AddressOf Me.PasteToolStripMenuItemClick
		'
		'deleteToolStripMenuItem
		'
		Me.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem"
		Me.deleteToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
		Me.deleteToolStripMenuItem.Text = "Delete"
		AddHandler Me.deleteToolStripMenuItem.Click, AddressOf Me.DeleteToolStripMenuItemClick
		'
		'menuStrip1
		'
		Me.menuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.fileToolStripMenuItem, Me.editToolStripMenuItem, Me.insertToolStripMenuItem, Me.helpToolStripMenuItem})
		Me.menuStrip1.Location = New System.Drawing.Point(0, 0)
		Me.menuStrip1.Name = "menuStrip1"
		Me.menuStrip1.Size = New System.Drawing.Size(1004, 24)
		Me.menuStrip1.TabIndex = 2
		Me.menuStrip1.Text = "menuStrip1"
		'
		'fileToolStripMenuItem
		'
		Me.fileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.newToolStripMenuItem, Me.openToolStripMenuItem, Me.reloadToolStripMenuItem, Me.saveToolStripMenuItem, Me.saveAsToolStripMenuItem, Me.clearToolStripMenuItem, Me.openInNotepadToolStripMenuItem, Me.quitToolStripMenuItem})
		Me.fileToolStripMenuItem.Name = "fileToolStripMenuItem"
		Me.fileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
		Me.fileToolStripMenuItem.Text = "File"
		'
		'newToolStripMenuItem
		'
		Me.newToolStripMenuItem.Name = "newToolStripMenuItem"
		Me.newToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
		Me.newToolStripMenuItem.Text = "New"
		AddHandler Me.newToolStripMenuItem.Click, AddressOf Me.NewToolStripMenuItemClick
		'
		'openToolStripMenuItem
		'
		Me.openToolStripMenuItem.Name = "openToolStripMenuItem"
		Me.openToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
		Me.openToolStripMenuItem.Text = "Open ..."
		AddHandler Me.openToolStripMenuItem.Click, AddressOf Me.OpenToolStripMenuItemClick
		'
		'reloadToolStripMenuItem
		'
		Me.reloadToolStripMenuItem.Name = "reloadToolStripMenuItem"
		Me.reloadToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
		Me.reloadToolStripMenuItem.Text = "Re-Open"
		AddHandler Me.reloadToolStripMenuItem.Click, AddressOf Me.ReloadToolStripMenuItemClick
		'
		'saveToolStripMenuItem
		'
		Me.saveToolStripMenuItem.Name = "saveToolStripMenuItem"
		Me.saveToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
		Me.saveToolStripMenuItem.Text = "Save"
		AddHandler Me.saveToolStripMenuItem.Click, AddressOf Me.SaveToolStripMenuItemClick
		'
		'saveAsToolStripMenuItem
		'
		Me.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem"
		Me.saveAsToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
		Me.saveAsToolStripMenuItem.Text = "Save As ..."
		AddHandler Me.saveAsToolStripMenuItem.Click, AddressOf Me.SaveAsToolStripMenuItemClick
		'
		'clearToolStripMenuItem
		'
		Me.clearToolStripMenuItem.Name = "clearToolStripMenuItem"
		Me.clearToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
		Me.clearToolStripMenuItem.Text = "Close"
		AddHandler Me.clearToolStripMenuItem.Click, AddressOf Me.ClearToolStripMenuItemClick
		'
		'openInNotepadToolStripMenuItem
		'
		Me.openInNotepadToolStripMenuItem.Name = "openInNotepadToolStripMenuItem"
		Me.openInNotepadToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
		Me.openInNotepadToolStripMenuItem.Text = "Open in Notepad"
		AddHandler Me.openInNotepadToolStripMenuItem.Click, AddressOf Me.OpenInNotepadToolStripMenuItemClick
		'
		'quitToolStripMenuItem
		'
		Me.quitToolStripMenuItem.Name = "quitToolStripMenuItem"
		Me.quitToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
		Me.quitToolStripMenuItem.Text = "Quit"
		AddHandler Me.quitToolStripMenuItem.Click, AddressOf Me.QuitToolStripMenuItemClick
		'
		'editToolStripMenuItem
		'
		Me.editToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cutToolStripMenuItemFORMMENU, Me.copyToolStripMenuItemFROMMENU, Me.pasteToolStripMenuItemFORMMENU, Me.deleteToolStripMenuItemFORMMENU})
		Me.editToolStripMenuItem.Name = "editToolStripMenuItem"
		Me.editToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
		Me.editToolStripMenuItem.Text = "Edit"
		'
		'cutToolStripMenuItemFORMMENU
		'
		Me.cutToolStripMenuItemFORMMENU.Name = "cutToolStripMenuItemFORMMENU"
		Me.cutToolStripMenuItemFORMMENU.Size = New System.Drawing.Size(190, 22)
		Me.cutToolStripMenuItemFORMMENU.Text = "Cut"
		AddHandler Me.cutToolStripMenuItemFORMMENU.Click, AddressOf Me.CutToolStripMenuItem1Click
		'
		'copyToolStripMenuItemFROMMENU
		'
		Me.copyToolStripMenuItemFROMMENU.Name = "copyToolStripMenuItemFROMMENU"
		Me.copyToolStripMenuItemFROMMENU.Size = New System.Drawing.Size(190, 22)
		Me.copyToolStripMenuItemFROMMENU.Text = "Copy"
		AddHandler Me.copyToolStripMenuItemFROMMENU.Click, AddressOf Me.CopyToolStripMenuItemClick
		'
		'pasteToolStripMenuItemFORMMENU
		'
		Me.pasteToolStripMenuItemFORMMENU.Name = "pasteToolStripMenuItemFORMMENU"
		Me.pasteToolStripMenuItemFORMMENU.Size = New System.Drawing.Size(190, 22)
		Me.pasteToolStripMenuItemFORMMENU.Text = "Paste In Selected Cells"
		AddHandler Me.pasteToolStripMenuItemFORMMENU.Click, AddressOf Me.PasteToolStripMenuItem1Click
		'
		'deleteToolStripMenuItemFORMMENU
		'
		Me.deleteToolStripMenuItemFORMMENU.Name = "deleteToolStripMenuItemFORMMENU"
		Me.deleteToolStripMenuItemFORMMENU.Size = New System.Drawing.Size(190, 22)
		Me.deleteToolStripMenuItemFORMMENU.Text = "Delete"
		AddHandler Me.deleteToolStripMenuItemFORMMENU.Click, AddressOf Me.DeleteToolStripMenuItem1Click
		'
		'insertToolStripMenuItem
		'
		Me.insertToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.columnToolStripMenuItem, Me.insertColumnToolStripMenuItem, Me.removeColumnToolStripMenuItem, Me.rowToolStripMenuItem, Me.insertRowToolStripMenuItem, Me.removeRowToolStripMenuItem, Me.toolStripMenuItem2, Me.changeDelimiterToolStripMenuItem})
		Me.insertToolStripMenuItem.Name = "insertToolStripMenuItem"
		Me.insertToolStripMenuItem.Size = New System.Drawing.Size(57, 20)
		Me.insertToolStripMenuItem.Text = "Modify"
		'
		'columnToolStripMenuItem
		'
		Me.columnToolStripMenuItem.Name = "columnToolStripMenuItem"
		Me.columnToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
		Me.columnToolStripMenuItem.Text = "Column Add"
		AddHandler Me.columnToolStripMenuItem.Click, AddressOf Me.ColumnToolStripMenuItemClick
		'
		'insertColumnToolStripMenuItem
		'
		Me.insertColumnToolStripMenuItem.Name = "insertColumnToolStripMenuItem"
		Me.insertColumnToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
		Me.insertColumnToolStripMenuItem.Text = "Column Insert"
		AddHandler Me.insertColumnToolStripMenuItem.Click, AddressOf Me.InsertColumnToolStripMenuItemClick
		'
		'removeColumnToolStripMenuItem
		'
		Me.removeColumnToolStripMenuItem.Name = "removeColumnToolStripMenuItem"
		Me.removeColumnToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
		Me.removeColumnToolStripMenuItem.Text = "Column(s) Remove"
		AddHandler Me.removeColumnToolStripMenuItem.Click, AddressOf Me.RemoveColumnToolStripMenuItemClick
		'
		'rowToolStripMenuItem
		'
		Me.rowToolStripMenuItem.Name = "rowToolStripMenuItem"
		Me.rowToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
		Me.rowToolStripMenuItem.Text = "Row Add"
		AddHandler Me.rowToolStripMenuItem.Click, AddressOf Me.RowToolStripMenuItemClick
		'
		'insertRowToolStripMenuItem
		'
		Me.insertRowToolStripMenuItem.Name = "insertRowToolStripMenuItem"
		Me.insertRowToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
		Me.insertRowToolStripMenuItem.Text = "Row Insert"
		AddHandler Me.insertRowToolStripMenuItem.Click, AddressOf Me.InsertRowToolStripMenuItemClick
		'
		'removeRowToolStripMenuItem
		'
		Me.removeRowToolStripMenuItem.Name = "removeRowToolStripMenuItem"
		Me.removeRowToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
		Me.removeRowToolStripMenuItem.Text = "Row(s) Remove"
		AddHandler Me.removeRowToolStripMenuItem.Click, AddressOf Me.RemoveRowToolStripMenuItemClick
		'
		'toolStripMenuItem2
		'
		Me.toolStripMenuItem2.Name = "toolStripMenuItem2"
		Me.toolStripMenuItem2.Size = New System.Drawing.Size(176, 22)
		Me.toolStripMenuItem2.Text = "---"
		'
		'changeDelimiterToolStripMenuItem
		'
		Me.changeDelimiterToolStripMenuItem.Name = "changeDelimiterToolStripMenuItem"
		Me.changeDelimiterToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
		Me.changeDelimiterToolStripMenuItem.Text = "Change Delimiter"
		AddHandler Me.changeDelimiterToolStripMenuItem.Click, AddressOf Me.ChangeDelimiterToolStripMenuItemClick
		'
		'helpToolStripMenuItem
		'
		Me.helpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.aboutToolStripMenuItem})
		Me.helpToolStripMenuItem.Name = "helpToolStripMenuItem"
		Me.helpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
		Me.helpToolStripMenuItem.Text = "Help"
		'
		'aboutToolStripMenuItem
		'
		Me.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem"
		Me.aboutToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
		Me.aboutToolStripMenuItem.Text = "About"
		AddHandler Me.aboutToolStripMenuItem.Click, AddressOf Me.AboutToolStripMenuItemClick
		'
		'statusStrip1
		'
		Me.statusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.laFilename, Me.laDelimiter, Me.laStatus, Me.laSelectedCell, Me.laChanged})
		Me.statusStrip1.Location = New System.Drawing.Point(0, 420)
		Me.statusStrip1.Name = "statusStrip1"
		Me.statusStrip1.Size = New System.Drawing.Size(1004, 22)
		Me.statusStrip1.TabIndex = 3
		Me.statusStrip1.Text = "statusStrip1"
		'
		'laFilename
		'
		Me.laFilename.Name = "laFilename"
		Me.laFilename.Size = New System.Drawing.Size(0, 17)
		'
		'laDelimiter
		'
		Me.laDelimiter.Name = "laDelimiter"
		Me.laDelimiter.Size = New System.Drawing.Size(0, 17)
		'
		'laStatus
		'
		Me.laStatus.Name = "laStatus"
		Me.laStatus.Size = New System.Drawing.Size(0, 17)
		'
		'laSelectedCell
		'
		Me.laSelectedCell.Name = "laSelectedCell"
		Me.laSelectedCell.Size = New System.Drawing.Size(0, 17)
		'
		'laChanged
		'
		Me.laChanged.Name = "laChanged"
		Me.laChanged.Size = New System.Drawing.Size(0, 17)
		'
		'MainForm
		'
		Me.AllowDrop = true
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(1004, 442)
		Me.Controls.Add(Me.statusStrip1)
		Me.Controls.Add(Me.dataGridView1)
		Me.Controls.Add(Me.menuStrip1)
		Me.MainMenuStrip = Me.menuStrip1
		Me.Name = "MainForm"
		Me.Text = "csvEdit"
		AddHandler FormClosing, AddressOf Me.MainFormFormClosing
		AddHandler Load, AddressOf Me.MainFormLoad
		AddHandler DragDrop, AddressOf Me.MainFormDragDrop
		AddHandler DragEnter, AddressOf Me.MainFormDragEnter
		CType(Me.dataGridView1,System.ComponentModel.ISupportInitialize).EndInit
		Me.contextMenuStripContext.ResumeLayout(false)
		Me.menuStrip1.ResumeLayout(false)
		Me.menuStrip1.PerformLayout
		Me.statusStrip1.ResumeLayout(false)
		Me.statusStrip1.PerformLayout
		Me.ResumeLayout(false)
		Me.PerformLayout
	End Sub
	Private laChanged As System.Windows.Forms.ToolStripStatusLabel
	Private deleteToolStripMenuItemFORMMENU As System.Windows.Forms.ToolStripMenuItem
	Private pasteToolStripMenuItemFORMMENU As System.Windows.Forms.ToolStripMenuItem
	Private cutToolStripMenuItemFORMMENU As System.Windows.Forms.ToolStripMenuItem
	Private deleteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private pasteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private copyToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
	Private cutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private contextMenuStripContext As System.Windows.Forms.ContextMenuStrip
	Private toolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
	Private changeDelimiterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private laSelectedCell As System.Windows.Forms.ToolStripStatusLabel
	Private removeColumnToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private removeRowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private insertColumnToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private insertRowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private rowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private columnToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private insertToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private openInNotepadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private reloadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private newToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private saveAsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private aboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private helpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private laStatus As System.Windows.Forms.ToolStripStatusLabel
	Private copyToolStripMenuItemFROMMENU As System.Windows.Forms.ToolStripMenuItem
	Private editToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private quitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private clearToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private laDelimiter As System.Windows.Forms.ToolStripStatusLabel
	Private laFilename As System.Windows.Forms.ToolStripStatusLabel
	Private statusStrip1 As System.Windows.Forms.StatusStrip
	Private saveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private openToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private fileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Private menuStrip1 As System.Windows.Forms.MenuStrip
	Private dataGridView1 As System.Windows.Forms.DataGridView
	

	

End Class
